
import UIKit
import LGSideMenuController
import ProgressHUD

class ViewAllViewController: BaseController,SvodViewModelDelegate {
    
    var viewAllClicked = false
    var viewModel  = SvodViewModel()
    var catId = ""
    var isLastCat = false
    init?(coder: NSCoder, id: String, isLastCategory : Bool) {
        self.catId = id
        self.isLastCat = isLastCategory
        super.init(coder: coder)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "On Demand Controller"
        view.backgroundColor = UIColor(red: 32, green: 32, blue: 32)
        viewModel.delegate = self
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
        tableView.register(OnDemadTableViewCell.nib(), forCellReuseIdentifier: OnDemadTableViewCell.identifier)
        tableView.delegate = self
        tableView.dataSource = self
        self.viewModel.getRootCategoryData(catId: self.catId)
    }
    @IBAction func backButtonClicked(_ sender: Any) {
        
        navigationController?.popViewController(animated: true)
    }
    
    func didUpdateRow(didUpdate: Bool) {
        if(didUpdate)
        {
            tableView.reloadData()
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        if(!self.viewAllClicked)
        {
            DispatchQueue.main.async {
                self.viewModel.VodDic = [:]
                self.viewModel.sectionTitle = []
                self.tableView.reloadData()
            }
        }
        self.viewAllClicked  = false
    }
    
}
extension ViewAllViewController : UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.viewModel.sectionTitle.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.viewModel.sectionTitle[section]
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = .clear
        let headerLabel = UILabel()
        headerLabel.text = viewModel.sectionTitle[section]
        headerLabel.textColor = UIColor.white
        headerLabel.font = UIFont.boldSystemFont(ofSize: 16)
        
        headerLabel.frame = CGRect(x: 16, y: -10, width: tableView.bounds.size.width - 32, height: 40)
        headerView.addSubview(headerLabel)
        let viewAllButton: UIButton = {
            let button = UIButton(type: .system)
            button.translatesAutoresizingMaskIntoConstraints = false
            button.setTitle("VIEW ALL", for: .normal)
            button.tintColor = .white
            button.isHidden = false
            button.tag = section
            button.backgroundColor = .clear
            button.addTarget(self, action: #selector(ViewAllButtonTapped(_:)), for: .touchUpInside)
            return button
        }()
        headerView.addSubview(viewAllButton)
        let catAsset = self.viewModel.VodDic[self.viewModel.sectionTitle[section]]
        let shouldShowViewAll = catAsset?.first?.isParentCategory ?? false ? catAsset?.first?.isParentCategory  : catAsset?.first?.assets?.count ?? 0 >= 10
        viewAllButton.isHidden = shouldShowViewAll ?? false ? false : true
        NSLayoutConstraint.activate([
            
            viewAllButton.trailingAnchor.constraint(equalTo: headerView.trailingAnchor, constant: -10),
            viewAllButton.centerYAnchor.constraint(equalTo: headerView.centerYAnchor)
        ])
        if(self.isLastCat)
        {
            headerView.isHidden = true
        }
        return headerView
    }
    
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: OnDemadTableViewCell.identifier, for: indexPath) as! OnDemadTableViewCell
        cell.onDemandCellTapDelegate = self
        if indexPath.section < self.viewModel.sectionTitle.count
        {
            if let assets = self.viewModel.VodDic[self.viewModel.sectionTitle[indexPath.section]]?.first?.assets {
                cell.configure(with: assets, isLast: self.isLastCat)
            } else {
                return OnDemadTableViewCell()
            }
        }
        else
        {
            return OnDemadTableViewCell()
        }
        ProgressHUD.dismiss()
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if(self.isLastCat)
        {
            return UIScreen.main.bounds.size.height
        }
        return 220
    }
    
    @objc func ViewAllButtonTapped(_ sender: UIButton) {
        self.viewAllClicked = true
        let catId = self.viewModel.catListIds[self.viewModel.VodDic[self.viewModel.sectionTitle[sender.tag]]?.first?.name ?? ""]
        let isparent = catId?.isEmpty ?? true ? true : self.viewModel.VodDic[self.viewModel.sectionTitle[sender.tag]]?.first?.isParentCategory
        let viewControllerToPush = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(identifier: "viewAll", creator: { coder -> ViewAllViewController? in
            ViewAllViewController(coder: coder, id: catId ?? "", isLastCategory: isparent ?? true ? false : true)
        })
        self.viewModel.catListIds.removeAll()
        self.navigationController?.pushViewController(viewControllerToPush, animated: true)
        
    }
    
}

extension ViewAllViewController: OnDemandCollectionViewCellDelegate {
    func onDemandcollectionView(onDemandCollectionviewcell: OnDemandCollectionViewCell?, index: Int, onDemandTableViewCell: OnDemadTableViewCell) {
        let data = onDemandTableViewCell.models[index]
        
        if data.episodes != nil {
            self.viewAllClicked = true
            if data.episodes!.count > 0 {
                let vc = DetailSeriesViewController.instantiate(vodDetailSeries: viewModel.mapRecommendModelToVODDetailSeries(model: data), detailRecordingModel: nil)
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
               
            }
            else {
                let vodDetail = viewModel.mapRecommendModelToVODDetail(model: onDemandTableViewCell.models[index])
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(DetailViewController.instantiate(vodDetail: vodDetail, detailRecording: nil, detailLive: nil ), animated: true)
                }
            }
            
        }
       
    }
    
}

