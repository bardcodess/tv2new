import UIKit
import ProgressHUD
import LGSideMenuController

protocol HomeViewControllerDelegate: AnyObject {
    func didTapMenuButton()
}

class HomeViewController: BaseController, ViewModelDelegate  {
    
    var didNavigatedToDetail = false
    
    weak var delegate: HomeViewControllerDelegate?
    @IBOutlet var table: UITableView!
    var viewModel  = HomeViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        viewModel.delegate = self
       
        table.register(HomeCollectionTableViewCell.nib(), forCellReuseIdentifier: HomeCollectionTableViewCell.identifier)
        table.delegate = self
        table.dataSource = self
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
    }
    
    func didUpdateRow(didUpdate: Bool) {
        if(didUpdate)
        {
            table.reloadData()
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.viewModel.getHomeData()
    }
    
    
    override func viewDidDisappear(_ animated: Bool) {
        if (!self.didNavigatedToDetail) {
            DispatchQueue.main.async {
                self.viewModel.HomeOrderDic = [:]
                self.viewModel.sectionTitle = []
                self.table.reloadData()
            }
        }
       
    }
    
    @IBAction func menuBtnTapped(_ sender: Any) {
        sideMenuController?.showLeftView(sender: sender)
    }
}

extension HomeViewController : UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.viewModel.sectionTitle.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return self.viewModel.sectionTitle[section]
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = .clear
        let headerLabel = UILabel()
        headerLabel.text = viewModel.sectionTitle[section]
        print(viewModel.sectionTitle[section])
        headerLabel.textColor = UIColor.white
        headerLabel.font = UIFont.boldSystemFont(ofSize: 16)
        
        headerLabel.frame = CGRect(x: 16, y: -10, width: tableView.bounds.size.width - 32, height: 40)
        headerView.addSubview(headerLabel)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        print(self.viewModel.sectionTitle)
        let cell = table.dequeueReusableCell(withIdentifier: HomeCollectionTableViewCell.identifier, for: indexPath) as! HomeCollectionTableViewCell
        switch indexPath.section
        {
        case self.viewModel.sectionTitle.firstIndex(of: "Recent Channel"):
            if(self.viewModel.HomeOrderDic["Recent Channel"] != nil)
            {
                cell.configure(with: self.viewModel.HomeOrderDic["Recent Channel"]!)
                cell.homeCellTapDelegate = self
            }
        case self.viewModel.sectionTitle.firstIndex(of: "Continue Watching (VOD)"):
            if(self.viewModel.HomeOrderDic["Continue Watching (VOD)"] != nil)
            {
                cell.configure(with: self.viewModel.HomeOrderDic["Continue Watching (VOD)"]!)
                cell.homeCellTapDelegate = self
            }
        case self.viewModel.sectionTitle.firstIndex(of: "New Releases (VOD)"):
            if(self.viewModel.HomeOrderDic["New Releases (VOD)"] != nil)
            {
                cell.configure(with: self.viewModel.HomeOrderDic["New Releases (VOD)"]!)
                cell.homeCellTapDelegate = self
            }
            
        case self.viewModel.sectionTitle.firstIndex(of: "New Releases (Rentals)"):
            if(self.viewModel.HomeOrderDic["New Releases (Rentals)"] != nil)
            {
                cell.configure(with: self.viewModel.HomeOrderDic["New Releases (Rentals)"]!)
                cell.homeCellTapDelegate = self
            }
        case self.viewModel.sectionTitle.firstIndex(of: "Recordings"):
            if(self.viewModel.HomeOrderDic["Recordings"] != nil)
            {
                cell.configure(with: self.viewModel.HomeOrderDic["Recordings"]!)
                cell.homeCellTapDelegate = self
            }
        default:
            return HomeCollectionTableViewCell()
            
        }
        ProgressHUD.dismiss()
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let sectionTitle = viewModel.sectionTitle[indexPath.section]
        if(sectionTitle == "Recordings")
        {
            return 160
        }
        return 200.0
    }
    
    
    
    @objc func didTapMenuButton() {
        delegate?.didTapMenuButton()
    }
}

extension HomeViewController: CollectionViewCellDelegate {
    func collectionView(collectionviewcell: HomeCollectionViewCell?, index: Int, didTappedInTableViewCell: HomeCollectionTableViewCell) {
        self.didNavigatedToDetail = true
        if didTappedInTableViewCell.models[index].isAsset {
            if didTappedInTableViewCell.models[index].assetDetails?.episodes == nil || didTappedInTableViewCell.models[index].assetDetails?.episodes?.count == 0 {
                
                let vodDetail = viewModel.mapHomeDataModelToVODDetail(model: didTappedInTableViewCell.models[index])
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(DetailViewController.instantiate(vodDetail: vodDetail, detailRecording:  nil, detailLive: nil), animated: true)
                }
                
            } else {
                let vc = DetailSeriesViewController.instantiate(vodDetailSeries: viewModel.mapHomeDataModelToVODSeriesDetail(model: didTappedInTableViewCell.models[index]), detailRecordingModel: nil)
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            }
        } else {
            if didTappedInTableViewCell.models[index].otherRecordedEpisodes != nil && didTappedInTableViewCell.models[index].otherRecordedEpisodes!.count > 1 {
                let vc = DetailSeriesViewController.instantiate(vodDetailSeries: nil, detailRecordingModel: viewModel.mapToDetailRecordingModelFromHomeDataModel(data: didTappedInTableViewCell.models[index]))
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            } else {
                let vc = DetailViewController.instantiate(vodDetail: nil, detailRecording: viewModel.mapToDetailRecordingModelFromHomeDataModel(data: didTappedInTableViewCell.models[index]), detailLive: nil)
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            }
            
        }
        
        
    }
    
}
