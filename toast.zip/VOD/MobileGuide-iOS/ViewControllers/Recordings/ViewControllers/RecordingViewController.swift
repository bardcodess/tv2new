
import UIKit
import LGSideMenuController


class RecordingViewController: UIViewController {
    
    
    var parentPageViewController: PageViewController!
    @IBOutlet var failBottomView: UIView!
    @IBOutlet var scheduledBottomView: UIView!
    @IBOutlet var recordBottomView: UIView!
    @IBOutlet var pageViewContainer: UIView!
    @IBOutlet var failView: UIView!
    @IBOutlet var stackContainer: UIView!
    
    var currentIndex = 0
    
    let pvc = PageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal)
        var dataSource = [UIViewController]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        prepareTheme()
        dataSource.append(RecordedViewController())
        dataSource.append(ScheduledViewController())
        failView.isHidden = true
        if appDelegate.operatorName == "CCAP" || appDelegate.operatorName == "NWTel" {
            dataSource.append(FailedViewController())
            failView.isHidden = false
            
        }
        prepareUI()
        addBottomBorderWithColor(color: UIColor(red: 59, green: 59, blue: 59), width: 2)
       
    }
    
    
    func addBottomBorderWithColor(color: UIColor, width: CGFloat) {
      let border = CALayer()
        border.backgroundColor = color.cgColor
      border.frame = CGRectMake(0, stackContainer.frame.size.height - width, stackContainer.frame.size.width, width)
      stackContainer.layer.addSublayer(border)
    }
    
    
  private func prepareUI() {
        //pvc.dataSource = self
        pvc.delegate = self
        addChild(pvc)
        pvc.didMove(toParent: self)
        
        pvc.view.translatesAutoresizingMaskIntoConstraints = false
        pageViewContainer.addSubview(pvc.view)
        let views : [String: Any] = ["pageView":pvc.view]
        pageViewContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "H:|-0-[pageView]-0-|", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views))
        
        pageViewContainer.addConstraints(NSLayoutConstraint.constraints(withVisualFormat: "V:|-0-[pageView]-0-|", options: NSLayoutConstraint.FormatOptions(rawValue: 0), metrics: nil, views: views))
        
        
        pvc.setViewControllers([dataSource[0]], direction: .forward, animated: true)
        scheduledBottomView.isHidden = true
        failBottomView.isHidden = true
        failBottomView.isHidden = true
    }
    
    
       private func prepareTheme() {
           let operatorName = appDelegate.operatorName
           switch operatorName {
           case "CCAP":
               failBottomView.backgroundColor = UIColor(hex: Colors.ccapBrandColor.rawValue)
               scheduledBottomView.backgroundColor = UIColor(hex: Colors.ccapBrandColor.rawValue)
               recordBottomView.backgroundColor = UIColor(hex: Colors.ccapBrandColor.rawValue)
           case "NWTel":
               failBottomView.backgroundColor = UIColor(hex: Colors.nwTelBranColor.rawValue)
               scheduledBottomView.backgroundColor = UIColor(hex: Colors.nwTelBranColor.rawValue)
               recordBottomView.backgroundColor = UIColor(hex: Colors.nwTelBranColor.rawValue)
           case  "TBAYTEL":
               failBottomView.backgroundColor = UIColor(hex: Colors.tBayBrandColor.rawValue)
               scheduledBottomView.backgroundColor = UIColor(hex: Colors.tBayBrandColor.rawValue)
               recordBottomView.backgroundColor = UIColor(hex: Colors.tBayBrandColor.rawValue)
           case  "HARGRAY":
               failBottomView.backgroundColor = UIColor(hex: Colors.hargrayBrandColor.rawValue)
               scheduledBottomView.backgroundColor = UIColor(hex: Colors.hargrayBrandColor.rawValue)
               recordBottomView.backgroundColor = UIColor(hex: Colors.hargrayBrandColor.rawValue)
           default:
               print("default")
           }
        }
    
    
  
    
    @IBAction func menutapped(_ sender: Any) {
        
        sideMenuController?.toggleLeftView(sender: sender)
    }
    
    
    
    @IBAction func recordingBtnTapped(_ sender: Any) {
        pvc.setViewControllers([dataSource[0]], direction: .forward, animated: true)
        scheduledBottomView.isHidden = true
        recordBottomView.isHidden = false
        failBottomView.isHidden = true
    }
    
    
    
    @IBAction func scheduleBtnTapped(_ sender: Any) {
        pvc.setViewControllers([dataSource[1]], direction: .forward, animated: true)
        scheduledBottomView.isHidden = false
        recordBottomView.isHidden = true
        failBottomView.isHidden = true
        
    }
    
    
    
    @IBAction func failedBtnTapped(_ sender: Any) {
        pvc.setViewControllers([dataSource[2]], direction: .forward, animated: true)
        scheduledBottomView.isHidden = true
        recordBottomView.isHidden = true
        failBottomView.isHidden = false
    }
    
}


extension RecordingViewController : UIPageViewControllerDelegate {
     
    
        func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
    
            guard let viewController = pageViewController.viewControllers  else {return}
            let viewControllerName = viewController[0].nibName
            switch viewControllerName {
            case "RecordedViewController":
                recordBottomView.isHidden = false
                scheduledBottomView.isHidden = true
                failBottomView.isHidden = true
            case "ScheduledViewController":
                recordBottomView.isHidden = true
                scheduledBottomView.isHidden = false
                failBottomView.isHidden = true
            case "FailedViewController"      :
                recordBottomView.isHidden = true
                scheduledBottomView.isHidden = true
                failBottomView.isHidden = false
            default:
                print("Error")
    
    
            }
    
        }
    
    
}


