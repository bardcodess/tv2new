//
//  ScheduledViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 23/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import ProgressHUD

class ScheduledViewController: UIViewController {

    @IBOutlet var scheduledTableView: UITableView!
    let viewModel = RecordingVM()
    var viewAllTapped = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareViewModelObserver()
        scheduledTableView.delegate = self
        scheduledTableView.dataSource = self
        
        let nib = UINib(nibName: "RecordTableViewCell", bundle: nil)
        self.scheduledTableView.register(nib, forHeaderFooterViewReuseIdentifier: "recordCell")
        
        scheduledTableView.register(UINib(nibName: "OtherRecordedTableViewCell", bundle: nil), forCellReuseIdentifier: "OtherRecordedTableViewCell")
        scheduledTableView.tableHeaderView =
        UIView(frame:
                CGRect(x: 0, y: 0,
                       width: scheduledTableView.frame.width,
                       height: CGFloat.leastNormalMagnitude))
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
        fetchData()
        
    }
    
   
    
    private func fetchData() {
        if appDelegate.operatorName == "CCAP" || appDelegate.operatorName == "NWTel" {
            viewModel.getScheduleRecordingsForNwTelAndCcap(skip: 0, top: 10)
        } else {
            viewModel.getScheduleRecordingsForHargrayAndTbtyel(skip: 0, top: 10)
        }
    }
    
    private func fetchAllData() {
        if appDelegate.operatorName == "CCAP" || appDelegate.operatorName == "NWTel" {
            viewModel.getScheduleRecordingsForNwTelAndCcap(skip: 0, top: 0)
        } else {
            viewModel.getScheduleRecordingsForHargrayAndTbtyel(skip: 0, top: 0)
        }
    }
    
    
    @objc func headerTapped(_ sender: UITapGestureRecognizer?) {
        guard let section = sender?.view?.tag else { return }
        
        if viewModel.schedules?[section].otherScheduledEpisodes?.count == 1 {
            let data = viewModel.schedules?[section].section
            let vc = DetailViewController.instantiate(vodDetail: nil, detailRecording: viewModel.mapExpandeScheduledToDetailRecordings(model: data!, isSeries: data?.seriesDefinitionId == nil ? false : true), detailLive: nil)
            DispatchQueue.main.async {
                self.navigationController?.pushViewController(vc, animated: true)
            }
        } else {
            viewModel.schedules![section].isExpanded = !viewModel.schedules![section].isExpanded
            scheduledTableView.reloadSections([section], with: .automatic)
           // return
        }
    }
    
    func showEmptyScheduledRecordingMessage() {
        Toast.show(message: "No scheduled recordings", controller: self)
    }
    
}

extension ScheduledViewController: UITableViewDelegate, UITableViewDataSource {
  
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if viewModel.schedules![section].isExpanded {
            return viewModel.schedules![section].otherScheduledEpisodes?.count ?? 0
        } else {
            return 0
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "OtherRecordedTableViewCell",for: indexPath) as? OtherRecordedTableViewCell else {return UITableViewCell()}
        cell.configure(with: (viewModel.schedules?[indexPath.section].otherScheduledEpisodes?[indexPath.row])!)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        viewModel.schedules?.count ?? 0
    }
    

    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerview = tableView.dequeueReusableHeaderFooterView(withIdentifier: "recordCell") as? RecordTableViewCell
        headerview?.delegate = self
        headerview?.secIndex = section
        viewModel.schedules![section].isExpanded ?  headerview?.expandButton.setImage(UIImage(named: "up@2x.png"), for: .normal) : headerview?.expandButton.setImage(UIImage(named: "down@2x.png"), for: .normal)
        headerview?.layoutIfNeeded()
        headerview?.configureCellSchedule(with: viewModel.schedules![section])
        
        let tapGestureRecognizer = UITapGestureRecognizer(
             target: self,
             action: #selector(headerTapped(_:))
         )
        
        headerview!.tag = section
        headerview!.addGestureRecognizer(tapGestureRecognizer)
        return headerview
        
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let data = viewModel.schedules?[indexPath.section].otherScheduledEpisodes?[indexPath.row]
        let vc = DetailViewController.instantiate(vodDetail: nil, detailRecording: viewModel.mapExpandeScheduledToDetailRecordings(model: data!, isSeries: data?.seriesDefinitionId != nil ? true : false), detailLive: nil)
        DispatchQueue.main.async {
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    
}





extension ScheduledViewController : HeaderDelegate {
    func callHeader(idx: Int) {
        viewModel.schedules![idx].isExpanded = !viewModel.schedules![idx].isExpanded
        scheduledTableView.reloadSections([idx], with: .automatic)
    }
    
}





extension ScheduledViewController {
    
    
    func prepareViewModelObserver() {
        self.viewModel.scheduleDidChanges = { [weak self] (finished, error) in
            if !error {
                if self?.viewModel.schedules?.count == 0 {
                    DispatchQueue.main.async {
                        self?.showEmptyScheduledRecordingMessage()
                        self?.reloadTableView()
                    }
                } else {
                    DispatchQueue.main.async {
                        self?.reloadTableView()
                    }
                }
            }
        }
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
            
            if  self.viewModel.schedules!.count > 0{
                
                if self.viewModel.schedules!.count == 10  && !self.viewAllTapped{
                    
                    let footer  = RecordedTableFooter(frame: CGRect(x: 0, y: 0, width: self.scheduledTableView.frame.size.width, height: 70))
                    self.scheduledTableView.tableFooterView = footer
                    
                    footer.onButtonClicked = {[weak self] in
                        ProgressHUD.show()
                        self?.fetchAllData()
                        self?.prepareViewModelObserver()
                        self?.viewAllTapped = true
                        self?.scheduledTableView.tableFooterView = UIView()
                    }
                }
                
                self.scheduledTableView.reloadData()
                ProgressHUD.dismiss()
                //self.updateTableFooterViewVisibility()
                //            }
            }
            else {
                ProgressHUD.dismiss()
            }
            
        }
        
    }
    
    
}
