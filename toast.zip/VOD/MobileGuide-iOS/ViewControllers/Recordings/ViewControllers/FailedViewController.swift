//
//  FailedViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 23/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import ProgressHUD

class FailedViewController: UIViewController {
    
    @IBOutlet var FailedTableView: UITableView!
    var viewModel = RecordingVM()

    override func viewDidLoad() {
        super.viewDidLoad()
        prepareViewModelObserver()
        FailedTableView.delegate = self
        FailedTableView.dataSource = self
        FailedTableView.register(UINib(nibName: "FailedRecordingsTableViewCell", bundle: nil), forCellReuseIdentifier: "failedCell")
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
        viewModel.getFailedRecordings()
        // Do any additional setup after loading the view.
    }

   

    
//    override func viewDidDisappear(_ animated: Bool) {
//        viewModel.failedRec = []
//        DispatchQueue.main.async {
//            self.FailedTableView.tableFooterView = UIView()
//            self.FailedTableView.reloadData()
//        }
//    }
    
    
}


extension FailedViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.failedRec?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "failedCell", for: indexPath) as? FailedRecordingsTableViewCell else {
            return UITableViewCell()
        }
        
        cell.configureCell(with: viewModel.failedRec![indexPath.row] )
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return view.frame.size.height/8
        
    }
    
}




extension FailedViewController {

    func prepareViewModelObserver() {
        self.viewModel.failedDidChanges = { (finished, error) in
            if !error {
                self.reloadTableView()
            }
        }
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
            if  self.viewModel.failedRec!.count > 0{
                self.FailedTableView.tableHeaderView = FailedTableHeader(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: 60))
                self.FailedTableView.reloadData()
                ProgressHUD.dismiss()
            } else {
                ProgressHUD.dismiss()
                print("empty")
            }
            
        }
        
        
        //    func updateTableFooterViewVisibility() {
        //        if viewModel.recordings!.isEmpty || viewModel.recordings!.count < 10 {
        //            recordedTableView.tableFooterView = UIView() // Hide default footer view
        //            footerViewObj.isHidden = true // Hide custom footer view
        //        } else if viewModel.recordings!.count == 10  {
        //            recordedTableView.tableFooterView = footerViewObj // Show custom footer view
        //            footerViewObj.isHidden = false // Show custom footer view
        //        }
        //    }
    }
    
}

