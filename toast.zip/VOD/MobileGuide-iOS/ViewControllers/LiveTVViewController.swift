//
//  LiveTVViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import LGSideMenuController

class LiveTVViewController: BaseController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "LIVE TV"
        
        // Do any additional setup after loading the view.
    }

    @IBAction func menuBtnTapped(_ sender: Any) {
        sideMenuController?.showLeftView(sender: sender)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    

}


