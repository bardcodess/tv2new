//
//  BaseNavigationController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 25/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//


import UIKit
/// 📣`BaseController`
/// -  ` Usage ` : -- Base of VC
class BaseController: UIViewController {
    
    // MARK: - ✅ View Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
    
    // MARK: - ✅ Memory MGT
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - ✅ StatusBar
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    override var prefersStatusBarHidden: Bool {
        return false
    }
    
    
}

