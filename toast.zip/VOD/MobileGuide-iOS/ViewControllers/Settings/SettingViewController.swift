//
//  SettingViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 04/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import SwiftUI
import LGSideMenuController

class SettingViewController: BaseController {

    @IBOutlet var settingsTable: UITableView!
    
     enum settingOptions : String, CaseIterable {
        case about = "About"
        case legalAndPrivacy = "Legal and privacy"
        case getSupport = "Get support"
        case parentalControls = "Parental controls"
        case demoPlayer = "Demo player"
        case environment = "Environment"
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Settings"
        settingsTable.dataSource = self
        settingsTable.delegate = self
        settingsTable.register(UINib(nibName: "SettingOptionCellTableViewCell", bundle: nil), forCellReuseIdentifier: "settingCell")
        // Do any additional setup after loading the view.
    }
    
    @IBAction func menuBtnTapped(_ sender: Any) {
        sideMenuController?.showLeftView(sender: sender)
    }
    
    
    
   
 

}

extension SettingViewController : UITableViewDelegate, UITableViewDataSource  {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        settingOptions.allCases.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "settingCell", for: indexPath) as? SettingOptionCellTableViewCell else {return UITableViewCell()}
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.optionLabel.text = settingOptions.allCases[indexPath.row].rawValue
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        60
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let item =  settingOptions.allCases[indexPath.row]
        
        switch item {
        case .about:
            let vc = UIStoryboard(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "AboutViewController") as! AboutViewController
            self.navigationController?.pushViewController(vc, animated: true)
        case .legalAndPrivacy:
            print("environment")
        case .getSupport:
            print("environment")
        case .parentalControls:
            print("environment")
        case .demoPlayer:
            print("environment")
        case .environment:
            print("environment")
        }
    }
}



