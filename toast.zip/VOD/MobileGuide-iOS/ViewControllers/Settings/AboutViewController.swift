//
//  DemoViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 19/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class AboutViewController: BaseController {

    @IBOutlet var aboutTable: UITableView!
    private var viewModel = SettingsVM()
    var countList = [CountList]()
    private let fields = ["User Name","Device Name","Version","IP Address","Network Location","Channel Map"]
    override func viewDidLoad() {
        super.viewDidLoad()
        prepareViewModelObserver()
        aboutTable.delegate = self
        aboutTable.dataSource = self
        aboutTable.register(UINib(nibName: "UserDetailsTableViewCell", bundle: nil), forCellReuseIdentifier: "userDetail")
        
        aboutTable.register(UINib(nibName: "InNetworkTableViewCell", bundle: nil), forCellReuseIdentifier: "inNetwork")
        viewModel.fetchUserDetails()
        let tableFooter = AboutTableSection(frame: CGRect(x: 0, y: 0, width: view.frame.width, height: 400))
        APIManager.shared.getAccountDiagonostics { result in
            switch result {
            case .success(let success):
                self.countList = success.response.countList
                DispatchQueue.main.async {
                    self.aboutTable.tableFooterView = tableFooter
                    tableFooter.configure(with: self.countList)
                }
                
            case .failure(let failure):
                print(failure)
            }
        }

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

extension AboutViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        fields.count
    }
    
  
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "userDetail",for: indexPath) as? UserDetailsTableViewCell else {
                return UITableViewCell()
            }
        
        cell.fields.text = self.fields[indexPath.row]
        cell.fieldValues.text = self.viewModel.aboutSectionDictionay[fields[indexPath.row]]
            return cell
    }
    
    
    
    
    
   
    
    
    
}



extension AboutViewController {
    
    func prepareViewModelObserver() {
        self.viewModel.aboutSectionDictionayDidChanges = { (finished, error) in
            if !error {
                self.reloadTableView()
            }
        }
    }
    
    func reloadTableView() {
        DispatchQueue.main.async {
            self.aboutTable.reloadData()
        }
    }
    
}




