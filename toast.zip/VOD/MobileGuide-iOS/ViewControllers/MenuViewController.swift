//
//  MenuViewController.swift
//  SideMenu
//
//  Created by MA-15 on 13/07/23.
//

import UIKit
import LGSideMenuController

protocol MenuViewControllerDelegate: AnyObject {
    func didSelect(menuItem: MenuViewController.MenuOptions)
}

class MenuViewController: BaseController {
    
    @IBOutlet var sideMenuTable: UITableView!
    
    
    
    weak var delegate: MenuViewControllerDelegate?
    private let appDelegate = UIApplication.shared.delegate as! AppDelegate
    private var operatorImageName : String = ""
   
    
    enum MenuOptions: String, CaseIterable {
        case home = "Home"
        case livetv = "Live TV"
        case recordings = "Recordings"
        case ondemand = "On Demand"
        case downloads = "Downloads"
        case search = "Search"
        case settings = "Settings"
        case logout = "Logout"
        
        var imageName: String {
            switch self {
            case .home:
                return "house"
            case .livetv:
                return "tv"
            case .recordings:
                return "record.circle.fill"
            case .ondemand:
                return "play.fill"
            case .downloads:
                return "arrow.down.circle.fill"
            case .search:
                return "magnifyingglass"
            case .settings:
                return "gearshape.fill"
            case .logout:
                return "arrow.left.square.fill"
            }
        }
    }
    
    
  
   
      
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if SideMenuUtil.shared.getDeviceOrientation().isLandscape {
            sideMenuController?.leftViewWidth = SideMenuUtil.screenWidth/2.5
            sideMenuController?.hideLeftView()
        } else {
            sideMenuController?.leftViewWidth = SideMenuUtil.screenWidth - 60
            sideMenuController?.hideLeftView()
        }
       
    }
 
    
 
    
    let greyColor = UIColor(red: 33/255.0, green: 33/255.0, blue: 33/255.0, alpha: 1)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //view.backgroundColor = .red
        //view.status
      
        sideMenuTable.delegate = self
        sideMenuTable.dataSource = self
        sideMenuTable.register(UINib(nibName: "MenuViewCell", bundle: nil), forCellReuseIdentifier: "MenuViewCell")
        sideMenuTable.register(UINib(nibName: "OperatorImage", bundle: nil), forHeaderFooterViewReuseIdentifier: "OperatorImage")
        setImageForOperator()
       
    }
    
    private func setImageForOperator() {
        switch appDelegate.operatorName {
        case "CCAP":
            operatorImageName = "CCAP_Menu_Logo"
        case "HARGRAY":
            operatorImageName = "Hargray_Menu_Logo"
        case "NWTel":
            operatorImageName =  "NWTel_Menu_Logo"
        case "TBAYTEL":
            operatorImageName = "Tbaytel_Menu_Logo"
        default:
            print("Default")
        }
    }
    
    fileprivate func setVCandClose(vc: UIViewController) {
        let menuVC = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "menu")
        let sideMenuController = LGSideMenuController(rootViewController: vc,leftViewController: menuVC,rightViewController: nil)
        if SideMenuUtil.shared.getDeviceOrientation().isLandscape {
            sideMenuController.leftViewWidth = SideMenuUtil.screenWidth/2.5
        } else if SideMenuUtil.shared.getDeviceOrientation().isPortrait {
            sideMenuController.leftViewWidth = SideMenuUtil.screenWidth - 60
        } else {
            sideMenuController.leftViewWidth = SideMenuUtil.screenWidth - 60
        }
        //sideMenuController.leftViewWidth = SideMenuUtil.screenWidth - 60
        sideMenuController.leftViewPresentationStyle = .slideAbove
        let aNav = UINavigationController(rootViewController: sideMenuController)
        aNav.setNavigationBarHidden(true, animated: false)
        appDelegate.window?.rootViewController = aNav
        
        sideMenuController.hideLeftView()
    }
    
    
}

extension MenuViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        //data.count
        return 1
    }

    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "OperatorImage") as? OperatorImage
        header?.operatorImage.image = UIImage(named: operatorImageName)
        return header
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return MenuOptions.allCases.count
        //    }
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        200
    }
    
//    func numberOfSections(in tableView: UITableView) -> Int {
//        return MenuOptions.allCases.count
//    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "MenuViewCell", for: indexPath) as? MenuViewCell else {
            return UITableViewCell()
        }
        
        cell.menuIconImageView.image = UIImage(systemName: MenuOptions.allCases[indexPath.row].imageName)
        cell.menuLabel.text = MenuOptions.allCases[indexPath.row].rawValue
        cell.menuIconImageView.tintColor = .white
        
       // cell.contentView.backgroundColor = .clear
//        cell.backgroundColor = greyColor
//        cell.contentView.backgroundColor = greyColor
        cell.selectionStyle = .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
      tableView.deselectRow(at: indexPath, animated: true)

        let item = MenuOptions.allCases[indexPath.row]
       // delegate?.didSelect(menuItem: item)
        switch item {
        case .home:
            if appDelegate.currentSideController == "HOME" {
                sideMenuController?.hideLeftView()
                
                return
            } else {
                if let dashboardVC = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "home") as? HomeViewController {
                    setVCandClose(vc: dashboardVC)
                    appDelegate.setCurrentSideController(name: "HOME")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
        case .livetv:
            if appDelegate.currentSideController == "LIVE" {
                sideMenuController?.hideLeftView()
                return
            } else {
                if let liveVc = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "live") as? LiveTVViewController {
                    setVCandClose(vc: liveVc)
                    appDelegate.setCurrentSideController(name: "LIVE")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
        case .recordings:
            if appDelegate.currentSideController == "RECORDING" {
                sideMenuController?.hideLeftView()
                return
            } else {
                if let vodVc = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "recorded") as? RecordingViewController {
                    setVCandClose(vc: vodVc)
                    appDelegate.setCurrentSideController(name: "RECORDING")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
        case .ondemand:
            if appDelegate.currentSideController == "ONDEMAND" {
                sideMenuController?.hideLeftView()
                return
            } else {
                if let vodVc = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "ondemand") as? OnDemandViewController {
                    setVCandClose(vc: vodVc)
                    appDelegate.setCurrentSideController(name: "ONDEMAND")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
        case .downloads:
            if appDelegate.currentSideController == "DOWNLOADS" {
                sideMenuController?.hideLeftView()
                return
            } else {
                if let vodVc = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "downloads") as? DownloadsViewController {
                    setVCandClose(vc: vodVc)
                    appDelegate.setCurrentSideController(name: "DOWNLOADS")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
        case .search:
            if appDelegate.currentSideController == "SEARCH" {
                sideMenuController?.hideLeftView()
                return
            } else {
                if let vodVc = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "search") as? SearchViewController {
                    setVCandClose(vc: vodVc)
                    appDelegate.setCurrentSideController(name: "SEARCH")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
        case .settings:
            if appDelegate.currentSideController == "SETTINGS" {
                sideMenuController?.hideLeftView()
                return
            } else {
                if let vodVc = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "setting") as? SettingViewController {
                    setVCandClose(vc: vodVc)
                    appDelegate.setCurrentSideController(name: "SETTINGS")
                    CoreDataHelper.shared.removeChannelPermissions()
                }
            }
            
        case .logout:
            AlertManager.showLogoutAlert(on: self)
           
        }
    }
    
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 55
    }


    
}
