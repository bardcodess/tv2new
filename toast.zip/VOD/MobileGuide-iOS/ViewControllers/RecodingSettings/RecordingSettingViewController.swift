//
//  RecordingSettingViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 21/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import ProgressHUD

class RecordingSettingViewController: BaseController ,RecordingSettingsProtocol {
    
    
    
    @IBOutlet var recordingSettingTableView: UITableView!
    
    
    var recordingSettings : RecordingSettingsModel?
    var scheduledRecordingData : DetailRecordingsModel?
    var optionsDic = [String:[RecordingSettingsResponse]]()
    var headers = [String]()
    var headersCaseName = [String:String]()
    var settings = RecordingSettings()
    var selectedOptions = [String:Setting]()
    var viewModel: RecordingSettingVM?
    
    
    @IBAction func goBackTappeed(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    deinit {
        viewModel = nil
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
        recordingSettingTableView.dataSource = self
        recordingSettingTableView.delegate = self
        recordingSettingTableView.register(UINib(nibName: "RecordingSettingsHeader", bundle: nil), forHeaderFooterViewReuseIdentifier: "RecordingSettingsHeader")
        recordingSettingTableView.register(UINib(nibName: "RecordingSettingTableViewCell", bundle: nil), forCellReuseIdentifier: "recordingSettingTableCell")
        recordingSettingTableView.isHidden = true
        viewModel?.getSetting()
        viewModel?.headers.bind({ [weak self] _ in
         if self?.viewModel?.headers.value.count ?? 0 > 0 {
             DispatchQueue.main.async {
                 let footerView = self?.scheduledRecordingData?.isProgram ?? false ? RecordingSettingFooterForProgram.instanceFromNib() : RecordingSettingFooterForSeries.instanceFromNib()
                 
                 let fView = UIView(frame: CGRect(x: 0, y: 0, width: Int((self?.recordingSettingTableView.frame.width)!), height: 95))
                 
                 fView.addSubview(footerView)
                 self?.recordingSettingTableView.tableFooterView = fView
                 ProgressHUD.dismiss()
                
                 self?.recordingSettingTableView.reloadData()
                 self?.recordingSettingTableView.isHidden = false
             }
            }
           
           
        })

    }
    
    
    
    override func viewWillLayoutSubviews() {
       super.viewWillLayoutSubviews()
     self.recordingSettingTableView.reloadData()
    }
    
    
    
    
    
    
    
    func didPickerOptionChanged(dataChanged: Setting, idx: Int) {
        viewModel?.headers.bind({ [weak self] _ in
            DispatchQueue.main.async {
                self?.recordingSettingTableView.reloadData()
            }
        })
        viewModel?.selectedValueDidChange(dataChanged: dataChanged, idx: idx)
    
    }
    
    
   
    
    // MARK: - Setting up data
        
    internal static func instantiate(scheduledRecordingData: DetailRecordingsModel ) -> RecordingSettingViewController {
        let vc = UIStoryboard(name: "Home", bundle: nil).instantiateViewController(withIdentifier: "recordingsSettings") as! RecordingSettingViewController
        vc.scheduledRecordingData = scheduledRecordingData
        vc.viewModel = RecordingSettingVM(scheduledRecordingData: vc.scheduledRecordingData)
        return vc
        
    }


}

extension RecordingSettingViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        viewModel?.headers.value.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "RecordingSettingsHeader") as! RecordingSettingsHeader
        let headerTitle = viewModel?.headers.value[section]
    
        header.configure(headerLabel: headerTitle ?? "")
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 60
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        35
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "recordingSettingTableCell", for: indexPath) as! RecordingSettingTableViewCell
        var settingdata = [RecordingSettingsResponse]()
        cell.recordingSettingDelegate = self
        cell.secIdx = indexPath.section
        let headerRawValue = viewModel?.headers.value[indexPath.section] ?? ""
        let headerCaseName = viewModel?.headersCaseName.value[headerRawValue]
        settingdata = viewModel?.optionsDic[headerCaseName!] ?? []
       // let textFieldData = settingdata[0].settings.filter({$0.value == settings.value(forKey: headerCaseName!) as! Int})
        let textfieldString = viewModel?.selectedOptions.value[headerCaseName ?? ""]?.description
      // selectedOptions[headerCaseName!] = textFieldData[0]
        cell.configure(with: settingdata, recordingData: scheduledRecordingData!, userSelectedData: textfieldString ?? "")
        return cell
        
    }
    
     func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return .leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
