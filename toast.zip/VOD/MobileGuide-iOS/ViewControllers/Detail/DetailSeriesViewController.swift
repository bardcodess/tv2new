//
//  VODDetailSeriesViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 16/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class DetailSeriesViewController: BaseController {
    
    
    var homeDataModel : HomeDataModel?
    var vodDetailSeries : VODDetailSeriesModel?
    var detailRecordingModel : DetailRecordingsModel?
    var viewModel = VODDetailSeriesVM()
    
    @IBOutlet var detailSeriesTable: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        detailSeriesTable.delegate = self
        detailSeriesTable.dataSource = self
        
        detailSeriesTable.register(UINib(nibName: "VODImage", bundle: nil), forHeaderFooterViewReuseIdentifier: "VODImage")
        detailSeriesTable.register(UINib(nibName: "VODSeriesTableViewCell", bundle: nil), forCellReuseIdentifier: "vodseriescell")
        detailSeriesTable.register(UINib(nibName: "VODSeasonPicker", bundle: nil), forCellReuseIdentifier: "seasonPicker")
        
        if vodDetailSeries != nil {
            viewModel.setupGroupedSeason(model: vodDetailSeries!)
            viewModel.displaySortedData()
            
            viewModel.seriesBookmark.bind { [weak self] _ in
                DispatchQueue.main.async {
                    self?.detailSeriesTable.reloadSections([2], with: .automatic)
                }
            }
            
            viewModel.fetchBookmarkForSeries(for: vodDetailSeries?.assetDetails?.id ?? "")
        } else {
            viewModel.setUpGroupedSeasonForRecordings(model: detailRecordingModel!)
            viewModel.displaySortedRecordings()
        }
       
    }
    
    
    @IBAction func goBack(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    

    internal static func instantiate( vodDetailSeries: VODDetailSeriesModel?, detailRecordingModel: DetailRecordingsModel? ) -> DetailSeriesViewController{
        let vc = UIStoryboard(name: "Home", bundle: nil).instantiateViewController(withIdentifier: "voddetailseries") as! DetailSeriesViewController
        vc.vodDetailSeries = vodDetailSeries
        vc.detailRecordingModel = detailRecordingModel
        return vc
    }
    
}


