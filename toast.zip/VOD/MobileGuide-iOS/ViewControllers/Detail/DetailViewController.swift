//
//  VODDetailViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 09/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import ProgressHUD

class DetailViewController: BaseController {

    var vodDetail : VODDetailModel?
    var detailRecording: DetailRecordingsModel?
    var detailLive: DetailLiveModel?
    var viewModel = VODDetailVM()
   
   
    @IBOutlet var detailTableVIew: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
        detailTableVIew.delegate = self
        detailTableVIew.dataSource = self
        
        // FOR VOD
        detailTableVIew.register(UINib(nibName: "VODImage", bundle: nil), forHeaderFooterViewReuseIdentifier: "vodImage")
        detailTableVIew.register(UINib(nibName: "VODDescriptionTableViewCell", bundle: nil), forCellReuseIdentifier: "vodDetail")
        detailTableVIew.register(UINib(nibName: "VODProgressTableViewCell", bundle: nil), forCellReuseIdentifier: "vodProgress")
        
        if vodDetail != nil {
            if vodDetail?.isSeries ?? false  {
                viewModel.seriesBookmark.bind { [weak self] _ in
                    DispatchQueue.main.async {
                      
                        ProgressHUD.dismiss()
                        self?.detailTableVIew.reloadData()
                    }
                }
                viewModel.fetchBookmarkForSeries(for: vodDetail?.assetDetails?.id ?? "")
                
            } else {
                viewModel.assetBookmark.bind { [weak self] _ in
                    DispatchQueue.main.async {
                       
                        ProgressHUD.dismiss()
                        self?.detailTableVIew.reloadData()
                    }
                }
                viewModel.fetchBookmarkForAsser(for: vodDetail?.assetId ?? "")
            }
        } else if detailRecording != nil {
            
        } else {
            
            viewModel.showTimes.bind { [weak self] _ in
                DispatchQueue.main.async {
                    self?.detailTableVIew.reloadData()
                }
            }
           
            viewModel.fetchShowTimes(seriesId: detailLive?.seriesId ?? "", callLetter: detailLive?.channelCallLetter ?? "", programId: detailLive?.programId ?? "")
            
            
            let channelPermission  = CoreDataHelper.shared.get(byCallLetter: detailLive?.channelCallLetter ?? "")
            
            if channelPermission != nil {
                dump(channelPermission)
            } else {
                APIManager.shared.getAllChannels { result in
                    switch result {
                    case .success(let success):
                        let preFlightForChannel = success.result.filter({$0.callLetter == self.detailLive?.channelCallLetter ?? ""})
                        let preflight = PreFlightModel(success: true, callLetter: preFlightForChannel.first?.callLetter ?? "", permissions: preFlightForChannel.first?.permissions ?? [], blockCode: preFlightForChannel.first?.blockCode ?? "", startTime: preFlightForChannel.first?.startTime ?? "", endTime: preFlightForChannel.first?.endTime ?? "")
                        CoreDataHelper.shared.savePermissionsForChannel(record: ChannelPermission(channelCallLetter: self.detailLive?.channelCallLetter ?? "", preFlight: preflight ))
                    case .failure(let failure):
                        print(failure)
                    }
                }
            }
        }
      
        // FOR RECORDINGS
        detailTableVIew.register(UINib(nibName: "RecordingActionsTableViewCell", bundle: nil), forCellReuseIdentifier: "recordingActionCell")
        detailTableVIew.register(UINib(nibName: "RecordingDetailTableViewCell", bundle: nil), forCellReuseIdentifier: "recordingDetail")
    
        //FOR LIVE
        detailTableVIew.register(UINib(nibName: "LiveActionTableViewCell", bundle: nil), forCellReuseIdentifier: "liveActionCell")
        detailTableVIew.register(UINib(nibName: "LiveDetailTableViewCell", bundle: nil), forCellReuseIdentifier: "liveDetailCell")
        
    }
    
   
    @IBAction func goBackTappeed(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    // MARK: - Setting up data
        
    internal static func instantiate( vodDetail: VODDetailModel?, detailRecording: DetailRecordingsModel?, detailLive: DetailLiveModel?) -> DetailViewController {
        let vc = UIStoryboard(name: "Home", bundle: nil).instantiateViewController(withIdentifier: "voddetail") as! DetailViewController
        vc.vodDetail = vodDetail
        vc.detailRecording = detailRecording
        vc.detailLive = detailLive
        return vc
    }
    
    
    func createLoadingView(on parent: UIView) -> UIView {
        let loaderview : UIView =  {
            let view = UIView()
            view.backgroundColor = .red.withAlphaComponent(0.2)
            return view
        }()
        loaderview.frame = parent.frame
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
        parent.addSubview(loaderview)
        return loaderview
    }
  
}


