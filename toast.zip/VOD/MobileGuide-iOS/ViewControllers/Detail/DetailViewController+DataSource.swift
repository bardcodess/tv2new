//
//  VODDetailViewController+DataSource.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 31/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
// MARK: - TableView setup

extension DetailViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        2
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 0
        } else {
            return 2
        }
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if  section == 0 {
            let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "vodImage") as! VODImage
            if vodDetail != nil {
                if vodDetail?.isSeries ?? false   {
                    header.configureWithRecommendationModel(with: vodDetail!.assetDetails!, isSeriesView: false )
                } else {
                    header.configure(with: vodDetail! )
                }
            } else if detailRecording != nil {
                header.configureForRecordingItem(model: detailRecording?.iconSrc)
            } else {
                header.configureForLiveItem(model: detailLive?.iconSrc)
            }
           
            return header
        } else {
            return UIView()
        }
    }
    

    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 220
        } else {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section ==  1 {
            if indexPath.row == 0 {
               
                if vodDetail != nil {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "vodProgress", for: indexPath) as! VODProgressTableViewCell
                    if vodDetail?.isSeries ?? false {
                        cell.configureWithRecommendationModel(with: vodDetail!.assetDetails!,assetProgress: viewModel.seriesBookmark.value?.result.bookmarks ?? [])
                    } else {
                        cell.configureWithHomemodel(with: vodDetail!, assetProgress: viewModel.assetBookmark.value ?? nil)
                    }
                    return cell
                } else if detailRecording != nil{
                    let cell = tableView.dequeueReusableCell(withIdentifier: "recordingActionCell", for: indexPath) as! RecordingActionsTableViewCell
                    cell.configure(model: detailRecording!, rootVC: self)
                    return cell
                } else  {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "liveActionCell", for: indexPath) as!
                    LiveActionTableViewCell
                    cell.configure(model: detailLive!)
                    return cell
                }
              
               
                
                
            } else {
               
                if vodDetail != nil {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "vodDetail", for: indexPath) as! VODDescriptionTableViewCell
                    if vodDetail?.isSeries ?? false {
                        cell.configureWithRecommendationModel(with: vodDetail!.assetDetails!)
                    } else {
                        cell.configureWithHomemodel(with: vodDetail!)
                    }
                    return cell
                } else if detailRecording != nil  {
                    
                    let cell = tableView.dequeueReusableCell(withIdentifier: "recordingDetail", for: indexPath) as! RecordingDetailTableViewCell
                    cell.configure(model: detailRecording!)
                    return cell
                } else {
                    let cell = tableView.dequeueReusableCell(withIdentifier: "liveDetailCell", for: indexPath) as! LiveDetailTableViewCell
                    cell.configure(model: detailLive!,showTimes: viewModel.showTimes.value)
                    return cell
                }
            
               
            }
            
            
        } else {
            return UITableViewCell()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 1 {
            if indexPath.row == 0 {
                if vodDetail != nil {
                    return UITableView.automaticDimension
                } else {
                    return 125
                }
            } else {
               return 300
            }
        } else {
            return 0.0
        }
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
