//
//  VODDetailSeriesViewController+Datasource.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 31/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
// MARK: - TableData setup

extension DetailSeriesViewController : UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        3
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if section == 0 {
            return 0
        } else  if section == 1{
            return 1
        } else {
            if vodDetailSeries != nil {
                return viewModel.sortedEpisodes.value.count
            } else {
                return viewModel.sortedRecordings.value.count
            }
        }
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.section == 2 {
            if vodDetailSeries != nil {
                let cell =  tableView.dequeueReusableCell(withIdentifier: "vodseriescell", for: indexPath) as! VODSeriesTableViewCell
                cell.configure(with: viewModel.sortedEpisodes.value[indexPath.row], progressArray: viewModel.seriesBookmark.value?.result.bookmarks ?? [])
                return cell
            } else {
                let cell =  tableView.dequeueReusableCell(withIdentifier: "vodseriescell", for: indexPath) as! VODSeriesTableViewCell
                cell.configureForRecordings(with: viewModel.sortedRecordings.value[indexPath.row])
                return cell
            }
            
        } else if indexPath.section == 1 {
            if vodDetailSeries != nil {
                let cell = tableView.dequeueReusableCell(withIdentifier: "seasonPicker", for: indexPath) as! VODSeasonPicker
                cell.seasonPickerDelegate = self
                cell.configure(title:  vodDetailSeries?.assetDetails?.title ?? "", seasonCount: viewModel.seasons.count, episodeCount: viewModel.episodes, pickerDataSource: viewModel.seasons, userReview: vodDetailSeries?.userReview)
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: "seasonPicker", for: indexPath) as! VODSeasonPicker
                cell.seasonPickerDelegate = self
                cell.configure(title:  detailRecordingModel?.title ?? "", seasonCount: viewModel.seasons.count, episodeCount: viewModel.episodes, pickerDataSource: viewModel.seasons, userReview: nil)
                return cell
            }
            
        } else {
            return UITableViewCell()
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if  section == 0 {
            if vodDetailSeries != nil {
                let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "VODImage") as! VODImage
                header.configureWithRecommendationModel(with: vodDetailSeries!.assetDetails!, isSeriesView: true)
                return header
            } else {
                let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "VODImage") as! VODImage
                header.configureForRecordings(model: detailRecordingModel!)
                return header
            }
            
        } else {
            return UIView()
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return 0
        } else if indexPath.section == 1 {
            return 130
        } else {
            return 140
        }
        
    }
    
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 220
        } else {
            return 0
        }
    }
    
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.section == 2 {
            
            if vodDetailSeries != nil {
                viewModel.sortedEpisodes.value[indexPath.row].id = homeDataModel?.assetDetails?.id
                var vodDetail = VODDetailModel(assetId: vodDetailSeries?.assetDetails?.id ,assetDetails:  viewModel.sortedEpisodes.value[indexPath.row],isSeries: true)
                vodDetail.assetDetails?.id = vodDetailSeries?.assetDetails?.id
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(DetailViewController.instantiate(vodDetail: vodDetail, detailRecording: nil, detailLive: nil), animated: true)
                }
            } else {
                let data = viewModel.sortedRecordings.value[indexPath.row]
                let detailRecording = DetailRecordingsModel(title: data.title, iconSrc: data.iconSrc, userReview: nil, isSeries: true, id: data.id, actualEndUtc: data.actualEndUtc, actualStartUtc: data.actualStartUtc, duration: data.duration, ratings: data.ratings, seasonNumber: data.seasonNumber, episodeNumber: data.episodeNumber, episodeTitle: data.episodeTitle, channelCallLetter: data.channelCallLetter, itemID: data.itemID, shortSummary: data.shortSummary, channelNumber: data.channelNumber, scheduledStartUtc: data.scheduledStartUtc, scheduledEndUtc: data.scheduledEndUtc, episodes: [], isRecordingCompleted: true,keepUntil: data.keepUntil,keepAtMost: data.keepAtMost,startTimeChoice: data.startTimeChoice,showTypeChoice: data.showTypeChoice,channelChoice: data.channelChoice,startRecordingTime: data.startRecordingTime,stopRecordingTime: data.stopRecordingTime, seriesId: data.seriesId, isProgram: data.seriesId == nil && data.episodeId == nil ? true : false, episodeId: data.episodeId)
                
                
                DispatchQueue.main.async { [weak self] in
                    self?.navigationController?.pushViewController(DetailViewController.instantiate(vodDetail: nil, detailRecording: detailRecording, detailLive: nil), animated: true)
                }
            }
            
            
        }
    }
    
}


// MARK: - Season picker

extension DetailSeriesViewController : SeasonPickerProtocol {
    
    func setSeason(season: String) {
        let seasonString = season.replacingOccurrences(of: "Season", with: "").trimmingCharacters(in: .whitespaces)
        viewModel.seasonKey = viewModel.seasons.firstIndex(of: Int(seasonString)!)!
        if vodDetailSeries != nil {
            viewModel.sortedEpisodes.bind { [weak self] _ in
                DispatchQueue.main.async {
                    self?.detailSeriesTable.reloadSections([2], with: .automatic)
                }
            }
            viewModel.displaySortedData()
        } else {
            viewModel.sortedRecordings.bind { [weak self] _ in
                DispatchQueue.main.async {
                    self?.detailSeriesTable.reloadSections([2], with: .automatic)
                }
            }
            viewModel.displaySortedRecordings()
        }
    
    }
    
}
