//
//  ContainerViewController.swift
//  SideMenu
//
//  Created by MA-15 on 13/07/23.
//

import UIKit

class ContainerViewController: BaseController {
    
    enum MenuState {
        case opened
        case closed
    }
    
    private var menuState: MenuState = .closed
    
    let menuVC = MenuViewController()
    let homeVC = HomeViewController()
    var navVC: UINavigationController?
    lazy var recordingsVC = RecordingViewController()
    lazy var onDemandVC = OnDemandViewController()
    lazy var downLoadVC = DownloadsViewController()
    lazy var settingVC = SettingViewController()
    lazy var searchVC = SearchViewController()
    lazy var liveTVVC = LiveTVViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = .red
        
        addChildVCc()
    }
    
    private func addChildVCc() {
        // Menu
        menuVC.delegate = self
        addChild(menuVC)
        view.addSubview(menuVC.view)
        menuVC.didMove(toParent: self)
        
        // Home
        homeVC.delegate = self
        let navVC = UINavigationController(rootViewController: homeVC)
        addChild(navVC)
        view.addSubview(navVC.view)
        navVC.didMove(toParent: self)
        self.navVC = navVC
    }
    
}

extension ContainerViewController: HomeViewControllerDelegate {
    func didTapMenuButton() {
        togleMenu(completion: nil)
        
    }
    
    func togleMenu(completion: (() -> Void)?) {
        // Animate the menu
        switch menuState {
        case .closed:
            // open it
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut) {
                
                self.navVC?.view.frame.origin.x = self.homeVC.view.frame.size.width - 150
                
            } completion: { [weak self] done in
                if done {
                    self?.menuState = .opened
                }
            }
        case .opened:
            //close it
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 0.8, initialSpringVelocity: 0, options: .curveEaseInOut) {
                
                self.navVC?.view.frame.origin.x = 0
                
            } completion: { [weak self] done in
                if done {
                    self?.menuState = .closed
                    DispatchQueue.main.async {
                        completion?()
                    }
                }
            }
        }
    }
}

extension ContainerViewController: MenuViewControllerDelegate {
    func didSelect(menuItem: MenuViewController.MenuOptions) {

        togleMenu(completion: nil)
       // removeChildVC()
        switch menuItem {
        case .home:
            resetToHome()
        case .recordings:
            addRecordings()
        case .ondemand:
            addOnDemand()
            break
        case .downloads:
            addDownload()
            break
        case .settings:
            addSetting()
            break
        case .search:
            addSearch()
        case .logout:
            performLogout()
        case .livetv:
            addLiveTV()
        }
    }

    func removeChildVC(){
        let navArr = homeVC.navigationController?.viewControllers
        
        
        for obj in navArr!{
            obj.removeFromParent()
        }
        //print(homeVC.navigationController?.viewControllers)
    }
    func addRecordings() {
        let vc = recordingsVC
        
        
        homeVC.addChild(vc)
        homeVC.view.addSubview(vc.view)
        vc.view.frame = view.frame
        vc.didMove(toParent: self)
        homeVC.title = vc.title
    }

    func resetToHome() {
        recordingsVC.view.removeFromSuperview()
        recordingsVC.didMove(toParent: nil)
        
        liveTVVC.view.removeFromSuperview()
        liveTVVC.didMove(toParent: nil)
        
        onDemandVC.view.removeFromSuperview()
        onDemandVC.didMove(toParent: nil)
        
        settingVC.view.removeFromSuperview()
        settingVC.didMove(toParent: nil)
        
        searchVC.view.removeFromSuperview()
        searchVC.didMove(toParent: nil)
        
        downLoadVC.view.removeFromSuperview()
        downLoadVC.didMove(toParent: nil)
        
        homeVC.title = "Home"
        
    }

    func addOnDemand() {
        let vc = onDemandVC
        homeVC.addChild(vc)
        homeVC.view.addSubview(vc.view)
        vc.view.frame = view.frame
        vc.didMove(toParent: self)
        homeVC.title = vc.title
    }

    func addDownload() {
        let vc = downLoadVC
        homeVC.addChild(vc)
        homeVC.view.addSubview(vc.view)
        vc.view.frame = view.frame
        vc.didMove(toParent: self)
        homeVC.title = vc.title
    }
    func addSetting(){
        let vc = settingVC
        homeVC.addChild(vc)
        homeVC.view.addSubview(vc.view)
        vc.view.frame = view.frame
        vc.didMove(toParent: self)
        homeVC.title = vc.title
    }
    
    func addSearch(){
        let vc = searchVC
        homeVC.addChild(vc)
        homeVC.view.addSubview(vc.view)
        vc.view.frame = view.frame
        vc.didMove(toParent: self)
        homeVC.title = vc.title
    }
    
    func performLogout() {
        
    }
    
    func addLiveTV() {
        let vc = liveTVVC
        homeVC.addChild(vc)
        homeVC.view.addSubview(vc.view)
        vc.view.frame = view.frame
        vc.didMove(toParent: self)
        homeVC.title = vc.title
    }

}
