//
//  SearchEventViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 05/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class SearchEventViewController: BaseController {
    
    var event: SearchEventModel?
    var programs = [EventProgram]()
    
    
    @IBOutlet var EventTable: UITableView!
    init(event: SearchEventModel? = nil) {
        super.init(nibName: "SearchEventViewController", bundle: nil)
        self.event = event
        
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        EventTable.dataSource = self
        EventTable.delegate = self
        EventTable.register(UINib(nibName: "SearchEventTableViewCell", bundle: nil), forCellReuseIdentifier: "searchEvent")
        filterPurchasedEvent()
        // Do any additional setup after loading the view.
    }
    
    private func filterPurchasedEvent() {
        guard let programs = event?.programs else {
            return
        }
        print(programs)
        self.programs = programs.filter({$0.isPurchased == true})
        DispatchQueue.main.async {
            self.EventTable.reloadData()
        }
    }

}

extension SearchEventViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        programs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "searchEvent", for: indexPath) as! SearchEventTableViewCell
       // cell.textLabel?.text = programs[indexPath.row].title
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.configure(with: programs[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
