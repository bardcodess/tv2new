//
//  SearchRecordingsViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 01/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit


class SearchRecordingsViewController: BaseController {
    
    @IBOutlet var searchRecordingTable: UITableView!
    var recordings: SearchRecordingsModel?
    var viewModel = SearchVM()
    
    init(recordings: SearchRecordingsModel? = nil) {
        super.init(nibName: "SearchRecordingsViewController", bundle: nil)
        self.recordings = recordings
    
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchRecordingTable.dataSource = self
        searchRecordingTable.delegate = self
        searchRecordingTable.register(UINib(nibName: "SearchRecordingTableViewCell", bundle: nil), forCellReuseIdentifier: "searchRecordingCell")
        viewModel.groupedRecordings.bind { [weak self] _  in
            DispatchQueue.main.async {
                self?.searchRecordingTable.reloadData()
            }
        }
        
        viewModel.groupSearchRecordedPrograms(programs: recordings!.response.items)
        
    }
    

}

extension SearchRecordingsViewController :  UITableViewDelegate, UITableViewDataSource{
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        viewModel.groupedRecordings.value.keys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "searchRecordingCell", for: indexPath) as! SearchRecordingTableViewCell
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        let keyArray = Array(viewModel.groupedRecordings.value.keys)
        let key = keyArray[indexPath.row]
        cell.configureCell(with: viewModel.groupedRecordings.value[key]![0] , episodeCount : viewModel.groupedRecordings.value[key]!.count )
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
       
        let keyArray = Array(viewModel.groupedRecordings.value.keys)
        let key = keyArray[indexPath.row]
        if viewModel.groupedRecordings.value[key]!.count > 1 {
            let recordedSeries = viewModel.mapSearchRecordingItemToDetailRecording(programs: viewModel.groupedRecordings.value[key]!)
            let vc = DetailSeriesViewController.instantiate(vodDetailSeries: nil, detailRecordingModel: recordedSeries)
            DispatchQueue.main.async { [weak self] in
              
                self?.navigationController?.pushViewController(vc, animated: true)
            }
        
        } else {
            let recordedAsset = viewModel.mapSearchRecordingItemToDetailRecordings(model: viewModel.groupedRecordings.value[key]!)
            let vc = DetailViewController.instantiate(vodDetail: nil, detailRecording: recordedAsset, detailLive: nil)
            DispatchQueue.main.async { [weak self] in
                self?.navigationController?.pushViewController(vc, animated: true)
            }
        }
//        
//       
    }
}
