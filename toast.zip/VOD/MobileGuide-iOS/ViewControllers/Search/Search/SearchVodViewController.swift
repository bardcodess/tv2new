//
//  SearchVodViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 02/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class SearchVodViewController: BaseController {

    @IBOutlet var searchVodTable: UITableView!
    
    var vod : SearchVodModel?
    var viewModel = SearchVM()
    
    init(vod: SearchVodModel? = nil) {
        super.init(nibName: "SearchVodViewController", bundle: nil)
        self.vod = vod
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchVodTable.delegate = self
        searchVodTable.dataSource = self
        searchVodTable.register(UINib(nibName: "SearchRecordingTableViewCell", bundle: nil), forCellReuseIdentifier: "searchRecordingCell")
    }




}

extension SearchVodViewController : UITableViewDelegate , UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        vod?.programs.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "searchRecordingCell",for: indexPath) as! SearchRecordingTableViewCell
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.configureForVod(with: vod?.programs[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if vod?.programs[indexPath.row].episodes != nil {
            if (vod?.programs[indexPath.row].episodes!.count)! > 0 {
                let vc = DetailSeriesViewController.instantiate(vodDetailSeries: viewModel.mapSearchVODToVodDetailSeries(model: vod?.programs[indexPath.row]) , detailRecordingModel: nil)
                self.navigationController?.pushViewController(vc, animated: true)
           } else {
               let vc = DetailViewController.instantiate(vodDetail: viewModel.mapSearchVODToVODDetail(model: vod?.programs[indexPath.row]), detailRecording: nil, detailLive: nil)
               self.navigationController?.pushViewController(vc, animated: true)

           }
        }
    }
    
    
}
