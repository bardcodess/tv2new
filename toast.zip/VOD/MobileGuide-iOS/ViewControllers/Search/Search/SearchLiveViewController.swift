//
//  SearchLiveViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 01/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class SearchLiveViewController: BaseController {
    
    
    @IBOutlet var searchLiveTable: UITableView!
    var live : SearchLiveModel?
    
    
    init(live: SearchLiveModel? = nil) {
        super.init(nibName: "SearchLiveViewController", bundle: nil)
        self.live = live
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        searchLiveTable.dataSource = self
        searchLiveTable.delegate = self
        searchLiveTable.register(UINib(nibName: "SearchRecordingTableViewCell", bundle: nil), forCellReuseIdentifier: "searchRecordingCell")
        
    }


}

extension SearchLiveViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        live?.programs.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "searchRecordingCell",for: indexPath) as! SearchRecordingTableViewCell
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.configureForLive(with: live?.programs[indexPath.row],channel: live?.channels ?? [])
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let data = live?.programs[indexPath.row]
        let detailLive = DetailLiveModel(ratings: data?.ratings ?? [], start: data?.start, end: data?.end, programTitle: data?.programTitle, iconSrc: data?.iconSrc, seriesId: data?.seriesId, episodeId: data?.episodeId, runtimeMinutes: data?.runtimeMinutes, creationYear: data?.creationYear, duration: data?.duration, originatingCountry: data?.originatingCountry, episodeType: data?.episodeType, rtitle: data?.rtitle, episodeTitle: data?.episodeTitle, description: data?.description, reducedDescription: data?.reducedDescription, programId: data?.programId, channelId: data?.channelId, programChannelId: data?.programChannelId, operatorId: data?.operatorId, channelCallLetter: data?.channelCallLetter, category: data?.category, createdAt: data?.createdAt, id: data?.id, timeshiftEnabled: data?.timeshiftEnabled, timeshiftSettings: data!.timeshiftSettings, channelName: data?.channelName, showRecordForPastProgram: data?.showRecordForPastProgram, isAdultOnly: data?.isAdultOnly, isNewEpisode: data?.isNewEpisode, type: data?.type, score: data?.score)
        let vc = DetailViewController.instantiate(vodDetail: nil, detailRecording: nil,detailLive: detailLive )
        DispatchQueue.main.async {
            
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    

    
    
}
