//
//  SearchViewController.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 09/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import LGSideMenuController
import ProgressHUD
class SearchViewController: BaseController, UITextFieldDelegate {
    
    @IBOutlet var searchTextField: UITextField!{
        didSet {
            searchTextField.tintColor = UIColor.lightGray
            searchTextField.setIcon()
        }
    }
    
    
    @IBOutlet var stackView: UIStackView!
    
    @IBOutlet var stackViewLabel: UILabel!
  
    
    @IBOutlet var tabsCollectionView: UICollectionView!
    
    @IBOutlet var controllerContainer: UIView!
    
    var tabs = [String]()
    var searchRecordings: SearchRecordingsModel?
    var searchLive : SearchLiveModel?
    var searchVod: SearchVodModel?
    var searchEvent: SearchEventModel?
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        if appDelegate.operatorName == "CCAP" || appDelegate.operatorName == "NWTel" {
            stackViewLabel.text = "Search across Live TV, Recordings, On Demand and PPV."
        } else {
            stackViewLabel.text = "Search across Live TV and On Demand."
        }
        
        searchTextField.delegate = self
        tabsCollectionView.dataSource = self
        tabsCollectionView.delegate = self
        tabsCollectionView.register(UINib(nibName: "TabsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "tabs")
        
    }
    
    
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == searchTextField {
            textField.resignFirstResponder()
            guard let textFieldValueAfterRemovingWhiteSpace = searchTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) else {
                return false
            }
            if textFieldValueAfterRemovingWhiteSpace.isEmpty {
                AlertManager.showEmptySearchAlert(on: self)
                return false
            } else {
                stackView.isHidden = true
            }
           
            
            guard let userinput = searchTextField.text else {
              

                return false
            }
            
            if appDelegate.operatorName == "CCAP" || appDelegate.operatorName == "NWTel" {
                getDataForNwtelAndCCAP(for: userinput)
            } else {
                getDataForTbytalAndHargray(for: userinput)
            }
            
            
            
            return false
            
        }
        return true
    }


    
  
    
    
    @IBAction func menuBtnTapped(_ sender: Any) {
        sideMenuController?.showLeftView(sender: sender)
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        tabsCollectionView.reloadData()
    }

   

}

extension SearchViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        tabs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tabs", for: indexPath) as! TabsCollectionViewCell
        cell.tabName.text = tabs[indexPath.row]
        cell.backgroundColor = .clear
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: Int(collectionView.bounds.width) / (tabs.count) , height: 50)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        0
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let tab = tabs[indexPath.row]
        collectionView.scrollToItem(at: indexPath, at: [.centeredVertically, .centeredHorizontally], animated: true)
        
        switch tab {
        case "Live TV":
            removeAllChildren()
            let vc = SearchLiveViewController(live: searchLive)
            add(childViewController: vc, to: controllerContainer)
        case "Recording":
            removeAllChildren()
            let vc = SearchRecordingsViewController(recordings: searchRecordings)
            add(childViewController: vc, to: controllerContainer)
        case "On demand":
            removeAllChildren()
            let vc = SearchVodViewController(vod: searchVod)
            add(childViewController: vc, to: controllerContainer)
        case  "PPV Event":
            removeAllChildren()
            let vc = SearchEventViewController(event: self.searchEvent)
            self.add(childViewController: vc, to: self.controllerContainer)
        default:
            print("default")
        }
       
    }
    
}






// MARK: - Add child View Controller
extension SearchViewController {
    
    
    func add(childViewController viewController: UIViewController, to contentView: UIView) {
        
        let matchParentConstraints = [
            viewController.view.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            viewController.view.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            viewController.view.topAnchor.constraint(equalTo: contentView.topAnchor),
            viewController.view.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ]
        
        addChild(viewController)
        viewController.view.translatesAutoresizingMaskIntoConstraints = false
        contentView.addSubview(viewController.view)
        NSLayoutConstraint.activate(matchParentConstraints)
        viewController.didMove(toParent: self)
        
        viewController.view.alpha = 0
        viewController.view.layoutIfNeeded()
        
        UIView.animate(withDuration: 0.2, delay: 0.1, options: .transitionFlipFromLeft) {
            viewController.view.alpha = 1
           
        }
    }
    
    
    func removeAllChildren() {
        if self.children.count > 0 {
            let childrenVC: [UIViewController] = self.children
            for chlidVC in childrenVC {
                chlidVC.willMove(toParent: nil)
                chlidVC.view.removeFromSuperview()
                chlidVC.removeFromParent()
            }
        }
    }
    
    func getDataForTbytalAndHargray(for key: String) {
        
        
        var tobeEncoded = "\"\(key)\""
        guard let encodedString = tobeEncoded.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) else {
            return
        }
        
        searchRecordings = nil
        searchVod = nil
        searchLive = nil
        tabs.removeAll()
        
        let dispatch = DispatchGroup()
        
        dispatch.enter()
        ProgressHUD.show()
        APIManager.shared.getSearchResultForVOD(for: encodedString) { result in
            switch result {
            case .success(let success):
                self.searchVod = success
                //print(success)
                
            case .failure(let failure):
                print(failure)
            }
            dispatch.leave()
            
        }
        
        dispatch.enter()
        
        APIManager.shared.getSearchResultForLive(for: encodedString) { result in
            switch result {
            case .success(let success):
                self.searchLive = success
                
                
            case .failure(let failure):
                print(failure)
            }
            dispatch.leave()
        }
        
        dispatch.notify(queue: .main) {
            DispatchQueue.main.async {
                ProgressHUD.dismiss()
                
                if self.searchLive != nil {
                    if (self.searchLive?.programs.count)! > 0 {
                        
                        self.tabs.append("Live TV")
                    }
                }
                
                if self.searchVod != nil {
                    if (self.searchVod?.programs.count)! > 0 {
                        self.tabs.append("On demand")
                    }
                }
                
                self.tabsCollectionView.reloadData()
                if self.tabs.count>0 {
                    let selectedIndex = NSIndexPath(item: 0, section: 0) as IndexPath
                    self.tabsCollectionView.selectItem(at: selectedIndex, animated: false, scrollPosition: .centeredHorizontally)
                    switch self.tabs[0] {
                    case "Live TV":
                      
                        let vc = SearchLiveViewController(live: self.searchLive)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    case "Recording":
                      
                        let vc = SearchRecordingsViewController(recordings: self.searchRecordings)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    case "On demand":
                        
                        let vc = SearchVodViewController(vod: self.searchVod)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    case  "PPV Event":
                        print("event")
                    default:
                        print("default")
                    }
                } else {
                    AlertManager.showNoResultOnSearchAlert(on: self)
                    self.removeAllChildren()
                }
               
                
              
                
                
            }
            
        }
    }
    
    func getDataForNwtelAndCCAP(for key: String) {
        
        
        
        var tobeEncoded = "\"\(key)\""
        guard let encodedString = tobeEncoded.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) else {
            return
        }
        
        searchRecordings = nil
        searchVod = nil
        searchLive = nil
        tabs.removeAll()
        
        let dispatch = DispatchGroup()
        
        dispatch.enter()
        ProgressHUD.show()
        APIManager.shared.getSearchResultForRecording(for: encodedString) { result in
            switch result {
            case .success(let success):
                self.searchRecordings = success
                
                
            case .failure(let failure):
                print(failure)
            }
            dispatch.leave()
        }
        
        
        
        
        dispatch.enter()
        
        APIManager.shared.getSearchResultForLive(for: encodedString) { result in
            switch result {
            case .success(let success):
                self.searchLive = success
                
                
            case .failure(let failure):
                print(failure)
            }
            dispatch.leave()
        }
        
        
        
        dispatch.enter()
        
        APIManager.shared.getSearchResultForVOD(for: encodedString) { result in
            switch result {
            case .success(let success):
                self.searchVod = success
                //print(success)
                
            case .failure(let failure):
                print(failure)
            }
            dispatch.leave()
            
        }
        
        dispatch.enter()
        
        APIManager.shared.getSearchResultForEvent(for: encodedString) { result in
            switch result {
            case .success(let success):
                self.searchEvent = success
                print(success)
            case .failure(let failure):
                print(failure)
            }
            dispatch.leave()
            
        }
        
        
        
        
        dispatch.notify(queue: .main) {
            DispatchQueue.main.async {
                ProgressHUD.dismiss()
                
                if self.searchLive != nil {
                    if (self.searchLive?.programs.count)! > 0 {
                        
                        self.tabs.append("Live TV")
                    }
                }
                
                
                if self.searchRecordings != nil {
                    if (self.searchRecordings?.response.items.count)! > 0 {
                        self.tabs.append("Recording")
                    }
                }
                
                if self.searchVod != nil {
                    if (self.searchVod?.programs.count)! > 0 {
                        self.tabs.append("On demand")
                    }
                }
                
                if self.searchEvent != nil {
                    if(self.searchEvent?.programs.count)! > 0 {
                        if((self.searchEvent?.programs.filter({$0.isPurchased == true}).count)! > 0)
                        {
                            self.tabs.append("PPV Event")
                        }
                    }
                    
                }
            
                self.tabsCollectionView.reloadData()
                if self.tabs.count > 0 {
                    let selectedIndex = NSIndexPath(item: 0, section: 0) as IndexPath
                    self.tabsCollectionView.selectItem(at: selectedIndex, animated: false, scrollPosition: .centeredHorizontally)
                    
                    switch self.tabs[0] {
                    case "Live TV":
                       
                        let vc = SearchLiveViewController(live: self.searchLive)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    case "Recording":
                       
                        let vc = SearchRecordingsViewController(recordings: self.searchRecordings)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    case "On demand":
                     
                        let vc = SearchVodViewController(vod: self.searchVod)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    case  "PPV Event":
                        let vc = SearchEventViewController(event: self.searchEvent)
                        self.add(childViewController: vc, to: self.controllerContainer)
                    default:
                        print("default")
                    }
                } else {
                    AlertManager.showNoResultOnSearchAlert(on: self)
                    
                    self.removeAllChildren()
                }
               
               

                
            }
            
        }
        
    }
    
    
}

