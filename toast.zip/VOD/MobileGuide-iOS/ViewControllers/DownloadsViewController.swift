//
//  ShareViewController.swift
//  SideMenu
//
//  Created by MA-15 on 13/07/23.
//

import UIKit
import LGSideMenuController

class DownloadsViewController: BaseController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Downloads"
        view.backgroundColor = UIColor(red: 32, green: 32, blue: 32)
    }
    
    @IBAction func menuBtnTapped(_ sender: Any) {
        sideMenuController?.showLeftView(sender: sender)
    }
    
    
  
}
