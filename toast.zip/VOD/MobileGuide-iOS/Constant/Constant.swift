//
//  Constant.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import Foundation

let appDelegate = UIApplication.shared.delegate as! AppDelegate


enum RecordingStatus {
    case recordingIsInPast
    case recordingIsInPresent
    case recordingIsInFuture
}
