//
//  Colors.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit

enum Colors : String {
    case hargrayBrandColor = "#B40B12"
    case nwTelBranColor =  "#00865D"
    case ccapBrandColor = "#F07D00"
    case tBayBrandColor = "#00AEEF"
    case statusYellow = "#FF9B00"
    case appBG = "#202020"
}
