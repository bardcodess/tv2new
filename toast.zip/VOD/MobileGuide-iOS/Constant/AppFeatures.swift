//
//  AppFeatures.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 28/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation


enum appFeatures: String {
    case RecordingEnabled = "Enable UI Padding Options"
}

 struct AppEnabledFeatures {
    var isRecordingEnabled : Bool
}
