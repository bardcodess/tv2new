//
//  AssetBookmark.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 20/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

// MARK: - Welcome2
struct AssetBookmarkModel : Codable {
    let success: Bool
    let result: AssetBookmarkResult
}

// MARK: - Result
struct AssetBookmarkResult : Codable {
    let bookmark: AssetBookmark
    let asset: Asset
}

// MARK: - Bookmark
struct AssetBookmark : Codable {
    let accountID, vodID: String?
    let assetProgress: Double?
    let lastPosition, createdOn, lastUpdatedOn, id: String?
    let seriesID: String?
    let fullyBookmarked: Bool?
}
