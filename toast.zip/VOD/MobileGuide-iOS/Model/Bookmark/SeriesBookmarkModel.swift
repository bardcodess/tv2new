// This file was generated from JSON Schema using codebeautify, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome8 = try Welcome8(json)

import Foundation

// MARK: - Welcome8
struct SeriesBookmarkModel: Codable {
    let success: Bool
    let result: SeriesBookMarkResult
}

// MARK: - Result
struct SeriesBookMarkResult: Codable {
    let bookmarks: [SeriesBookMark]
    let asset: SeriesAsset
}

// MARK: - Asset
struct SeriesAsset : Codable {
    let title, billingID, assetType, creationDate: String?
    let finishedProcessing: Bool?
    let ingestState: String?
    let isOttAsset, isEvodAsset: Bool?
    let assetDescription, product, provider, providerID: String?
    let year, shortSummary, rating, genre: String?
    let seriesID, showType, runTime, trailerRunTime: String?
    let lastCategoryNames: [String]?
    let licensingWindowEnd, licensingWindowStart, createdOn, lastUpdatedOn: String?
    let ingestionStartDate, ingestionCompleteDate: String?
    let trickRestrictions: [String]?
    let price, maximumViewingLength: Int?
    let assetName, titleBrief, episodeName, country: String?
    let closedCaptioning, language: String?
    let isDownloadAllowed: Bool?
    let downloadExpirationMins, playbackExpirationMins: Int?
    let id: String?
    let categoryIDS, lastCategoryIDS: [String]?
    let episodes: [Episode]?
    let subscriberGroupIDS: [String]?
    let seasonNumber, episodeId: EpisodeID?
    let seriesTitle: String?
}

// MARK: - Episode
struct Episode : Codable {
    let assetID: String?
    let finishedProcessing: Bool?
    let ingestState, billingID, title, creationDate: String?
    let episodeDescription, product, provider, providerID: String?
    let year, shortSummary, rating, genre: String?
    let seasonNumber, episodeId : EpisodeID?
    let episodeName, showType: String?
    let runTime, trailerRunTime, licensingWindowEnd, licensingWindowStart: String?
    let ingestionStartDate, ingestionCompleteDate: String?
    let trickRestrictions: [String]?
    let price: Int?
    let media: [Media]?
    let bifUrls: [BifURL]?
    let assetName, titleBrief, country, closedCaptioning: String?
    let language: String?
    let isDownloadAllowed: Bool?
    let downloadExpirationMins, playbackExpirationMins: Int?
    let seriesId: String?
    let isOttAsset: Bool?
    let maximumViewingLength: Int?
    let assetType, seriesTitle, externalID: String?
    let categoryIDS, lastCategoryIDS: [String]?
    let poster: [String]?
    let lastPosition: String?
    let posters: [Poster]?
}

// MARK: - BifURL
struct BifURL : Codable {
    let resolution: String?
    let url: String?
}



// MARK: - Bookmark
struct SeriesBookMark: Codable {
    let accountId, vodId: String
    let assetProgress: Double?
    let lastPosition, createdOn, lastUpdatedOn, id: String?
    let seriesId: String?
    let fullyBookmarked: Bool?
}

