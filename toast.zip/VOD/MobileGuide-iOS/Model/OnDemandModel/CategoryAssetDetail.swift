import Foundation

// MARK: - Welcome
struct  CategoryAssetDetails: Codable {
    let success: Bool
    let result: [CategoryList]
}
struct  CategoryAssetResponse: Codable {
    let success: Bool
    let result: CategoryList
}

// MARK: - Result
struct CategoryList: Codable {
    let name: String?
    let posterURL: String?
    let finishedProcessing: Bool?
    let footerColor, createdOn, lastUpdatedOn: String?
    let isAdult: Bool?
    let sortName, id, parentId: String?
    let ancestorIds: [String]?
    let level: Int?
    let categoryHierarchy: String?
    let isParentCategory: Bool?
    let subscriberGroupIds: [String]?
    let index: Int?
    let isRootCategory: Bool?
    let assets: [Recommendation]?
    
}
struct Asset: Codable {
    let title, billingID: String?
    let assetType: String?
    let isOttAsset: Bool?
    let isEvodAsset: Bool?
    let description: String?
    let product: String?
    let provider: String?
    let providerID: String?
    let year, shortSummary: String
    let rating: String?
    let seriesID, runTime, trailerRunTime: String?
    let licensingWindowEnd: String?
    let licensingWindowStart: String?
    let trickRestrictions: [String]?
    let price: Double?
    let maximumViewingLength: Int?
    let episodeName: String?
    let isDownloadAllowed: Bool?
    let downloadExpirationMins, playbackExpirationMins: Int?
    let id: String?
    let categoryIds, lastCategoryIds: [String]?
    let episodes: [Recommendation]?
    let assetID: String?
    let poster: [String]?
    let posters: [Poster]?
    let media: [Media]?
    let bifUrls: [BifUrl]?
    let ingestionStartDate: String?
    let userReview: Double?
    let finishedProcessing: Bool?
    let creationDate: String?
    let genre: String?
    let seasonNumber, episodeID : EpisodeID?
    let showType: String?
    let seriesTitle: String?
    let externalId: String?
}

