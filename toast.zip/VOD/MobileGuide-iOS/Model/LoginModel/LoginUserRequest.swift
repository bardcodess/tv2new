//
//  LoginUserRequest.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 06/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct LoginUserRequest {
    let username: String
    let password: String
}
