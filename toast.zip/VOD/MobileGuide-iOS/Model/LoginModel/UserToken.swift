//
//  UserToken.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 06/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct User : Codable {
    let access_token: String
    let expires_in: Int
    let token_type: String
    let refresh_token: String
}
