//
//  ErrorModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 09/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct ErroModel : Decodable {
    let error: String
    let error_description: String
}
