//
//  DetailLive.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation


struct DetailLiveModel {
    let ratings: [Rating]
    let start, end: String?
    let programTitle: String?
    let iconSrc: String?
    let seriesId, episodeId: String?
    let runtimeMinutes: String?
    let creationYear: String?
    let duration: Int?
    let originatingCountry: String?
    let episodeType, rtitle, episodeTitle, description: String?
    let reducedDescription, programId: String?
    let channelId: String?
    let programChannelId: String?
    let operatorId: String?
    let channelCallLetter, category, createdAt, id: String?
    let timeshiftEnabled: Bool?
    let timeshiftSettings: TimeshiftSettings
    let channelName: String?
    let showRecordForPastProgram, isAdultOnly, isNewEpisode: Bool?
    let type: String?
    let score: Int?
}
