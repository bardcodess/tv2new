//
//  showTimeModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation


struct ShowTimeModel : Codable {
    let success: Bool
    let result: [ShowTimeResult]
}

// MARK: - Result
struct ShowTimeResult: Codable {
    let ratings: [Rating]
    let start, end: String?
    let programTitle: String?
    let iconSrc: String?
    let seriesId, episodeId, runtimeMinutes, creationYear: String?
    let duration: Int?
    let originatingCountry, episodeType, rtitle, episodeTitle: String?
    let resultDescription, reducedDescription, channelID, programID: String?
    let resultChannelId: String?
    let operatorId: String?
    let channelCallLetter: String?
    let category: String?
    let createdAt, id: String?
    let timeshiftEnabled: Bool?
    let timeshiftSettings: TimeshiftSettings?
    let channelName: String?
    let showRecordForPastProgram, isAdultOnly, isNewEpisode: Bool?
    let metadata: MetadataForItem?
    let description: String?
    let channelId: String?
}






// MARK: - Metadata
struct MetadataForItem : Codable {
    let episodeNum, seasonNum: String?
}









