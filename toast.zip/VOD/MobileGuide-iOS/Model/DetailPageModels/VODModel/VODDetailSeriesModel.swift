//
//  VODDetailSeriesModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 26/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct VODDetailSeriesModel {
    
    var assetDetails : DetailSeriesModel?
    var userReview : Float?
    
}

struct DetailSeriesModel {
    var id : String?
    let title: String?
    let assetId: String?
    let seasonNumber: EpisodeID?
    let episodeId: EpisodeID?
    let userReview: Float?
    let poster: [String]?
    let posters: [Poster]?
    let year: String?
    let shortSummary: String?
    let rating: String?
    let episodeName: String?
    let licensingWindowEnd: String?
    let runTime: String?
    let episodes: [DetailSeriesModel]?
    
}
