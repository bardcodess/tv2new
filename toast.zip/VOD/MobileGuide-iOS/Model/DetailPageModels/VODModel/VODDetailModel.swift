//
//  VODDetailModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 26/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct VODDetailModel {
    
    var assetId: String?
    var assetDetails: DetailSeriesModel?
    var userReview : Float?
//    let seasonNumber: EpisodeID?
//    let episodeId: EpisodeID?
    var isSeries : Bool
}


