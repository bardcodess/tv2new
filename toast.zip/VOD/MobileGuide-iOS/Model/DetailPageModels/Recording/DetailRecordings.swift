//
//  DetailRecordings.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 31/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation


struct DetailRecordingsModel {
    let title: String?
    let iconSrc: String?
    let userReview: Float?
    let isSeries: Bool
    let id: String?
    let actualEndUtc, actualStartUtc: String?
    let duration: Int?
    let ratings: [Rating]?
    let seasonNumber, episodeNumber : String?
    let episodeTitle: String?
    let channelCallLetter: String?
    let itemID: String?
    let shortSummary: String?
    let channelNumber: Int?
    let scheduledStartUtc: String?
    let scheduledEndUtc: String?
    let episodes: [DetailRecordings]?
    var isRecordingCompleted: Bool
    let keepUntil: String?
    let keepAtMost: Int?
    let startTimeChoice: Int?
    let showTypeChoice: Int?
    let channelChoice: Int?
    let startRecordingTime :  Int?
    let stopRecordingTime : Int?
    let seriesId: String?
    let isProgram: Bool
    let episodeId: String?
    
}










struct DetailRecordings {
    let id: String?
    let title: String?
    let actualEndUtc, actualStartUtc: String?
    let duration: Int?
    let ratings: [Rating]?
    let seasonNumber, episodeNumber : String?
    let episodeTitle: String?
    let iconSrc: String?
    let channelCallLetter: String?
    let itemID: String?
    let shortSummary: String?
    let channelNumber: Int?
    let scheduledStartUtc: String?
    let scheduledEndUtc: String?
    let keepUntil: String?
    let keepAtMost: Int?
    let startTimeChoice: Int?
    let showTypeChoice: Int?
    let channelChoice: Int?
    let startRecordingTime :  Int?
    let stopRecordingTime : Int?
    let seriesId: String?
    let episodeId: String?
    let isProgram: Bool
}


class RecordingSettings : NSObject {
    @objc dynamic  var keepUntil: Int
    @objc dynamic var keepAtMost: Int
    @objc dynamic var startTimeChoice: Int
    @objc dynamic  var showTypeChoice: Int
    @objc dynamic  var channelChoice: Int
    @objc dynamic  var startRecordingTime :  Int//no hargray and tbt
    @objc dynamic  var stopRecordingTime : Int//no hargray and tbt
    
    
    override init() {
        self.keepUntil = 0
        self.keepAtMost = 0
        self.startTimeChoice = 0
        self.showTypeChoice = 0
        self.channelChoice = 0
        self.startRecordingTime = 0
        self.stopRecordingTime = 0
    }
}

