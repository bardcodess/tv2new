//
//  AccountDiagosticsModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 22/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct AccountDiagosticsModel: Codable {
    let success: Bool
    let response: ResponseDiagonstics
}

struct ResponseDiagonstics: Codable {
    let outOfNetworkDeviceCount, inNetworkDeviceCount, deviceLimit, outOfNetworkDeviceLimit: Int
    let allowedStreamingDevices, totalStreamingDeviceCount: Int
    let countList: [CountList]
}


struct CountList: Codable {
    let text, value: String
    let indent: Int?
}
