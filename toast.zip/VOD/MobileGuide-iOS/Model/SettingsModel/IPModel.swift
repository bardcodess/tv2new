//
//  IPModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 21/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct IPModel: Codable {
    let success: Bool
    let response: String
}
