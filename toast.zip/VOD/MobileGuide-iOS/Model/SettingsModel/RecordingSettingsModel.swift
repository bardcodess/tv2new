//
//  RecordingSettingsModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 21/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation


struct RecordingSettingsModel: Codable {
    let success: Bool
    let response: [RecordingSettingsResponse]
}

// MARK: - Response
struct RecordingSettingsResponse : Codable {
    let type: String
    let settings: [Setting]
}

// MARK: - Setting
struct Setting : Codable {
    let value: Int
    let text, description: String
}
