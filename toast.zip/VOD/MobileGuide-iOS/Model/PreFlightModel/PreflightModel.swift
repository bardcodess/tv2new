//
//  PreflightModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

 class PreFlightModel  {
    
    public static var supportsSecureCoding = true
    
  
    var success : Bool
    var callLetter: String
    var permissions: [String]
    var blockCode: String?
    var startTime: String
    var endTime: String
    
    init(success: Bool, callLetter: String, permissions: [String], blockCode: String?, startTime: String, endTime: String) {
        self.success = success
        self.callLetter = callLetter
        self.permissions = permissions
        self.blockCode = blockCode
        self.startTime = startTime
        self.endTime = endTime
    }
    
     

}
