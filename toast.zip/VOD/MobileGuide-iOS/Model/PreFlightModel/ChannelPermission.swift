//
//  PreflightModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

 class ChannelPermission{
  
     var channelCallLetter: String
     var preflight: PreFlightModel
     
     init(channelCallLetter: String,preFlight: PreFlightModel) {
         self.channelCallLetter = channelCallLetter
         self.preflight = preFlight
     }
}

