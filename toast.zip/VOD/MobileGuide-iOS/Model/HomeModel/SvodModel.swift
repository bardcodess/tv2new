import Foundation
struct Recommendation: Codable {
    let title: String?
    let assetId: String?
    let billingId: String?
    let assetType: String?
    let creationDate: String?
    let finishedProcessing: Bool?
    let ingestState: String?
    let isOttAsset: Bool?
    let isEvodAsset: Bool?
    let description: String?
    let product: String?
    let provider: String?
    let providerId: String?
    let year: String?
    let shortSummary: String?
    let rating: String?
    let genre: String?
    let seriesId: String?
    let showType: String?
    let poster: [String]?
    let posters: [Poster]?
    let media: [Media]?
    let bifUrls: [BifUrl]?
    let runTime: String?
    let trailerRunTime: String?
    let lastCategoryNames: [String]?
    let licensingWindowEnd: String?
    let licensingWindowStart: String?
    let createdOn: String?
    let lastUpdatedOn: String?
    let ingestionStartDate: String?
    let ingestionCompleteDate: String?
    let trickRestrictions: [String]?
    let price: Double?
    let maximumViewingLength: Int?
    let assetName: String?
    let titleBrief: String?
    let episodeName: String?
    let country: String?
    let closedCaptioning: String?
    let language: String?
    let isDownloadAllowed: Bool?
    let downloadExpirationMins: Int?
    let playbackExpirationMins: Int?
    var id: String?
    let categoryIds: [String]?
    let lastCategoryIds: [String]?
    let episodes: [Recommendation]?
    let subscriberGroupIds: [String]?
    let seasonNumber: EpisodeID?
    let episodeId: EpisodeID?
    let isAdultOnly: Bool?
    let userReview: Float?
    
}

struct Poster: Codable {
    let posterUrl: String
    let posterType: String
}

struct Media: Codable {
    let streamType: String
    let streamUrl: String
}

struct BifUrl: Codable {
    let resolution: String
    let url: String
}

struct AssetList: Codable {
    let Recommendations: [Recommendation]
}

struct RecommendationsResponse: Codable {
    let success: Bool
    let response: AssetList
}

struct RecommendationFeed: Codable {
    let userId: [String]?
    let name: String?
    let noContentMessage: String?
    let noContentLink: String?
    let refreshInternal: Int?
    let order: String?
    let type: String?
    let localClassName: String?
    let contentType: String?
    let id: String?
}

struct RecommendationsFeedResponseList: Codable {
    let Recommendationfeeds: [RecommendationFeed]
    enum CodingKeys: String, CodingKey {
        case Recommendationfeeds = "Recommendation feeds"
    }
}

struct RecommendationsFeedResponse: Codable {
    let success: Bool
    let response: RecommendationsFeedResponseList
}


