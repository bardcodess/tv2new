import Foundation

struct HomeDataModel {
    var id: String?
    var recentWatchedTime: String?
    var channelId: String?
    var channel : String?
    var programId: String?
    var programName: String?
    var channelNumber: Int?
    var callLetters: String?
    var channelLogoURL: String?

    var ppvStart: String
    var ppvEnd: String
    var blockCode: String
    var pauseEnabled: Bool
    var isAPIWithBlockCode: Bool
    var multicastAbrEnabled: Bool
    var assetId: String?
    var placeHolderImage: String
    var recordingId: String
    var showDetailsPage: Bool
    var isAsset: Bool
    var isPPV: Bool
    var assetDetails: Recommendation?
    var shouldDisplayBanner: Bool
    var shouldDisplayPlayBadge: Bool
    var shouldDisplayPurchasedTag: Bool 
    var isSeriesIndicator: Bool
    var ratings: [Rating]?
    var assetPermission: AssetPermission?
    var posterHeight: String
    var userReview : Float?
    let seasonNumber: EpisodeID?
    let episodeId: EpisodeID?
    let recordedItem: RecordingsItems?
    var otherRecordedEpisodes: [RecordingsItems]?
    var isRecordedAsset: Bool
}

struct AssetPermission: Codable {
    var success: Bool
    var permissions: [String]
    var bookmarkDetails: BookmarkDetails
    var outOfLocation: Bool
    var message: String
    var startTime: Date
    var endTime: Date
}

struct BookmarkDetails: Codable {
    var bookmark: Bookmark
}

struct VODPreflightModel: Codable {
    var permissions: [String]
    var message: String
    var startTime: Date
    var endTime: Date
}

struct Bookmark: Codable {
    let accountID, vodID: String?
    let assetProgress: Double?
    let lastPosition, createdOn, lastUpdatedOn, id: String?
    let seriesId: String?
    let fullyBookmarked: Bool?
}

struct SVODBookmarkModel: Codable {
    var bookmarks: [Bookmark]
}


enum EpisodeID: Codable {
    case integer(Int)
    case string(String)
        
    var stringValue: String? {
        switch self {
        case .string(let s):
            return s
        case .integer(_):
            return ""
        }
     }
    
   

    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let x = try? container.decode(Int.self) {
            self = .integer(x)
            return
        }
        if let x = try? container.decode(String.self) {
            self = .string(x)
            return
        }
        throw DecodingError.typeMismatch(EpisodeID.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for EpisodeID"))
    }

    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .integer(let x):
            try container.encode(x)
        case .string(let x):
            try container.encode(x)
        }
    }
}
