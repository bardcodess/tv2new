import Foundation

// MARK: - Welcome
struct RecordingResponse: Codable {
    let success: Bool
    let response: RecordingsList
}

// MARK: - Response
struct RecordingsList: Codable {
//    let startIndex: Int
//    let timestamp: String
//    let totalCount: Int
    let items: [RecordingsItems]
//    let postProcessingBuffer: Int
//    let displayRecordingAvailabilityMessage, displayRecordedProgramDuration: Bool
//    let maximumAge: Int
}

// MARK: - Item
struct RecordingsItems: Codable {
    let id, showingID: String?
    let episodeId: String?
    let channelID, start, end, state: String?
    let ratings: [Rating]?
    let channelCallLetter: String?
    let iconSrc: String?
    let duration: Int?
//    let programID: String
    let title: String?
    let description, shortDescription, seriesId: String?
    let episodeTitle: String?
//    let isSharedCopy: Bool
//    let channelEpgID, programEpgID: String
//    let seriesEpgID: String?
//    let conflicts: String?
   let scheduledStartUtc, scheduledEndUtc: String?
//    let isRecordingInstructionAlreadySent: Bool?
      let channelNumber: Int?
//    let recordIconStartTime: String?
//    let recordIconStartPadding: Int?
   let seasonNumber, episodeNumber: EpisodeID?
//    let parentSeriesID: JSONNull?
//    let isAdultOnly, isPPVEvent: Bool
//    let createdAt, updatedAt: String?
    let seriesDefinitionId, itemId: String?
    let keepAtMost/* showTypeChoice, startTimeChoice, channelChoice*/: Int?
//    let seriesEXTID: String?
    let keepUntil: String?
//    let hardEndPadding, hardStartPadding: Int
//    let isConflicted: Bool?
//    let isManual: Bool
//    let priority: Int?
    let channel: String?
//    let programEXTID: String?
//    let showType: String?
//    let isAdultLocked, isRatingsLocked: Bool
//    let isHD: String?
//    let isEpisode: Bool
//    let stationEXTID: String?
//    let stationID: String?
//    let roles: [String]?
//    let storageLocation: String?
//    let channelLogoURL: String
//    let programratings: String?
//    let stationCallLetters: String?
//    let fake: Bool?
   let actualEndUtc, actualStartUtc, keepUntilDate: String?
//    let softEndPadding, softStartPadding: Int?
//    let stopReason: String?
//    let cloudPlayRights: String?
//    let playbackData, stationType, releaseYear, cloudRecorderName: JSONNull?
//    let cloudStartTimeOffset: JSONNull?
    let otherRecordedEpisodes: [RecordingsItems]?
//    let status: Int
//    let smilFilePath: String?
//    let isCurrentlyRecording: Bool
//    let url: String
//    let cdvrStreams: [String]?
//    let homeID: String?
//    let size: String?
//    let hour: Int?
//    let programRatings: [Rating]?
//    let accounts: String?
//
//    enum CodingKeys: String, CodingKey {
//        case id = "_id"
//        case showingID = "showingId"
//        case episodeID = "episodeId"
//        case channelID = "channelId"
//        case start, end, state, ratings, channelCallLetter, programTitle, iconSrc, duration
//        case programID = "programId"
//        case title, description, shortDescription
//        case seriesID = "seriesId"
//        case episodeTitle, isSharedCopy
//        case channelEpgID = "channelEpgId"
//        case programEpgID = "programEpgId"
//        case seriesEpgID = "seriesEpgId"
//        case conflicts
//        case scheduledStartUTC = "scheduledStartUtc"
//        case scheduledEndUTC = "scheduledEndUtc"
//        case isRecordingInstructionAlreadySent, channelNumber, recordIconStartTime, recordIconStartPadding, seasonNumber, episodeNumber
//        case parentSeriesID = "parentSeriesId"
//        case isAdultOnly, isPPVEvent, createdAt, updatedAt
//        case seriesDefinitionID = "seriesDefinitionId"
//        case itemID = "id"
//        case keepAtMost, showTypeChoice, startTimeChoice, channelChoice
//        case seriesEXTID = "seriesExtId"
//        case keepUntil, hardEndPadding, hardStartPadding, isConflicted, isManual, priority, channel
//        case programEXTID = "programExtId"
//        case showType, isAdultLocked, isRatingsLocked, isHD, isEpisode
//        case stationEXTID = "stationExtId"
//        case stationID = "stationId"
//        case roles, storageLocation
//        case channelLogoURL = "channelLogoUrl"
//        case programratings, stationCallLetters, fake
//        case actualEndUTC = "actualEndUtc"
//        case actualStartUTC = "actualStartUtc"
//        case keepUntilDate, softEndPadding, softStartPadding, stopReason, cloudPlayRights, playbackData, stationType, releaseYear, cloudRecorderName, cloudStartTimeOffset, otherRecordedEpisodes, status, smilFilePath, isCurrentlyRecording, url, cdvrStreams
//        case homeID = "homeId"
//        case size, hour, programRatings, accounts
    }


