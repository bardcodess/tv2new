
// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let recordedShows = try? JSONDecoder().decode(RecordedShows.self, from: jsonData)

import Foundation

// MARK: - RecordedShows
struct FailedRecordings: Codable {
    let success: Bool
    let response: ResponseForFailedRecordings
}

// MARK: - Response
struct ResponseForFailedRecordings: Codable {
    let startIndex: Int
    let timestamp: String
    let totalCount: Int
    let items: [ItemFailedRecording]
}

// MARK: - Item
struct ItemFailedRecording: Codable {
    let id, showingID: String?
    //let accounts: Accounts
    let cDVRRecorderName, cDVRStartTimeOffset: String?
    let channelCallLetter, channelEpgID, channelID: String?
    let conflicts: String?
    let description: String?
    let duration: Int?
    let end: String?
    let episodeID, episodeTitle: String?
    let iconSrc: String?
    let isSharedCopy, programEpgID, programID, programTitle: String?
    let ratings: [Rating]?
    let seriesEpgID, seriesID, shortDescription, start: String?
    let state, title, failReason: String?

}




