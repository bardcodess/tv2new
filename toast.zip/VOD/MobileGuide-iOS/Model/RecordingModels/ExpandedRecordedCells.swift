//
//  ExpandedCells.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 23/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class ExpandedRecordedCells {
    var isExpanded = false
    let section : Item
    var otherRecordedItems: [Item]?
    
    init(section: Item, otherRecordedItems: [Item]?) {
        self.section = section
        self.otherRecordedItems = otherRecordedItems ?? []
        print(section.title)

    }
}
