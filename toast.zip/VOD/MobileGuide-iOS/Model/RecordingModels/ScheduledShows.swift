// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let recordedShows = try? JSONDecoder().decode(RecordedShows.self, from: jsonData)

import Foundation

// MARK: - RecordedShows
struct ScheduledShows: Codable {
    let success: Bool
    let response: ResponseSchedule
}

// MARK: - Response
struct ResponseSchedule: Codable {
    let startIndex: Int
    let timestamp: String
    let totalCount: Int
    let items: [ItemSchedule]
}

// MARK: - Item
struct ItemSchedule: Codable {
    let id: String
    let size: String?
    let hour: Int?
    let start: String?
    let startUtc: String?
    let actualEndUtc, actualStartUtc: String?
    let duration, hardEndPadding, hardStartPadding: Int
    let isCurrentlyRecording, isManual: Bool
    let keepUntil: String?
    let keepAtMost: Int?
    let channel: String?
    let channelNumber: Int
    let scheduledEndUtc, scheduledStartUtc, seriesDefinitionId: String?
    let programExtId: String
    let programId: String
    let showType: String?
    let stationExtId: String
    let stationId: String?
    let title: String
    let ratings: [Rating]?
    let isAdultLocked, isRatingsLocked: Bool
    let isHD: String?
    let isEpisode: Bool
    let description, shortDescription: String?
    let seriesExtId: String?
    let seriesId: String?
    let seasonNumber, episodeNumber, episodeTitle: String?
    let showingId: String?
    let storageLocation: String?
    let isSharedCopy: Bool?
    let cloudRecorderName, cloudStartTimeOffset: String?
    let stationType, releaseYear, cloudPlayRights, playbackData: String?
    let channelEpgId, programEpgId: String
    let seriesEpgId: String?
    let iconSrc: String
    let channelCallLetter: String?
    let channelLogoURL: String?
    let parentSeriesId: String?
    let isPPVEvent, isAdultOnly: Bool?
    let otherScheduledEpisodes: [ItemSchedule]?
    let status: Int?
    let startTimeChoice: Int?
    let showTypeChoice: Int?
    let channelChoice: Int?
    let episodeId: String?
    

}







 












