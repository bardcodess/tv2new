//
//  ExpandedScheduledCells.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 23/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
class ExpandedScheduledCells {
    var isExpanded = false
    let section : ItemSchedule
    let otherScheduledEpisodes: [ItemSchedule]?
    
    init(section: ItemSchedule, otherScheduledEpisodes: [ItemSchedule]?) {
        self.section = section
        self.otherScheduledEpisodes = otherScheduledEpisodes
    }
}
