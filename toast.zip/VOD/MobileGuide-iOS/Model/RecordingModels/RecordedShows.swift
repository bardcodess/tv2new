// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let recordedShows = try? JSONDecoder().decode(RecordedShows.self, from: jsonData)

import Foundation

// MARK: - RecordedShows
struct RecordedShows: Codable {
    let success: Bool
    let response: Response
}

// MARK: - Response
struct Response: Codable {
    let startIndex: Int
    let timestamp: String
    let totalCount: Int
    let items: [Item]
   // let postProcessingBuffer: Int
    let displayRecordingAvailabilityMessage, displayRecordedProgramDuration: Bool
    let maximumAge: Int
}

// MARK: - Item
struct Item: Codable {
    
    let id: String
   // let homeId: String
    let size: String?
    let hour: Int?
    let actualEndUtc, actualStartUtc: String?
    let duration, hardEndPadding, hardStartPadding: Int
    let isCurrentlyRecording, isManual: Bool
    //let keepUntil: Int
    let keepUntilDate: String
    let channel: String?
    let channelNumber: Int
    let scheduledEndUtc, scheduledStartUtc, seriesDefinitionId: String?
    let softEndPadding, softStartPadding: Int
    let stopReason: String
    let programExtId: String
    let programId: String
    let showType: String?
    let stationExtId: String
    let stationId: String?
    let title: String
    let ratings: [Rating]?
    let isAdultLocked, isRatingsLocked: Bool
    let isHD: String?
    let isEpisode: Bool
    let description, shortDescription: String?
    let seriesExtId: String?
    let seriesId: String?
    let seasonNumber, episodeNumber, episodeTitle: String?
  //  let roles: String?
    let showingId: String?
    let storageLocation: String?
    let isSharedCopy: Bool?
   // let cloudRecorderName, cloudStartTimeOffset: String?
    let stationCallLetters: String?
    let stationType, releaseYear, playbackData: String?
    let channelEpgId, programEpgId: String
    let seriesEpgId: String?
    let programRatings: [Rating]?
    let iconSrc: String
    let channelCallLetter: String?
    let channelLogoURL: String?
    let parentSeriesId: String?
    //let isPPVEvent, isAdultOnly: Bool
    let otherRecordedEpisodes: [Item]?
    let status: Int?
   // let smilFilePath: String
    let url: String?
    let cdvrStreams: [CDVRStreams]

}



enum Platform: String, Codable {
    case androidTv = "ANDROID-TV"
    case appleTv = "APPLE-TV"
    case chromeWeb = "CHROME-WEB"
    case fireTv = "FIRE-TV"
    case roku = "ROKU"
    case safariWeb = "SAFARI-WEB"
    case xamarinAndroid = "XAMARIN-ANDROID"
    case xamarinIos = "XAMARIN-IOS"
}

struct CDVRStreams : Codable{
    let streamType: String
    let streamUrl: String
    let streamId: String
    let streamEngine: String
    let drmType: String
    let platforms: [Platform]
}

 

// MARK: - Rating
struct Rating: Codable {
    let system: String
    let value: String
}









