

import Foundation


struct SearchLiveModel: Codable {
    let channels: [Channel]
    let programs: [LiveProgram]
    let channelsCount, programsCount: Int?
}

// MARK: - Channel
struct Channel: Codable {
    let callLetter, type: String?
    let channelId: String
    let genre: [String]?
    let channelDescription, name: String?
    let iconSrc: String?
    let pauseEnabled, multicastABREnabled, substitutionEnabled, broadcastEnabled: Bool?
    let staticURL: String?
    let lastUpdatedOn: String?
    let lookBackEnabled: Bool?
    let purpleID: String?
    let streams: [Stream]
    let layers: [String]
    let streamingEngine: String?
    let operatorId: String?
    let operatorName: String?
    let channelNumber: Int
    let id: String?
    let adultContent: Bool?
    let createdOn: String?
}



// MARK: - Stream
struct Stream : Codable {
    let number: Int
    let streamType: String?
    let streamURL: String?
    let streamID: String?
    let drmType: String?
    let streamEngine: String?
    //let platforms: [String]
}


// MARK: - Program
struct LiveProgram: Codable {
    let ratings: [Rating]
    let start, end: String
    let programTitle: String?
    let iconSrc: String?
    let seriesId, episodeId: String?
    let runtimeMinutes: String?
    let creationYear: String?
    let duration: Int?
    let originatingCountry: String?
    let episodeType, rtitle, episodeTitle, description: String?
    let reducedDescription, programId: String?
    let channelId: String?
    let programChannelId: String?
    let operatorId: String?
    let channelCallLetter, category, createdAt, id: String?
    let timeshiftEnabled: Bool?
    let timeshiftSettings: TimeshiftSettings
    let channelName: String?
    let showRecordForPastProgram, isAdultOnly, isNewEpisode: Bool?
    let type: String?
    let score: Int?
}



// MARK: - TimeshiftSettings
struct TimeshiftSettings: Codable {
    let rewind, fastForward, pause, trickSpeed1X: Bool?
    let trickSpeed2X, trickSpeed3X, currentAiring: Bool?
}



