// This file was generated from JSON Schema using codebeautify, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let welcome7 = try Welcome7(json)

import Foundation


struct SearchEventModel: Codable {
    let channels: [EventChannel]
    let programs: [EventProgram]
    let channelsCount, eventsCount: Int?
    let message: String?
    let inAllowedLocationForPPV: Bool?
}

// MARK: - Channel
struct EventChannel: Codable {
    let callLetter: String?
    let channelID, type: String?
    let genre: [String]
    let channelDescription, name: String?
    let iconSrc: String?
    let pauseEnabled, multicastABREnabled, substitutionEnabled, broadcastEnabled: Bool?
    let lastUpdatedOn: String?
    let lookBackEnabled: Bool?
    let id: String?
    let streams: [Stream]
    let layers: [String]
    let operatorID, operatorName: String?
    let createdOn: String?
    let excludedProgramList: [String]?
}





// MARK: - Program
struct EventProgram : Codable{
    let channelID: String?
    let callLetter: String?
    let longName: String?
    let startTime: String?
    let duration: Int?
    let programID: String?
    let ppvPurchaseWindowStart, ppvPurchaseWindowEnd: Int?
    let price: Double?
    let iconSrc: String?
    let currency: String?
    let isPurchased: Bool
    let title: String?
    let programDescription: String?
    let vchipRating, canadaRating: String?
    let createdOn, lastUpdatedOn, endTime: String?
    let ratings: [Rating]
    let allCategories: [AllCategory]
    let isAdultOnly: Bool?
    let showType: String?
    let id: String?
    let isPPVDisabled: Bool?
    let defaultPPVCancelWindowOffsetMinutes: Int?
    let isExpired: Bool?
    let lookbackEndTime: String?
    let type: String?
    let channelCallLetter: String?
    let start: String?
}

// MARK: - AllCategory
struct AllCategory: Codable {
    let mscname: String?
    let value: String?
}





