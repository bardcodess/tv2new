//
//  SearchRecordingsModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 28/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct SearchRecordingsModel: Codable {
    let success: Bool
    let response: SearchRecordingsResponse
}

// MARK: - Response
struct SearchRecordingsResponse : Codable{
    let startIndex: Int
    let timestamp: String
    let totalCount: Int
    let items: [SearchRecordingsItem]
    let postProcessingBuffer: Int
    let displayRecordingAvailabilityMessage, displayRecordedProgramDuration: Bool
    let maximumAge: Int
}

// MARK: - Item
struct SearchRecordingsItem : Codable{
    let id, homeId, size: String?
    let hour: Int?
    let actualEndUtc, actualStartUtc: String?
    let duration, hardEndPadding, hardStartPadding: Int?
    let isCurrentlyRecording, isManual: Bool?
  //  let keepUntil: String?
    let keepUntilDate: String?
    let channel: String?
    let channelNumber: Int?
    let scheduledEndUTC, scheduledStartUTC, seriesDefinitionID: String?
    let softEndPadding, softStartPadding: Int?
    let stopReason, programEXTId, programId: String?
    let showType: String?
    let stationEXTId, stationId, title: String?
    let ratings: [Rating]
    let isAdultLocked, isRatingsLocked: Bool?
    let isHD: String?
    let isEpisode: Bool?
    let itemDescription, shortDescription: String?
    let seriesEXTID, seriesId: String?
    let seasonNumber, episodeNumber : String?
    let episodeTitle: String?
    let roles: [String]?
    let showingID: String?
    let storageLocation: String?
    let isSharedCopy: Bool?
    let cloudRecorderName, cloudStartTimeOffset: String?
    let stationCallLetters: String?
    //let stationType, releaseYear, cloudPlayRights, playbackData: String?
    let channelEpgID, programEpgID: String?
    let seriesEpgID: String?
   // let programRatings: [Rating]
    let iconSrc: String?
    let channelCallLetter: String?
    let channelLogoURL: String?
    let parentSeriesId: String?
    let isPPVEvent, isAdultOnly: Bool?
   // let accounts: String?
    let itemID: String?
    //let programratings: String?
    let status: Int?
    let smilFilePath: String?
    let url: String?
    let cdvrStreams: [CdvrStream]
}



// MARK: - CdvrStream
struct CdvrStream : Codable{
    let streamType: String?
    let streamURL: String?
    let streamID, streamEngine, drmType: String?
    let platforms: [String]
}


