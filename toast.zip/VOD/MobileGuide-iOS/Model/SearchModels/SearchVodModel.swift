//
//  SearchTypeModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

struct SearchVodModel: Codable {
    let channels: [String]
    let programs: [Recommendation]
    let assetsCount: Int?
}

// MARK: - Program
struct Program: Codable {
    let title, billingID: String?
    let assetType: String?
    let ingestState: String?
    let isOttAsset: Bool?
    let isEvodAsset: Bool?
    let programDescription: String?
    let product: String?
    let provider: String?
    let providerID: String?
    let year, shortSummary: String?
    let rating: String?
    let seriesID, runTime, trailerRunTime: String?
    let lastCategoryNames: [String]?
    let licensingWindowEnd, licensingWindowStart: String?
    let ingestionStartDate, ingestionCompleteDate: String?
    let trickRestrictions: [String]?
    let price, maximumViewingLength: Int?
    let assetName, titleBrief, episodeName: String?
    let country: String?
    let closedCaptioning: String?
    let language: String?
    let isDownloadAllowed: Bool?
    let downloadExpirationMins, playbackExpirationMins: Int?
    let id: String?
   // let categoryIds, lastCategoryIds: [String]
    let episodes: [Recommendation]?
    let type: String?
    let start: String?
    let score: Double?
    let assetID: String?
    let poster: [String]?
    let posters: [Poster]?
    let media: [Media]?
    let bifUrls: [BifUrl]?
    let finishedProcessing: Bool?
    let creationDate, genre, seasonNumber, episodeID: String?
    let showType, seriesTitle, externalID: String?
    let userReview: Float?
}


