//
//  AppConfigModel.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 23/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation


struct AppConfigModel: Codable {
    let success: Bool
    let response: AppConfigResponse
}

// MARK: - Response
struct AppConfigResponse: Codable {
    let appConfigurations: AppConfigurations
}

// MARK: - AppConfigurations
struct AppConfigurations: Codable {
    let common: Common
    let specific: Specific
    let platform, appConfigurationsOperator, id: String?
    let features: [Feature]
    let restangularEtag: String?
}

// MARK: - Common
struct Common: Codable {
    let operatorlogo, helptext, privacytext: String?
    let clientRESTURL: String?
    let defaultvideopopuptime, version, homePollingTime, channelPollingTime: Int?
    let featurePollingTime, vodPollingTime: Int?
    let isDVREnabled, isCachingEnabled, defaultTVODGrantActiveOnlyFlag: Bool?
    let assetURL: String?
    let parentalControlRelockTimeInMinutes, assetExpirationDeleteHours: Int?
    let trickRestrictionsEnum: [TrickRestrictionsEnum]
    let androidTvMinimumAllowedVersion: String?
    let blankChannelJumpCount: Int?
    let channelMap, accountHomeID: String?
    let isParentalControlPinSet, isRentalPinSet: Bool?
    let ppvNotificationDisplayWindow, toastNotificationIntervalSeconds: Int?
}

// MARK: - TrickRestrictionsEnum
struct TrickRestrictionsEnum: Codable{
    let key: String?
    let values: [String]?
}

// MARK: - Feature
struct Feature: Codable {
    let featureID: String?
    let status: Bool?
    let name: String?
    let level: String?
}



// MARK: - Specific
struct Specific: Codable {
    let operatorIcon, onDemandDefaultCategoryImagePath, headerTextAttribute, normalTextAttribute: String?
    let headerFontSize, normalFontSize, pageFontSize, primaryColor: String?
    let primaryDark, accent, lightBackgroundColor, darkBackgroundColor: String?
    let mediumGrayTextColor, lightTextColor, menuBaseColor, menuHightlightedColor: String?
    let barTextColor, barBackgroundColor, searchBackgroundColor, iosSearchColor: String?
    let androidSearchColor, cellBackgroundColor, normalTextColor, pageBackgroundColor: String?
    let stackBackgroundColor, recordingsCellBackgroundColor, dateBackgroundColor, tabBackgroundColor: String?
    let tabIndicatorColor, gridLineColor, programBackgroundColor, activeProgramBackgroundColor: String?
    let menuBackgroundColor: String?
    let version: Int?
}
