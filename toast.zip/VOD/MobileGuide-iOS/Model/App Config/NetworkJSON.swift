// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let networkJSON = try? JSONDecoder().decode(NetworkJSON.self, from: jsonData)

import Foundation

// MARK: - NetworkJSON
struct NetworkJSON: Codable {
    let nwTel, ccap, tbaytel, hargray: Ccap

    enum CodingKeys: String, CodingKey {
        case nwTel = "NWTel"
        case ccap = "CCAP"
        case tbaytel = "TBAYTEL"
        case hargray = "HARGRAY"
    }
}

// MARK: - Ccap
struct Ccap: Codable {
    let productionURL, developmentURL, stagingURL, productionBaseURL: String
    let developmentBaseURL, stagingBaseURL, logoURL: String
    let logoExtension, clientID, scope: String
    let baseURL, authorizeURL, issuerURL, certURL: String
    let logTag, redirectURLQuery, responseType, clientSecret: String
    let accessTokenURL: String
    let testIPAddress, vsspBaseAddress: String
    let prodHpnrURL, stagHpnrURL: String
    let isDevBuild, expiryDate, calendarDate, releaseDate: String
    let disableExpirationCheck: String
    let streamProxyHost: String
    let manifestProxyBaseURL: String
    let patchPosterByURL: String
    let fetchPosterByURL: String
    let supportPageURL, chatPageURL: String
    let nwTelSupportDeskNumber: String
    let termsAndConditionsURL: String
    let currentPlayerType, assetorProgramID, defaultKongEnvironment, multicastGeolocation: String
    let enableOnDemandFeature: String
    let unlockedID: [JSONAny]
    let streamRetuneTimeMS, retuneRetryMaxCount, dialogAutoHideDurationMS, vpForwardDurationSEC: Int
    let vpRewindDurationSEC, epgLastDay, waitCompleteMilliseconds, diagIntervalMilliseconds: Int
    let streamProxyPort, maxDownloadLimit, coorsPostProcessingTimeInMilliseconds, updateEpgDataTimeLimitInMilliseconds: Int
    let maxResponseContentBufferSize, logoRefreshDuration, durationAppStatUpdateCycleInMilliseconds: Int
    let isNonceNeeded, shouldRemovePort, isFairPlayEnable, isDRMEnableForDownloadedContent: Bool
    let shouldShowCurrentPosition, enableKongEnvironment, enablePrivacyPage, enableEnvironmentSelection: Bool
    let enableRestartSVODAndDVR, vsPlaying, disableVideoPlayBack, disableHideUnsubscribeBetaFeature: Bool
    let isDeviceActive, isLogosUpdated, isParentalControlEnabled, isStreamingDiagnosticOverlayEnabled: Bool
    let checkForDeviceLimitReached, isVODWidevineDRMEnabled, isMediaRoomAccount, useNewVODAPIs: Bool
    let isHPNREnabled, useProtobufForPacket, packetIsBigEndian, disablePermissionCheck: Bool
    let operatorThemeColor, operatorFontName: String

    enum CodingKeys: String, CodingKey {
        case productionURL = "PRODUCTION_URL"
        case developmentURL = "DEVELOPMENT_URL"
        case stagingURL = "STAGING_URL"
        case productionBaseURL = "PRODUCTION_BASE_URL"
        case developmentBaseURL = "DEVELOPMENT_BASE_URL"
        case stagingBaseURL = "STAGING_BASE_URL"
        case logoURL = "LogoUrl"
        case logoExtension = "LogoExtension"
        case clientID = "ClientId"
        case scope = "Scope"
        case baseURL = "BaseUrl"
        case authorizeURL = "AuthorizeUrl"
        case issuerURL = "IssuerUrl"
        case certURL = "CertUrl"
        case logTag = "LogTag"
        case redirectURLQuery = "RedirectUrlQuery"
        case responseType = "ResponseType"
        case clientSecret = "ClientSecret"
        case accessTokenURL = "AccessTokenURL"
        case testIPAddress = "TestIPAddress"
        case vsspBaseAddress = "VSSPBaseAddress"
        case prodHpnrURL = "PROD_HPNR_URL"
        case stagHpnrURL = "STAG_HPNR_URL"
        case isDevBuild = "IsDevBuild"
        case expiryDate = "ExpiryDate"
        case calendarDate = "CalendarDate"
        case releaseDate = "ReleaseDate"
        case disableExpirationCheck = "DisableExpirationCheck"
        case streamProxyHost = "StreamProxyHost"
        case manifestProxyBaseURL = "ManifestProxyBaseUrl"
        case patchPosterByURL = "PatchPosterByURL"
        case fetchPosterByURL = "FetchPosterByURL"
        case supportPageURL = "SupportPageURL"
        case chatPageURL = "ChatPageURL"
        case nwTelSupportDeskNumber = "NWTelSupportDeskNumber"
        case termsAndConditionsURL = "TermsAndConditionsURL"
        case currentPlayerType = "CurrentPlayerType"
        case assetorProgramID = "AssetorProgramID"
        case defaultKongEnvironment = "DefaultKongEnvironment"
        case multicastGeolocation = "MulticastGeolocation"
        case enableOnDemandFeature = "EnableOnDemandFeature"
        case unlockedID = "UnlockedID"
        case streamRetuneTimeMS = "StreamRetuneTimeMS"
        case retuneRetryMaxCount = "RetuneRetryMaxCount"
        case dialogAutoHideDurationMS = "DialogAutoHideDurationMS"
        case vpForwardDurationSEC = "VPForwardDurationSec"
        case vpRewindDurationSEC = "VPRewindDurationSec"
        case epgLastDay = "EPGLastDay"
        case waitCompleteMilliseconds = "WaitCompleteMilliseconds"
        case diagIntervalMilliseconds = "DiagIntervalMilliseconds"
        case streamProxyPort = "StreamProxyPort"
        case maxDownloadLimit = "MaxDownloadLimit"
        case coorsPostProcessingTimeInMilliseconds = "COORS_POST_PROCESSING_TIME_IN_MILLISECONDS"
        case updateEpgDataTimeLimitInMilliseconds = "UPDATE_EPG_DATA_TIME_LIMIT_IN_MILLISECONDS"
        case maxResponseContentBufferSize = "MaxResponseContentBufferSize"
        case logoRefreshDuration = "LOGO_REFRESH_DURATION"
        case durationAppStatUpdateCycleInMilliseconds = "DurationAppStatUpdateCycleInMilliseconds"
        case isNonceNeeded = "IsNonceNeeded"
        case shouldRemovePort = "ShouldRemovePort"
        case isFairPlayEnable = "IsFairPlayEnable"
        case isDRMEnableForDownloadedContent = "IsDRMEnableForDownloadedContent"
        case shouldShowCurrentPosition = "ShouldShowCurrentPosition"
        case enableKongEnvironment = "EnableKongEnvironment"
        case enablePrivacyPage = "EnablePrivacyPage"
        case enableEnvironmentSelection = "EnableEnvironmentSelection"
        case enableRestartSVODAndDVR = "EnableRestartSVODAndDVR "
        case vsPlaying = "VSPlaying"
        case disableVideoPlayBack = "DisableVideoPlayBack"
        case disableHideUnsubscribeBetaFeature = "DisableHideUnsubscribeBetaFeature"
        case isDeviceActive = "IsDeviceActive"
        case isLogosUpdated = "IsLogosUpdated"
        case isParentalControlEnabled = "IsParentalControlEnabled"
        case isStreamingDiagnosticOverlayEnabled = "IsStreamingDiagnosticOverlayEnabled"
        case checkForDeviceLimitReached = "CheckForDeviceLimitReached"
        case isVODWidevineDRMEnabled = "IsVODWidevineDRMEnabled "
        case isMediaRoomAccount = "IsMediaRoomAccount"
        case useNewVODAPIs = "UseNewVODAPIs"
        case isHPNREnabled
        case useProtobufForPacket = "UseProtobufForPacket"
        case packetIsBigEndian = "PacketIsBigEndian"
        case disablePermissionCheck = "DisablePermissionCheck"
        case operatorThemeColor = "OperatorThemeColor"
        case operatorFontName = "OperatorFontName"
    }
}

// MARK: - Encode/decode helpers

class JSONNull: Codable, Hashable {

    public static func == (lhs: JSONNull, rhs: JSONNull) -> Bool {
        return true
    }

    public var hashValue: Int {
        return 0
    }

    public init() {}

    public required init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if !container.decodeNil() {
            throw DecodingError.typeMismatch(JSONNull.self, DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Wrong type for JSONNull"))
        }
    }

    public func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        try container.encodeNil()
    }
}

class JSONCodingKey: CodingKey {
    let key: String

    required init?(intValue: Int) {
        return nil
    }

    required init?(stringValue: String) {
        key = stringValue
    }

    var intValue: Int? {
        return nil
    }

    var stringValue: String {
        return key
    }
}

class JSONAny: Codable {

    let value: Any

    static func decodingError(forCodingPath codingPath: [CodingKey]) -> DecodingError {
        let context = DecodingError.Context(codingPath: codingPath, debugDescription: "Cannot decode JSONAny")
        return DecodingError.typeMismatch(JSONAny.self, context)
    }

    static func encodingError(forValue value: Any, codingPath: [CodingKey]) -> EncodingError {
        let context = EncodingError.Context(codingPath: codingPath, debugDescription: "Cannot encode JSONAny")
        return EncodingError.invalidValue(value, context)
    }

    static func decode(from container: SingleValueDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if container.decodeNil() {
            return JSONNull()
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout UnkeyedDecodingContainer) throws -> Any {
        if let value = try? container.decode(Bool.self) {
            return value
        }
        if let value = try? container.decode(Int64.self) {
            return value
        }
        if let value = try? container.decode(Double.self) {
            return value
        }
        if let value = try? container.decode(String.self) {
            return value
        }
        if let value = try? container.decodeNil() {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer() {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decode(from container: inout KeyedDecodingContainer<JSONCodingKey>, forKey key: JSONCodingKey) throws -> Any {
        if let value = try? container.decode(Bool.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Int64.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(Double.self, forKey: key) {
            return value
        }
        if let value = try? container.decode(String.self, forKey: key) {
            return value
        }
        if let value = try? container.decodeNil(forKey: key) {
            if value {
                return JSONNull()
            }
        }
        if var container = try? container.nestedUnkeyedContainer(forKey: key) {
            return try decodeArray(from: &container)
        }
        if var container = try? container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key) {
            return try decodeDictionary(from: &container)
        }
        throw decodingError(forCodingPath: container.codingPath)
    }

    static func decodeArray(from container: inout UnkeyedDecodingContainer) throws -> [Any] {
        var arr: [Any] = []
        while !container.isAtEnd {
            let value = try decode(from: &container)
            arr.append(value)
        }
        return arr
    }

    static func decodeDictionary(from container: inout KeyedDecodingContainer<JSONCodingKey>) throws -> [String: Any] {
        var dict = [String: Any]()
        for key in container.allKeys {
            let value = try decode(from: &container, forKey: key)
            dict[key.stringValue] = value
        }
        return dict
    }

    static func encode(to container: inout UnkeyedEncodingContainer, array: [Any]) throws {
        for value in array {
            if let value = value as? Bool {
                try container.encode(value)
            } else if let value = value as? Int64 {
                try container.encode(value)
            } else if let value = value as? Double {
                try container.encode(value)
            } else if let value = value as? String {
                try container.encode(value)
            } else if value is JSONNull {
                try container.encodeNil()
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer()
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout KeyedEncodingContainer<JSONCodingKey>, dictionary: [String: Any]) throws {
        for (key, value) in dictionary {
            let key = JSONCodingKey(stringValue: key)!
            if let value = value as? Bool {
                try container.encode(value, forKey: key)
            } else if let value = value as? Int64 {
                try container.encode(value, forKey: key)
            } else if let value = value as? Double {
                try container.encode(value, forKey: key)
            } else if let value = value as? String {
                try container.encode(value, forKey: key)
            } else if value is JSONNull {
                try container.encodeNil(forKey: key)
            } else if let value = value as? [Any] {
                var container = container.nestedUnkeyedContainer(forKey: key)
                try encode(to: &container, array: value)
            } else if let value = value as? [String: Any] {
                var container = container.nestedContainer(keyedBy: JSONCodingKey.self, forKey: key)
                try encode(to: &container, dictionary: value)
            } else {
                throw encodingError(forValue: value, codingPath: container.codingPath)
            }
        }
    }

    static func encode(to container: inout SingleValueEncodingContainer, value: Any) throws {
        if let value = value as? Bool {
            try container.encode(value)
        } else if let value = value as? Int64 {
            try container.encode(value)
        } else if let value = value as? Double {
            try container.encode(value)
        } else if let value = value as? String {
            try container.encode(value)
        } else if value is JSONNull {
            try container.encodeNil()
        } else {
            throw encodingError(forValue: value, codingPath: container.codingPath)
        }
    }

    public required init(from decoder: Decoder) throws {
        if var arrayContainer = try? decoder.unkeyedContainer() {
            self.value = try JSONAny.decodeArray(from: &arrayContainer)
        } else if var container = try? decoder.container(keyedBy: JSONCodingKey.self) {
            self.value = try JSONAny.decodeDictionary(from: &container)
        } else {
            let container = try decoder.singleValueContainer()
            self.value = try JSONAny.decode(from: container)
        }
    }

    public func encode(to encoder: Encoder) throws {
        if let arr = self.value as? [Any] {
            var container = encoder.unkeyedContainer()
            try JSONAny.encode(to: &container, array: arr)
        } else if let dict = self.value as? [String: Any] {
            var container = encoder.container(keyedBy: JSONCodingKey.self)
            try JSONAny.encode(to: &container, dictionary: dict)
        } else {
            var container = encoder.singleValueContainer()
            try JSONAny.encode(to: &container, value: self.value)
        }
    }
}

