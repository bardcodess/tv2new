//
//  Channels.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

// MARK: - Welcome1
struct AllChannels :Codable {
    let success: Bool
    let result: [AllChannelsResult]
}

// MARK: - Result
struct AllChannelsResult :Codable {
    let callLetter, channelId: String
    let permissions: [String]
    let blockCode: String?
    let policy: [Policy]
    let startTime: String
    let endTime: String
}



// MARK: - Policy
struct Policy : Codable {
    let downloadExpirationMins, playbackExpirationMins: Int
}

