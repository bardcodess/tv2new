//
//  AuthService.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 06/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit
import CoreData

enum APIError : Error {
    case invalidCrediantials
    case invalidData
    case decodingError
    case serverError(String)
    case unknown
    case emptyUsernameOrPassword
}

class AuthService {
    
    public static let shared = AuthService()
    
    private init() {}
    
    
    public func loginUser(with userRequest: LoginUserRequest, completion: @escaping(Result<String,Error>)-> Void) {
        
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let json =  AuthService.shared.readJsonFile()
        
        
        
        var urlString = ""
        var clientId = ""
        
        switch appdelegate.operatorName {
        case "CCAP":
            urlString = json?.ccap.accessTokenURL ?? ""
            clientId = json?.ccap.clientID ?? ""
        case "HARGRAY":
            urlString = json?.hargray.accessTokenURL ?? ""
            clientId = json?.hargray.clientID ?? ""
        case "NWTel":
            urlString = json?.nwTel.accessTokenURL ?? ""
            clientId = json?.nwTel.clientID ?? ""
        case "TBAYTEL":
            urlString = json?.tbaytel.accessTokenURL ?? ""
            clientId = json?.tbaytel.clientID ?? ""
        case "MobileGuide-iOS":
            print("mobile")
        default:
            print("Default")
        }
        
        print(urlString)
        
        guard let url = URL(string: urlString ) else {return}
        
        let requestedHeader : [String:String] = ["Content-Type":"application/x-www-form-urlencoded" ]
        var requestComponent = URLComponents()
        requestComponent.queryItems = [
        URLQueryItem(name: "grant_type", value: "password"),
        URLQueryItem(name: "client_id", value: clientId),
        URLQueryItem(name: "username", value: userRequest.username),
        URLQueryItem(name: "password", value: userRequest.password)
        ]
        
        var request = URLRequest(url: URL(string: urlString)!)
        request.httpMethod = "POST"
        request.allHTTPHeaderFields = requestedHeader
        request.httpBody = requestComponent.query?.data(using: .utf8)
                
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            
            guard let data = data else {
                if let error = error {
                    completion(.failure(APIError.serverError(error.localizedDescription)))
                } else {
                        completion(.failure(APIError.unknown))
                }
                return
            }
            
            let decoder = JSONDecoder()
            
            print("decoder")
            if let successMsg = try? decoder.decode(User.self, from: data){
                DispatchQueue.main.async {
                    CoreDataHelper.shared.saveToken(save: successMsg)
                }
                completion(.success("Success"))
            } else if let errorMsg = try? decoder.decode(ErroModel.self, from: data) {
                completion(.failure(APIError.invalidCrediantials))
            } else {
                completion(.failure(APIError.decodingError))
            }
        }
        
        task.resume()
        
        
        
        
        
    }
    
//    public func loginUser(with userRequest: LoginUserRequest, completion: @escaping (Bool,APIError?)-> Void ) {


//        let managedContext = appdelegate.persistentContainer.viewContext
//
//
//

//
//
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//
//
//            guard let data = data else {
//                if let error = error {
//                    completion(false,APIError.serverError(error.localizedDescription))
//                }
//                return
//            }
//
//
//            let decoder = JSONDecoder()
//
//            do {
//                if let t = try? decoder.decode(User.self, from: data) {
//                    completion(true,)
//                }
//
//            } catch {
//                completion(false,APIError.decodingError)
//            }
//
//            do {
//
//
//
//                guard let entity = NSEntityDescription.entity(forEntityName: "UserToken", in: managedContext) else {return }
//
//                let user = NSManagedObject(entity: entity, insertInto: managedContext)
//                user.setValue(t.access_token, forKey: "access_token")
//                user.setValue(t.expires_in, forKey: "expires_in")
//                user.setValue(t.refresh_token, forKey: "refresh_token")
//                user.setValue(t.token_type, forKey: "token_type")
//                user.setValue(Date(), forKey: "apiCallDate")
//
//
//
//                try managedContext.save()
//                completion(true,nil)
//
//            } catch {
//                completion(false,APIError.decodingError)
//            }
//        }
//        task.resume()
//
//    }
    
    public func readJsonFile()-> NetworkJSON? {
        guard let url = Bundle.main.url(forResource: "NetworkConstants", withExtension: "json") else {
            return nil
        }
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            let jsonData = try decoder.decode(NetworkJSON.self, from: data)
            return jsonData
        }
        catch {
            print("error:\(error)")
            return nil
        }
        
        
    }
    
    
    
}

