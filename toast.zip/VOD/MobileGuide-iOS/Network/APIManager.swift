//
//  APIManager.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 17/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit
import CoreData

class APIManager {
    
    private let appDelegate = UIApplication.shared.delegate as! AppDelegate
    public static let shared = APIManager()
    
    private init() {}
    
    
    //MARK: - App Config
    
    
    func getAppConfig(completion: @escaping(Result<AppConfigModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/appConfiguration?platform=IOS_PHONE&operator=\(appDelegate.operatorName!.lowercased())"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(AppConfigModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
        
    }
    
    //MARK: - Recordings
    
    func getRecordedShows(skip: Int,top: Int,completion: @escaping(Result<RecordedShows,Error>)->Void) {
        
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let json =  AuthService.shared.readJsonFile()
        
        var urlString = ""
        
        switch appdelegate.operatorName {
        case "CCAP":
            urlString = json?.ccap.productionURL ?? ""
            
        case "HARGRAY":
            urlString = json?.hargray.productionURL ?? ""
            
        case "NWTel":
            urlString = json?.nwTel.productionURL ?? ""
            
        case "TBAYTEL":
            urlString = json?.tbaytel.productionURL ?? ""
            
        case "MobileGuide-iOS":
            print("mobile")
        default:
            print("Default")
        }
        
        if top == 10 {
            urlString = urlString + "/recordings/mds/v1/completed?keepInProgressRecordings=true&skip=\(skip)&top=\(top)"
        } else {
            urlString = urlString + "/recordings/mds/v1/completed?keepInProgressRecordings=true"
        }
        
        
        guard let token  = CoreDataHelper.shared.getToken() else {return}
        
        // print(urlString)
        let authToken = "JWT " + token.access_token!
        // print(authToken)
        guard let url = URL(string: urlString) else {return}
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        //request.setValue("green", forHTTPHeaderField: "env-type")
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(RecordedShows.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
            
        }
        
        task.resume()
        
    }
    
    
    // MARK: - Scheduled Shows
    
    func getScheduledShows(skip: Int,top: Int,completion: @escaping(Result<ScheduledShows,Error>)->Void) {
        
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let json =  AuthService.shared.readJsonFile()
        
        var urlString = ""
        
        switch appdelegate.operatorName {
        case "CCAP":
            urlString = json?.ccap.productionURL ?? ""
            
        case "HARGRAY":
            urlString = json?.hargray.productionURL ?? ""
            
        case "NWTel":
            urlString = json?.nwTel.productionURL ?? ""
            
        case "TBAYTEL":
            urlString = json?.tbaytel.productionURL ?? ""
            
        case "MobileGuide-iOS":
            print("mobile")
        default:
            print("Default")
        }
        
        
        if top == 10 {
            urlString = urlString + "/recordings/mds/v1/scheduled?keepInProgressRecordings=false&skip=\(skip)&top=\(top)"
        } else {
            urlString = urlString + "/recordings/mds/v1/scheduled?keepInProgressRecordings=false"
        }
        
        
        
        guard let token  = CoreDataHelper.shared.getToken() else {return}
        //  print(urlString)
        let authToken = "JWT " + token.access_token!
        guard let url = URL(string: urlString) else {return}
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        // request.setValue("green", forHTTPHeaderField: "env-type")
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(ScheduledShows.self, from: data)
                // print(String(data: data, encoding: .utf8))
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
            
        }
        
        task.resume()
        
    }
    
    // MARK: - Failed Shows
    
    func getFailedShows(completion:@escaping(Result<FailedRecordings,Error>)->Void) {
        guard let appdelegate = UIApplication.shared.delegate as? AppDelegate else {return}
        let json =  AuthService.shared.readJsonFile()
        
        var urlString = ""
        
        switch appdelegate.operatorName {
        case "CCAP":
            urlString = json?.ccap.productionURL ?? ""
            
        case "HARGRAY":
            urlString = json?.hargray.productionURL ?? ""
            
        case "NWTel":
            urlString = json?.nwTel.productionURL ?? ""
            
        case "Tbaytel TV":
            urlString = json?.tbaytel.productionURL ?? ""
            
        case "MobileGuide-iOS":
            print("mobile")
        default:
            print("Default")
        }
        
        urlString = urlString + "/recordings/mds/failed"
        // print(urlString)
        guard let token  = CoreDataHelper.shared.getToken() else {return}
        let authToken = "JWT " + token.access_token!
        // print(token)
        guard let url = URL(string: urlString) else {return}
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        //  request.setValue("green", forHTTPHeaderField: "env-type")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(FailedRecordings.self, from: data)
                // print(String(data: data, encoding: .utf8))
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
            
        }
        
        task.resume()
        
    }
    
    // MARK: - Home data
    func fetchVodData(catID  : String,completion: @escaping (Result<[Recommendation],Error>) -> Void)  {
        let catId = catID
        let query = "recommendations/recommendationFeed/\(catId)"
        
        let urlString = "\(self.appDelegate.selectedOperatorData?.productionURL ??  "")/\(query)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        let token  = CoreDataHelper.shared.getToken()
        let authToken = "JWT " + (token?.access_token ?? "")
        var request = URLRequest(url: url)
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }
            guard let data = data else {
                print("No data received")
                return
            }
            // Process the data (parse JSON, etc.) here
            do {
                let decoder = JSONDecoder()
                let recommendationsResponse = try decoder.decode(RecommendationsResponse.self, from: data)
                
                completion(.success(recommendationsResponse.response.Recommendations))
            } catch {
                print("JSON parsing error: \(error)")
                completion(.failure(error))
                
            }
        }
        task.resume()
        
    }
    
    func GetRecommendationFeedInfo(completion: @escaping (Result<[RecommendationFeed],Error>) -> Void)
    {
        let query = "recommendation-feeds"
        let urlString = "\(self.appDelegate.selectedOperatorData?.productionURL ??  "")/\(query)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        let token  = CoreDataHelper.shared.getToken()
        let authToken = "JWT " + (token?.access_token ?? "")
        var request = URLRequest(url: url)
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }
            guard let data = data else {
                print("No data received")
                return
            }
            // Process the data (parse JSON, etc.) here
            do {
                let decoder = JSONDecoder()
                let recommendationsFeedResponse = try decoder.decode(RecommendationsFeedResponse.self, from: data)
                completion(.success(recommendationsFeedResponse.response.Recommendationfeeds))
                
            } catch {
                print("JSON parsing error: \(error)")
                completion(.failure(error))
                
            }
        }
        task.resume()
    }
    
    func FetchHomeRecordingsData(completion: @escaping (Result<[RecordingsItems],Error>) -> Void)  {
        var query = ""
        if (appDelegate.operatorName == "tbaytel" || appDelegate.operatorName == "hargray")
        {
            query = "recordings/mds/completed?keepInProgressRecordings=true"
        }
        else
        {
            query = "recordings/mds/v1/completed?keepInProgressRecordings=true"
        }
        
        
        let urlString = "\(self.appDelegate.selectedOperatorData?.productionURL ??  "")/\(query)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        let token  = CoreDataHelper.shared.getToken()
        let authToken = "JWT " + (token?.access_token ?? "")
        var request = URLRequest(url: url)
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }
            guard let data = data else {
                print("No data received")
                return
            }
            // Process the data (parse JSON, etc.) here
            do {
                let decoder = JSONDecoder()
                let recordingsResponse = try decoder.decode(RecordingResponse.self, from: data)
                completion(.success(recordingsResponse.response.items))
            } catch {
                print("JSON parsing error: \(error)")
                completion(.failure(error))
                
            }
        }
        task.resume()
        
    }
    
    // MARK: - VOD data
    
    func GetNewVODCategoryData(catID  : String,completion: @escaping (Result<[CategoryList],Error>) -> Void)
    {
        var query = ""
        if(catID.isEmpty)
        {
            query = "vod/getCategory"
        }
        else
        {
            query = "vod/getCategory/\(catID)"
        }
        let urlString = "\(self.appDelegate.selectedOperatorData?.productionURL ??  "")/\(query)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            return
        }
        let token  = CoreDataHelper.shared.getToken()
        let authToken = "JWT " + (token?.access_token ?? "")
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        request.addValue("IOS_PHONE", forHTTPHeaderField: "platform")
        print(urlString)
        print(authToken)
        let session = URLSession.shared
        let task = session.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error)")
                return
            }
            guard let data = data else {
                print("No data received")
                return
            }
            // Process the data (parse JSON, etc.) here
            do {
                let decoder = JSONDecoder()
                let response = try decoder.decode(CategoryAssetDetails.self, from: data)
                completion(.success(response.result))
            } catch {
                print("JSON parsing error: \(error)")
                completion(.failure(error))
            }
        }
        task.resume()
        
    }
    
    func PostVODCategoryAssetDataAsync(categoryVod: CategoryList) async throws -> [CategoryList]
    {
        let query = "vod/getCategoryAssets/"
        let urlString = "\(await self.appDelegate.selectedOperatorData?.productionURL ??  "")/\(query)"
        guard let url = URL(string: urlString) else {
            print("Invalid URL")
            throw URLError(URLError.Code.badURL)
        }
        let token  = CoreDataHelper.shared.getToken()
        let authToken = "JWT " + (token?.access_token ?? "")
        print(urlString)
        print(authToken)
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        let encoder = JSONEncoder()
        do {
            let jsonData = try encoder.encode(categoryVod)
            let jsonString = String(data: jsonData, encoding: .utf8)
            if let unwrappedData = jsonString {
                let jsonDataOutput = unwrappedData.data(using: .utf8)
                request.httpBody = jsonDataOutput
            }
        } catch {
            print("Error encoding parameters: \(error)")
        }
        do {
            let (data, _) =  try await URLSession.shared.data(for: request)
            let decoder = JSONDecoder()
            let response = try decoder.decode(CategoryAssetResponse.self, from: data)
            return [response.result]
        }
        catch
        {
            print(error)
        }
        let respose : [CategoryList] = []
        return respose
    }
    
    
    
    // MARK: - Settings
    
    func getUserIP(completion: @escaping(Result<IPModel,Error>)->Void) {
        
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/network/getCallerIPAddress"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(IPModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
        
    }
    
    
    func getUsernameFromJWT()-> String {
        guard let token  = CoreDataHelper.shared.getToken() else {return "" }
        guard let result = decode(jwtToken: token.access_token!)["claims"] as? [String:Any] else {
            return ""
        }
        return "\(result["email"]!)"
    }
    
    
    func getNetworkLocation(userPublicIP IP: String,completion: @escaping(Result<NetWorkLocation,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/account/getgeosubscribergroup"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        request.setValue("Content-Type", forHTTPHeaderField: "application/json")
        
        
        var requestComponent = URLComponents()
        requestComponent.queryItems = [
            URLQueryItem(name: "ip_address", value: IP),
            URLQueryItem(name: "username", value: UserDefaults.standard.string(forKey: "username")),
        ]
        
        request.httpMethod = "POST"
        request.httpBody = requestComponent.query?.data(using: .utf8)
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(NetWorkLocation.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    func getAccountDiagonostics(completion: @escaping(Result<AccountDiagosticsModel,Error>)->Void) {
        
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/account/diagnostics/V2"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        request.setValue("IOS_PHONE", forHTTPHeaderField: "platform")
        request.setValue("Green", forHTTPHeaderField: "env-type")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(AccountDiagosticsModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
        
    }
    
    
    
    // MARK: - Decode JWT
    
    
    private func decode(jwtToken jwt: String) -> [String: Any] {
        let segments = jwt.components(separatedBy: ".")
        return decodeJWTPart(segments[1]) ?? [:]
    }
    
    
    private func base64UrlDecode(_ value: String) -> Data? {
        var base64 = value
            .replacingOccurrences(of: "-", with: "+")
            .replacingOccurrences(of: "_", with: "/")
        
        let length = Double(base64.lengthOfBytes(using: String.Encoding.utf8))
        let requiredLength = 4 * ceil(length / 4.0)
        let paddingLength = requiredLength - length
        if paddingLength > 0 {
            let padding = "".padding(toLength: Int(paddingLength), withPad: "=", startingAt: 0)
            base64 = base64 + padding
        }
        return Data(base64Encoded: base64, options: .ignoreUnknownCharacters)
    }
    
    private func decodeJWTPart(_ value: String) -> [String: Any]? {
        guard let bodyData = base64UrlDecode(value),
              let json = try? JSONSerialization.jsonObject(with: bodyData, options: []), let payload = json as? [String: Any] else {
            return nil
        }
        
        return payload
    }
    
    //MARK: - Search
    
    func getSearchResultForRecording(for key: String,completion: @escaping(Result<SearchRecordingsModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/recordings/mds/search?searchKey=\(key)"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(SearchRecordingsModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    enum searchType: String {
        case onDemand = "VOD"
        case ppvEvent = "EVENT"
        case live = "LIVE"
        
    }
    
    
    
    func getSearchResultForVOD(for key: String,completion: @escaping(Result<SearchVodModel,Error>)->Void) {
        
        
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/epg/searchV2?fetchAll=true&skip=0&inJSON=true&limit=50&type=\(searchType.onDemand.rawValue)&searchString=\(key)&isAdultFilterEnabled=False"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        //  print(url)
        // print(authToken)
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(SearchVodModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
        
        
    }
    
    func getSearchResultForLive(for key: String,completion: @escaping(Result<SearchLiveModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/epg/searchV2?fetchAll=true&skip=0&inJSON=true&limit=50&type=\(searchType.live.rawValue)&searchString=\(key)&isAdultFilterEnabled=False"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue(authToken, forHTTPHeaderField: "Authorization")
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(SearchLiveModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    func getSearchResultForEvent(for key: String,completion: @escaping(Result<SearchEventModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/epg/searchV2?fetchAll=true&skip=0&inJSON=true&limit=50&type=EVENT&searchString=\(key)&isAdultFilterEnabled=False"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        request.addValue("Green", forHTTPHeaderField: "env-type")
        
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(SearchEventModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    
    
    // MARK: - Series Bookmark
    
    func getSeriesBookmark(for seriesId: String,completion: @escaping(Result<SeriesBookmarkModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/vod/seriesBookmarks/\(seriesId)"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        request.addValue("Green", forHTTPHeaderField: "env-type")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(SeriesBookmarkModel.self, from: data)
                // print(String(data: data, encoding: .utf8))
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    func getAssetBookmark(for assetId: String,completion: @escaping(Result<AssetBookmarkModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/vod/bookmarks/\(assetId)"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(AssetBookmarkModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    
    // MARK: - Recording Settings
    
    
    func  getRecordingSettings(completion: @escaping(Result<RecordingSettingsModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/recordings/mds/settings?settingType=keepUntil%2CkeepAtMost%2CchannelChoice%2CshowTypeChoice%2CstartTimeChoice%2CstartRecordingTime%2CstopRecordingTime%2CkeepAll"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(RecordingSettingsModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    //MARK: - For Live Show Time
    
    
    
    func  getShowTimeForLiveShows(seriesId: String ,callLetter: String, programId: String   ,completion: @escaping(Result<ShowTimeModel,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/program/alternate?seriesId=\(seriesId)&callLetter=\(callLetter)&programId=\(programId)"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(ShowTimeModel.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    // MARK: - FOR ALL CHANNELS
    
    
    
    func  getAllChannels(completion: @escaping(Result<AllChannels,Error>)->Void) {
        let urlString = appDelegate.selectedOperatorData!.productionURL + "/channel/preflight/all"
        guard let url = URL(string: urlString) else {return}
        guard let token  = CoreDataHelper.shared.getToken() else {return }
        let authToken = "JWT " + token.access_token!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.addValue(authToken, forHTTPHeaderField: "Authorization")
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) { data, _, error in
            guard let data = data else {
                if let error = error {
                    completion(.failure(error))
                } else {
                    completion(.failure(error!))
                }
                return
            }
            
            let decoder = JSONDecoder()
            do {
                
                let success =  try decoder.decode(AllChannels.self, from: data)
                
                completion(.success(success))
            } catch {
                print(error)
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
    
    
    
    
}
