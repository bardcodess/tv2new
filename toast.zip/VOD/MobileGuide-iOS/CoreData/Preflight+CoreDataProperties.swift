//
//  Preflight+CoreDataProperties.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 05/12/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//
//

import Foundation
import CoreData


extension Preflight {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Preflight> {
        return NSFetchRequest<Preflight>(entityName: "Preflight")
    }

    @NSManaged public var success: Bool
    @NSManaged public var callLetter: String
    @NSManaged public var permissions: String
    @NSManaged public var blockCode: String?
    @NSManaged public var startTime: String
    @NSManaged public var endTime: String
    @NSManaged public var ofCallLetter: ChannelPermissions?

}

extension Preflight : Identifiable {

}
