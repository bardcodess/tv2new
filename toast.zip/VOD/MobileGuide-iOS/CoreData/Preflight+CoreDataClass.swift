//
//  Preflight+CoreDataClass.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 05/12/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Preflight)
public class Preflight: NSManagedObject {

}
