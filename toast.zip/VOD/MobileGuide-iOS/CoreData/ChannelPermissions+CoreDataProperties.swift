//
//  ChannelPermissions+CoreDataProperties.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 05/12/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//
//

import Foundation
import CoreData


extension ChannelPermissions {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<ChannelPermissions> {
        return NSFetchRequest<ChannelPermissions>(entityName: "ChannelPermissions")
    }

    @NSManaged public var callLetter: String?
    @NSManaged public var hasPermissions: Preflight?

}

extension ChannelPermissions : Identifiable {

}
