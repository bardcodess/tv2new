//
//  CoreDataHelper.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 10/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import CoreData


class CoreDataHelper {
    
    public static let shared = CoreDataHelper()
    
    private init() {}
    
    
  public  func checkUserIsLoggedIn()-> Bool {
       
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserToken")
        fetchRequest.fetchLimit = 1
        
        do {
            let context = appDelegate.persistentContainer.viewContext
            let count = try context.fetch(fetchRequest) as! [NSManagedObject]
           
            if count.count == 0 {
                return false
            } else {
                let tokenExpirationTime = count[0].value(forKey: "expires_in") as! Int
                let apiCallDate = count[0].value(forKey: "apiCallDate") as! Date
                let tokenExpireDate = apiCallDate.addingTimeInterval(TimeInterval(tokenExpirationTime))
              
                if (Date() < tokenExpireDate) {
                    return true
                } else {
                    let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: "UserToken")
                    let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)

                    do {
                        try context.execute(deleteRequest)
                        try context.save()
                    } catch let error as NSError {
                        print(error)
                    }
                    return false
                }
                
            }
            
        } catch {
            print("Error while checking Core Data: \(error)")
            return false
        }
    }
    
    public func saveToken(save token : User) {
        do {
            let context = appDelegate.persistentContainer.viewContext
            guard let entity = NSEntityDescription.entity(forEntityName: "UserToken", in: context) else {return }
            
            let user = NSManagedObject(entity: entity, insertInto: context)
            user.setValue(token.access_token, forKey: "access_token")
            user.setValue(token.expires_in, forKey: "expires_in")
            user.setValue(token.refresh_token, forKey: "refresh_token")
            user.setValue(token.token_type, forKey: "token_type")
            user.setValue(Date(), forKey: "apiCallDate")
        
            try context.save()
            
        } catch {
           print(error)
        }
    }
    
    public func getToken()-> UserToken? {
    
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "UserToken")
        fetchRequest.fetchLimit = 1
        
        do {
            let context = appDelegate.persistentContainer.viewContext
            let count = try context.fetch(fetchRequest) as? [UserToken]
             
            return count?[0]
        } catch {
            print(error)
            return nil
        }
        
    }
    
    public func removeToken() ->Bool {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "UserToken")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            let context = appDelegate.persistentContainer.viewContext
            try context.execute(deleteRequest)
            return true
        } catch let error as NSError {
            print(error)
            return false
        }
    }
    
  
    public func savePermissionsForChannel(record : ChannelPermission) {
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let cdChannelPermission = ChannelPermissions(context: managedContext)
        cdChannelPermission.callLetter = record.channelCallLetter
        
        let cdPreFlight = Preflight(context: managedContext)
        cdPreFlight.blockCode = record.preflight.blockCode
        cdPreFlight.callLetter = record.preflight.callLetter
        cdPreFlight.endTime = record.preflight.endTime
        cdPreFlight.startTime = record.preflight.startTime
        cdPreFlight.success = record.preflight.success
        
        if record.preflight.permissions.count  > 0 {
            cdPreFlight.permissions = record.preflight.permissions.joined(separator: "-")
        } else {
            cdPreFlight.permissions = ""
        }
        
        cdChannelPermission.hasPermissions = cdPreFlight
        
        do {
            try  managedContext.save()
        } catch {
            print(error)
        }
    }
    
    private func getPermissionsByCallLetter(callLetter: String) -> ChannelPermissions?{
        let managedContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<ChannelPermissions>(entityName: "ChannelPermissions")
        let fetchByCallLetter = NSPredicate(format: "callLetter==%@", callLetter )
        fetchRequest.predicate = fetchByCallLetter

        let result = try! managedContext.fetch(fetchRequest)
        guard result.count != 0 else {return nil}

        return result.first
    }
    
    
    public func get(byCallLetter: String) -> ChannelPermission? {
        let result = self.getPermissionsByCallLetter(callLetter: byCallLetter)
        guard result != nil else {return nil}

        return result!.convertToChannelPermission()
    }
    
    
    public func removeChannelPermissions() -> Bool {
        let fetchRequest: NSFetchRequest<NSFetchRequestResult> = NSFetchRequest(entityName: "ChannelPermissions")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)

        do {
            let context = appDelegate.persistentContainer.viewContext
            try context.execute(deleteRequest)
            return true
        } catch let error as NSError {
            print(error)
            return false
        }
    }
    
    
    
    
}
