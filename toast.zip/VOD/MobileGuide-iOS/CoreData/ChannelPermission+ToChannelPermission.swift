//
//  ChannelPermission+ToChannelPermission.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 05/12/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

extension ChannelPermissions {
    func convertToChannelPermission() -> ChannelPermission {
        return ChannelPermission(channelCallLetter: self.callLetter!, preFlight: (self.hasPermissions?.convertToPreflightModel())!)
         }
}

extension Preflight {
    func convertToPreflightModel() -> PreFlightModel {
        return PreFlightModel(success: self.success, callLetter: self.callLetter , permissions: self.permissions.components(separatedBy: "-"), blockCode: self.blockCode ?? "", startTime: self.startTime, endTime: self.endTime)
    }
}
