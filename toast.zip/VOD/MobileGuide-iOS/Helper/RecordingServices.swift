//
//  RecordingServices.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class RecordingServices {
    
    var shared = RecordingServices()
    private init() {}
    
    func checkRecordingStatus(model: DetailRecordingsModel) {
        
    }
    
    func checkForRecordingActions(model: DetailRecordingsModel) -> RecordingStatus{
       
        let currentDate = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = model.actualEndUtc
               dateFormatter.timeZone = TimeZone(abbreviation: "UTC")
               
               let dt = dateFormatter.date(from: "2023-11-30T09:33:00.000Z")
               dateFormatter.timeZone = TimeZone.current
               
               // let calendar = Calendar.current
                
            // let components = Calendar.current.dateComponents(in: TimeZone.current, from: dt!)
        if dt! < currentDate {
            return RecordingStatus.recordingIsInPast
        } else if dt! > currentDate {
            return RecordingStatus.recordingIsInFuture
        } else {
            return RecordingStatus.recordingIsInPresent
        }
        
    }
    
}
