//
//  AlertManager.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 10/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class AlertManager {
    
    private static func showBasicAlert(on vc: UIViewController, title: String, message: String?) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Dismiss", style: .default, handler: nil))
            vc.present(alert, animated: true)
        }
    }
    
    private static func showAlertWithLogoutActions(on vc: UIViewController, title: String, message: String?) {
        DispatchQueue.main.async {
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "No", style: .default, handler: nil))
            
            alert.addAction(UIAlertAction(title: "Yes", style: .default,handler: { _ in
                if CoreDataHelper.shared.removeToken() {
                    guard let loginVC = UIStoryboard.init(name: "Main", bundle: .main).instantiateViewController(withIdentifier: "MovieViewController") as? MovieViewController else {
                        return
                    }
                    CoreDataHelper.shared.removeChannelPermissions()
                    appDelegate.window?.rootViewController = loginVC
                    
                } else {
                    return
                }
               
            }))
           
            vc.present(alert, animated: true)
        }
    }
}

// MARK: - Show Login Alerts
extension AlertManager {
    
    
    public static func showInvalidUsernameAlert(on vc: UIViewController) {
        self.showBasicAlert(on: vc, title: "Error", message: "The username and/or password is incorrect")
    }
    
    public static func showEmptyUsernameOrPassword(on vc: UIViewController) {
        self.showBasicAlert(on: vc, title: "Error", message: "Email and Password must be provided")
    }
    
    public static func showLogoutAlert(on VC:UIViewController) {
        self.showAlertWithLogoutActions(on: VC, title: "Logout", message: "Do you want to logout?")
    }
    
    public static func showEmptySearchAlert(on VC: UIViewController) {
        self.showBasicAlert(on: VC, title: "Empty input", message: "Please Enter a value")
    }
    
    public static func showNoResultOnSearchAlert(on VC: UIViewController) {
        self.showBasicAlert(on: VC, title: "No results found", message: "Check your spelling or try another term")
    }
    
}



