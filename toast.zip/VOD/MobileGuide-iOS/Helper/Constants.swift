//
//  Constants.swift
//  MobileGuide-iOS
//
//  Created by MA-15 on 17/07/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit

/// General object of Application Delegate
let APPDELEGATE: AppDelegate                   =   UIApplication.shared.delegate as! AppDelegate

/// General object of Main Screen
let MAINSCREEN                                 =   UIScreen.main
