
import UIKit
import SwiftUI
import ProgressHUD

class MovieViewController: UIViewController {
    
    //MARK: Internal Properties
    @IBOutlet var viewHargray: UIView!
    @IBOutlet var txtEmailHargray: UITextField!
    @IBOutlet var txtPasswordHargray: UITextField!
    @IBOutlet var lblHargrayPassword: UILabel!
    @IBOutlet var lblHargrayWebsite: UILabel!
    
    @IBOutlet var viewtbaytel: UIView!
    @IBOutlet var txtEmailtbaytel: UITextField!
    @IBOutlet var txtPasswordtbaytel: UITextField!
    @IBOutlet var lbltbaytelPassword: UILabel!
    @IBOutlet var lbltbaytelWebsite: UILabel!

    @IBOutlet var viewNorthwestel: UIView!
    @IBOutlet var txtEmailNorthwestel: UITextField!
    @IBOutlet var txtPasswordNorthwestel: UITextField!
    @IBOutlet var lblNorthwestelCall: UILabel!
   
    
   
    @IBOutlet var viewCcap: UIView!
    @IBOutlet var txtEmailCcap: UITextField!
    @IBOutlet var txtPasswordCcap: UITextField!

    
    //MARK: Northwestel Constraints
    @IBOutlet var lblNorthwestelChat: UILabel!
    @IBOutlet weak var northwestelLblHeightCns: NSLayoutConstraint!
    @IBOutlet weak var txtEmailNorthWestelWidthCns: NSLayoutConstraint!
    @IBOutlet var txtNorthwestelTrailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var txtPasswordNorthWestelWidthCns: NSLayoutConstraint!
    @IBOutlet var btnNorthwestelTrailingCns: NSLayoutConstraint!
    @IBOutlet var chatViewNorthwestelTopCns: NSLayoutConstraint!
    @IBOutlet var chatViewNorthwestelLeadingCns: NSLayoutConstraint!
    @IBOutlet weak var northwestelLoginUsingLblTopCns: NSLayoutConstraint!
    
    
    
    
    
    //MARK: Ccap Constraints
    //MARK: Tbaytel Constraints
    //MARK: Hargary Constraints
    @IBOutlet weak var hargrayViewTopConstraint: NSLayoutConstraint!
    
   private let appDelegate = UIApplication.shared.delegate as! AppDelegate
    
    let tableView = UITableView(frame: .zero, style: .plain)
    //let myView = UIView(frame: .zero)
    //var btnLogin = UIButton()
    //let imgView = UIImageView(frame: .zero)
    //var imgName = ""
    //let txtUsername = UITextField(frame: .zero)
    //let txtPassword = UITextField(frame: .zero)
    
    var stackView: UIStackView {
        let stackView = UIStackView(frame: .zero)
        stackView.axis = .vertical
        return stackView
    }
    
    var indicator = UIActivityIndicatorView()
    
    func activityIndicator() {
        indicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        indicator.style = UIActivityIndicatorView.Style.large
        indicator.center = self.view.center
        indicator.color = .black
        self.view.addSubview(indicator)
    }
    
    var filterButton: UIButton {
        let button = UIButton(frame: .zero)
        button.setTitle("Filter By Name", for: .normal)
        button.backgroundColor = .red
        button.translatesAutoresizingMaskIntoConstraints = false
        button.addTarget(self, action: #selector(filterButtonTapped(_:)), for: .touchUpInside)
        return button
    }
    
    let loginVM = LoginVM()
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
//        #if DEBUG
//        print("DEBUG")
//        #endif
//        var execu_name = Bundle.main.infoDictionary!["CFBundleExecutable"] as! String
//        print(execu_name)
        
        resetUI()
       
       
        let operatorName = appDelegate.operatorName
        switch operatorName {
        case "CCAP":
            setCcapData()
        case "HARGRAY":
            setHargrayData()
        case "NWTel":
            setNWTelData()
        case "TBAYTEL":
            setTbaytelData()
        case "MobileGuide-iOS":
            setMobileGuideData()
        default:
            print("Default")
        }


    }
    func resetUI(){
        self.viewHargray.isHidden = true
        self.viewtbaytel.isHidden = true
        self.viewNorthwestel.isHidden = true
        self.viewCcap.isHidden = true
    }
    
    func setCcapData() {
        self.viewCcap.isHidden = false
                
        txtEmailCcap.layer.borderWidth = 1
        txtEmailCcap.layer.borderColor = UIColor.black.withAlphaComponent(0.42).cgColor
        txtEmailCcap.layer.cornerRadius = 5.0

        txtPasswordCcap.layer.borderWidth = 1
        txtPasswordCcap.layer.borderColor = UIColor.black.withAlphaComponent(0.42).cgColor
        txtPasswordCcap.layer.cornerRadius = 5.0
        txtPasswordCcap.enablePasswordToggle()
    }
    
    func setHargrayData() {
        self.viewHargray.isHidden = false
        
        let attributedString = NSAttributedString.init(string: "What’s My Password?")
        
        if UIDevice.current.orientation.isLandscape {
            hargrayViewTopConstraint.constant = 0
        } else if UIDevice.current.orientation.isPortrait {
            hargrayViewTopConstraint.constant = 63
        }
        lblHargrayPassword.attributedText = attributedString.underlined
        
        txtEmailHargray.layer.borderWidth = 1
        txtEmailHargray.layer.borderColor = UIColor.black.withAlphaComponent(0.42).cgColor
        txtEmailHargray.layer.cornerRadius = 5.0

        txtPasswordHargray.layer.borderWidth = 1
        txtPasswordHargray.layer.borderColor = UIColor.black.withAlphaComponent(0.42).cgColor
        txtPasswordHargray.layer.cornerRadius = 5.0

        lblHargrayWebsite.text = "Log in with the username and password associated with your Hargray  account. If you need assistance, please go to\nMy Hargray"
        
        lblHargrayWebsite.boldUnderlineSubstring("My Hargray")

        let tapWebsite = UITapGestureRecognizer(target: self, action: #selector(self.tapOnWebsite(_:)))
        lblHargrayWebsite.isUserInteractionEnabled = true
        lblHargrayWebsite.addGestureRecognizer(tapWebsite)
        txtPasswordHargray.enablePasswordToggle()
    }
    

    func setNWTelData() {
        self.viewNorthwestel.isHidden = false
        
        if UIDevice.current.orientation.isLandscape {
            northwestelLblHeightCns.constant = 50
            northwestelLoginUsingLblTopCns.constant = 1
            txtNorthwestelTrailingConstraint.isActive = false
            btnNorthwestelTrailingCns.isActive = false
            chatViewNorthwestelTopCns.constant = 230
            chatViewNorthwestelLeadingCns.constant = 450
        } else if UIDevice.current.orientation.isPortrait {
            northwestelLblHeightCns.constant = 177
            northwestelLoginUsingLblTopCns.constant = 4
            txtNorthwestelTrailingConstraint.isActive = true
            btnNorthwestelTrailingCns.isActive = false
            chatViewNorthwestelTopCns.constant = 626
            chatViewNorthwestelLeadingCns.constant = 30
        }
        
      
                
        txtEmailNorthwestel.layer.borderWidth = 1
        txtEmailNorthwestel.layer.borderColor = UIColor.lightGray.cgColor

        txtPasswordNorthwestel.layer.borderWidth = 1
        txtPasswordNorthwestel.layer.borderColor = UIColor.lightGray.cgColor
        
        let attributedString = NSAttributedString.init(string: "Call 1 888 423-2333")
        lblNorthwestelCall.attributedText = attributedString.underlined
        let tapWebsite = UITapGestureRecognizer(target: self, action: #selector(self.northWestelCall(_:)))
        lblNorthwestelCall.isUserInteractionEnabled = true
        lblNorthwestelCall.addGestureRecognizer(tapWebsite)

        let attributedString1 = NSAttributedString.init(string: "Chat with us")
        lblNorthwestelChat.attributedText = attributedString1.underlined
        let tapChat = UITapGestureRecognizer(target: self, action: #selector(self.northWestelChat(_:)))
        lblNorthwestelChat.isUserInteractionEnabled = true
        lblNorthwestelChat.addGestureRecognizer(tapChat)
        txtPasswordNorthwestel.enablePasswordToggle()
    }
    
    
    func setTbaytelData() {
        self.viewtbaytel.isHidden = false

        lbltbaytelPassword.text = "By continuing, I agree to the Terms & Conditions"
        lbltbaytelPassword.boldUnderlineSubstring("Terms & Conditions")
        let tapTnC = UITapGestureRecognizer(target: self, action: #selector(self.tapOnTnC(_:)))
        lbltbaytelPassword.isUserInteractionEnabled = true
        lbltbaytelPassword.addGestureRecognizer(tapTnC)

        
        txtEmailtbaytel.layer.borderWidth = 1
        txtEmailtbaytel.layer.borderColor = UIColor(hex: "003d53").cgColor
        txtEmailtbaytel.layer.cornerRadius = 5.0

        txtPasswordtbaytel.layer.borderWidth = 1
        txtPasswordtbaytel.layer.borderColor = UIColor(hex: "003d53").cgColor
        txtPasswordtbaytel.layer.cornerRadius = 5.0

        lbltbaytelWebsite.text = "Use the email address and password associated\nwith your myTbaytel account to log in. If you’re\nnot already registered with myTbaytel or forgot\nyour login credentials go to My Tbaytel"
        
        lbltbaytelWebsite.boldUnderlineSubstring("My Tbaytel")

        let tapWebsite = UITapGestureRecognizer(target: self, action: #selector(self.tapOnWebsite(_:)))
        lbltbaytelWebsite.isUserInteractionEnabled = true
        lbltbaytelWebsite.addGestureRecognizer(tapWebsite)
        txtPasswordtbaytel.enablePasswordToggle()
    }
    
    func setMobileGuideData() {
        
    }
    
    @objc func tapOnTnC(_ gesture: UITapGestureRecognizer) {
        print("tapOn TnC")
    }
    
    @objc func tapOnWebsite(_ gesture: UITapGestureRecognizer) {
        print("tapOnWebsite")
    }
    
    @objc func northWestelCall(_ gesture: UITapGestureRecognizer) {
        print("northWestelCall")
    }

    @objc func northWestelChat(_ gesture: UITapGestureRecognizer) {
        print("northWestelChat")
    }
}

//MARK: Prepare UI

extension MovieViewController {
    
    func prepareUI() {
        //prepareButton()
        //prepareTableView()
        //prepareStackView()
        //prepareViewModelObserver()
    }
    
    /*func prepareStackView() {
    //prepareImage()
    //prepareTextfield()
    prepareButton()
    
    myView.backgroundColor = .white
    let stackView = UIStackView(arrangedSubviews: [myView])
    stackView.axis = .vertical
    stackView.distribution = .fill
    stackView.alignment = .fill
    stackView.translatesAutoresizingMaskIntoConstraints = false
    self.view.addSubview(stackView)
    stackView.topAnchor.constraint(equalTo: self.view.topAnchor, constant: 0.0).isActive = true
    stackView.leftAnchor.constraint(equalTo: self.view.leftAnchor, constant: 0.0).isActive = true
    stackView.rightAnchor.constraint(equalTo: self.view.rightAnchor, constant: 0.0).isActive = true
    stackView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor, constant: 0.0).isActive = true
     }*/
    
    /*func prepareImage(){
        imgView.frame = CGRect(x: 20, y: 100, width: self.view.frame.size.width - 40, height: 80)
        imgView.contentMode = .scaleAspectFit
        imgView.backgroundColor = .clear
        imgView.image = UIImage(named:imgName)
        myView.addSubview(imgView)
    }*/
    
    /*func prepareTextfield(){
        txtUsername.frame = CGRect(x: 20, y: imgView.frame.origin.y + 120, width: self.view.frame.size.width - 40, height: 40)
        txtUsername.backgroundColor = .white
        txtUsername.layer.cornerRadius = 5.0
        txtUsername.layer.borderColor = UIColor.black.cgColor
        txtUsername.layer.borderWidth = 1.0
        txtUsername.placeholder = "Enter Username"
        txtUsername.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: txtUsername.frame.height))
        txtUsername.leftViewMode = .always

        txtPassword.frame = CGRect(x: 20, y: txtUsername.frame.origin.y + 60, width: self.view.frame.size.width - 40, height: 40)
        txtPassword.backgroundColor = .white
        txtPassword.layer.cornerRadius = 5.0
        txtPassword.layer.borderColor = UIColor.black.cgColor
        txtPassword.layer.borderWidth = 1.0
        txtPassword.placeholder = "Password"
        txtPassword.leftView = UIView(frame: CGRect(x: 0, y: 0, width: 10, height: txtPassword.frame.height))
        txtPassword.leftViewMode = .always
        txtPassword.isSecureTextEntry = true
        myView.addSubview(txtUsername)
        myView.addSubview(txtPassword)
    }*/
    
    /*func prepareButton() {
        btnLogin = UIButton(frame: CGRect(x: 100, y: txtPassword.frame.origin.y + 60, width: self.view.frame.size.width - 200, height: 50))
        btnLogin.setTitle("Login", for: .normal)
        btnLogin.layer.cornerRadius = 5.0
        btnLogin.backgroundColor = .red
        btnLogin.addTarget(self, action: #selector(loginClicked(_:)), for: .touchUpInside)
        myView.addSubview(btnLogin)
    }*/
    
    @IBAction func loginClicked(_ button: UIButton) {
        ProgressHUD.animationType = .circleRotateChase
        ProgressHUD.show()
        switch appDelegate.operatorName {
        case "CCAP":
            ccapLogin()
        case "HARGRAY":
            hargrayLogin()
        case "NWTel":
            nwtelLogin()
        case "TBAYTEL":
            tbaytelLogin()
        default:
            print("default")
        }

    }

}

//MARK: Action

extension MovieViewController {
    
    @objc func filterButtonTapped(_ button: UIButton) {
        print("filterButtonTapped")
         //viewModel.movies = viewModel.movies?.sortByName()
    }
}

/*
//MARK: Private Methods

extension MovieViewController {
    
    func fetchMovieList() {
        viewModel.fetchMovieList()
    }
    
    func prepareViewModelObserver() {
        self.viewModel.movieDidChanges = { (finished, error) in
            if !error {
                self.reloadTableView()
            }
        }
    }
    
    func reloadTableView() {
        self.tableView.reloadData()
    }
}


// MARK: - UITableView Delegate And Datasource Methods
extension MovieViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.movies!.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        guard let cell: MovieViewCell = tableView.dequeueReusableCell(withIdentifier: "MovieViewCell", for: indexPath as IndexPath) as? MovieViewCell else {
            fatalError("AddressCell cell is not found")
        }
        
        let movie = viewModel.movies![indexPath.row]
        cell.movieItem = movie
        return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        tableView.estimatedRowHeight = 160
        tableView.rowHeight = UITableView.automaticDimension
        return UITableView.automaticDimension
    }
}
*/

// MARK:  Set Landscape Constraints
extension MovieViewController {
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        
       // let cfbundle = Bundle.main.object(forInfoDictionaryKey: "CFBundleName") as? String ?? ""
        //print("-----",cfbundle)
        let operatorName = appDelegate.operatorName
        
        switch operatorName {
        case "CCAP":
            print("CCAP")
        case "NWTel":
            setNWTelLandscapeConstraints()
        case  "TBAYTEL":
            print("TBAYTEL")
        case  "HARGRAY":
            setHargrayLandscapeConstraints()
        default:
            print("parag")
        }
    }

}

extension MovieViewController {
    private func setHargrayLandscapeConstraints() {
        if UIDevice.current.orientation.isLandscape {
            hargrayViewTopConstraint.constant = 0
            
        } else {
            hargrayViewTopConstraint.constant = 63
        }
    }
    
    private func setNWTelLandscapeConstraints() {
       
        if UIDevice.current.orientation.isLandscape {
            northwestelLblHeightCns.constant = 50
            northwestelLoginUsingLblTopCns.constant = 1
            txtNorthwestelTrailingConstraint.isActive = false
            txtEmailNorthWestelWidthCns.constant = 334
            txtPasswordNorthWestelWidthCns.constant = 334
            btnNorthwestelTrailingCns.isActive = false
            chatViewNorthwestelTopCns.constant = 230
            chatViewNorthwestelLeadingCns.constant = 450
        } else {
            northwestelLblHeightCns.constant = 177
            northwestelLoginUsingLblTopCns.constant = 4
            txtNorthwestelTrailingConstraint.isActive = true
            txtEmailNorthWestelWidthCns.constant = 334
            txtPasswordNorthWestelWidthCns.constant = 334
            btnNorthwestelTrailingCns.isActive = true
            chatViewNorthwestelTopCns.constant = 626
            chatViewNorthwestelLeadingCns.constant = 30
            
        }
    }
}


// MARK:- Logins

extension MovieViewController {
    private func ccapLogin() {
        loginVM.validateCreds(userRequest: LoginUserRequest(username: txtEmailCcap.text ?? "", password: txtPasswordCcap.text ?? "")) { result in
            switch result {
            case .success(_):
               
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                    SideMenuUtil.shared.setMenuDrawer()
                    //self.appDelegate.window?.rootViewController = ContainerViewController()
                }
            case .failure(let failure):
                guard let error = failure as? APIError else {return}
                switch error {
                case .invalidCrediantials:
                    AlertManager.showInvalidUsernameAlert(on: self)
                case .emptyUsernameOrPassword:
                    AlertManager.showEmptyUsernameOrPassword(on: self)
                default:
                    print(error)
                }
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                }
            }
        }
        
    }
    
    
    private func hargrayLogin() {
      
        loginVM.validateCreds(userRequest: LoginUserRequest(username: txtEmailHargray.text ?? "", password: txtPasswordHargray.text ?? "")) { result in
            switch result {
            case .success(_):
                
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                    SideMenuUtil.shared.setMenuDrawer()
                }
            case .failure(let failure):
                guard let error = failure as? APIError else {return}
                switch error {
                case .invalidCrediantials:
                    AlertManager.showInvalidUsernameAlert(on: self)
                case .emptyUsernameOrPassword:
                    AlertManager.showEmptyUsernameOrPassword(on: self)
                default:
                    print(error)
                }
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                }
               
            }
        }
    }
    
    private func nwtelLogin() {
        loginVM.validateCreds(userRequest: LoginUserRequest(username: txtEmailNorthwestel.text ?? "", password: txtPasswordNorthwestel.text ?? "")) { result in
            switch result {
            case .success(_):
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                    SideMenuUtil.shared.setMenuDrawer()
                }
            case .failure(let failure):
                guard let error = failure as? APIError else {return}
                switch error {
                case .invalidCrediantials:
                    AlertManager.showInvalidUsernameAlert(on: self)
                case .emptyUsernameOrPassword:
                    AlertManager.showEmptyUsernameOrPassword(on: self)
                default:
                    print(error)
                }
               
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                }
            }
        }
        
    }
    
    private func tbaytelLogin() {
        loginVM.validateCreds(userRequest: LoginUserRequest(username: txtEmailtbaytel.text ?? "", password: txtPasswordtbaytel.text ?? "")) { result in
            switch result {
            case .success(_):
               
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                    SideMenuUtil.shared.setMenuDrawer()
                }
            case .failure(let failure):
                guard let error = failure as? APIError else {return}
                switch error {
                case .invalidCrediantials:
                    AlertManager.showInvalidUsernameAlert(on: self)
                case .emptyUsernameOrPassword:
                    AlertManager.showEmptyUsernameOrPassword(on: self)
                default:
                    print(error)
                }
                DispatchQueue.main.async {
                    ProgressHUD.dismiss()
                }
            }
        }
    }
    
    
    
}







