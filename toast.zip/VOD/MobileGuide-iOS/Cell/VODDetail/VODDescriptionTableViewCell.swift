//
//  VODDescriptionTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 11/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class VODDescriptionTableViewCell: UITableViewCell {

    @IBOutlet private var episodeTitle: UILabel!
    @IBOutlet private var Descriptionlabel: UILabel!
    @IBOutlet private var undertabVIew: UIView!
    @IBOutlet private var startStackContainer: UIStackView!
    @IBOutlet private var ratingLabelLeadingCns: NSLayoutConstraint!
    @IBOutlet private var ratingLabel: UILabel!
    @IBOutlet private var ratingLabelLeadingConstraint: NSLayoutConstraint!
    
    
    private let starAssets = ["fill_star_icon.png","half_star_icon.png","blank_star_icon.png"]
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        prepareTheme()
        startStackContainer.axis = .horizontal
        startStackContainer.distribution = .fillEqually
        startStackContainer.spacing = 0
        ratingLabel.translatesAutoresizingMaskIntoConstraints = false
    }
    
    private func prepareTheme() {
        let operatorName = appDelegate.operatorName
        switch operatorName {
        case "CCAP":
            undertabVIew.backgroundColor = UIColor(hex: Colors.ccapBrandColor.rawValue)
        case "NWTel":
            undertabVIew.backgroundColor = UIColor(hex: Colors.nwTelBranColor.rawValue)
        case  "TBAYTEL":
            undertabVIew.backgroundColor = UIColor(hex: Colors.tBayBrandColor.rawValue)
        case  "HARGRAY":
            undertabVIew.backgroundColor = UIColor(hex: Colors.hargrayBrandColor.rawValue)
        default:
            print("default")
        }
    
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layoutIfNeeded()
    }
    

    private func fillStarStack(userReview : Float) {
        
        if startStackContainer.arrangedSubviews.count > 0 {
            return
        }
        let userReviewUptoTwoDecimal = String(format: "%.2f", userReview)
        let splitDecimal = userReviewUptoTwoDecimal.split(separator: ".")
        let intPart = Int(splitDecimal[0]) ?? 0
        let decimalPart = Float(splitDecimal[1]) ?? 0
        let subtractedValue = Int(5 - userReview)
        
        if intPart > 0 {
            for _ in 1...intPart{
                let imageView = UIImageView(image: UIImage(named: "fill_star_icon.png"))
                imageView.contentMode = .scaleAspectFit
                startStackContainer.addArrangedSubview(imageView)
            }
            
            if decimalPart > 0 {
                if decimalPart >= 50  {
                    let imageView = UIImageView(image: UIImage(named: "half_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    startStackContainer.addArrangedSubview(imageView)
                } else if decimalPart > 80 {
                    let imageView = UIImageView(image: UIImage(named: "fill_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    startStackContainer.addArrangedSubview(imageView)
                } else {
                    let imageView = UIImageView(image: UIImage(named: "blank_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    startStackContainer.addArrangedSubview(imageView)
                }
            }
            
            if subtractedValue > 0 {
                for _ in 1...subtractedValue {
                    let imageView = UIImageView(image: UIImage(named: "blank_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    startStackContainer.addArrangedSubview(imageView)
                }
            }
            
        }
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    func configureWithHomemodel(with model: VODDetailModel) {
        Descriptionlabel.text = model.assetDetails?.shortSummary
        episodeTitle.isHidden = true
        
        if model.userReview == nil || model.userReview == 0 {
            startStackContainer.removeFromSuperview()
            ratingLabelLeadingCns.constant = 16
        } else {
            fillStarStack(userReview: model.userReview ?? 0)
        }
        
        var ratingsString = ""
        
        if model.assetDetails?.rating == nil {
            ratingsString = ""
        } else {
            ratingsString = model.assetDetails?.rating ?? ""
            ratingsString = "•" + ratingsString
        }
        
        let runtime = DateUtility.shared.convertTimeDurationToHoursMinutes(model.assetDetails?.runTime ?? "")
        let year = model.assetDetails?.year ?? ""
        let available = DateUtility.shared.getDateFromUTCString(from: model.assetDetails?.licensingWindowEnd ?? "")
        
        ratingLabel.text = "\(runtime) \(ratingsString) • \(year) • Available until \(available)"
        
    }
    
    
    func configureWithRecommendationModel(with model: DetailSeriesModel) {
        Descriptionlabel.text = model.shortSummary
        
        if model.userReview == nil || model.userReview == 0 {
            startStackContainer.removeFromSuperview()
            ratingLabelLeadingCns.constant = 16
        } else {
            fillStarStack(userReview: model.userReview ?? 0)
        }
        
        episodeTitle.text = model.episodeName
        var ratingsString = ""
        
        if model.rating == nil {
            ratingsString = ""
        } else {
            ratingsString = model.rating ?? ""
            ratingsString = "•" + ratingsString
        }
        
        let runtime = DateUtility.shared.convertTimeDurationToHoursMinutes(model.runTime ?? "")
        let year = model.year ?? ""
        let available = DateUtility.shared.getDateFromUTCString(from: model.licensingWindowEnd ?? "")
        let seasonNumber = model.seasonNumber?.stringValue ?? ""
        let episodeId = model.episodeId?.stringValue ?? ""
        
        ratingLabel.text = "S\(seasonNumber) E\(episodeId) • \(runtime) \(ratingsString) • \(year) • Available until \(available)"
    }
    
}
