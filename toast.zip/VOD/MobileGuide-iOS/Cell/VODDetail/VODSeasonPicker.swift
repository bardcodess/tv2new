//
//  VODSeasonPicker.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 19/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

protocol SeasonPickerProtocol {
    func setSeason(season: String)
}

class VODSeasonPicker: UITableViewCell, UITextFieldDelegate {
    
    
    @IBOutlet private var seasonEpisodeCountLabel: UILabel!
    @IBOutlet private var titleLabel: UILabel!
    @IBOutlet private var seasonPicker: UITextField!
    @IBOutlet var starStackContainer: UIStackView!
    
    var arrSeasons : [String] = []
    var picker = UIPickerView()
    var seasonPickerDelegate : SeasonPickerProtocol?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        picker.delegate = self
        picker.dataSource = self
        seasonPicker.layer.borderWidth = 1.0
        seasonPicker.layer.borderColor = UIColor.white.cgColor
        seasonPicker.inputView = picker
        seasonPicker.delegate = self
        starStackContainer.axis = .horizontal
        starStackContainer.distribution = .fillEqually
        starStackContainer.spacing = 3
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    private func fillStarStack(userReview : Float) {
        
        if starStackContainer.arrangedSubviews.count > 0 {
            return
        }
        let userReviewUptoTwoDecimal = String(format: "%.2f", userReview)
        let splitDecimal = userReviewUptoTwoDecimal.split(separator: ".")
        let intPart = Int(splitDecimal[0]) ?? 0
        let decimalPart = Float(splitDecimal[1]) ?? 0
        let subtractedValue = Int(5 - userReview)
        
        if intPart > 0 {
            for _ in 1...intPart{
                let imageView = UIImageView(image: UIImage(named: "fill_star_icon.png"))
                imageView.contentMode = .scaleAspectFit
                starStackContainer.addArrangedSubview(imageView)
            }
            
            if decimalPart > 0 {
                if decimalPart >= 50  {
                    let imageView = UIImageView(image: UIImage(named: "half_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    starStackContainer.addArrangedSubview(imageView)
                } else if decimalPart > 80 {
                    let imageView = UIImageView(image: UIImage(named: "fill_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    starStackContainer.addArrangedSubview(imageView)
                } else {
                    let imageView = UIImageView(image: UIImage(named: "blank_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    starStackContainer.addArrangedSubview(imageView)
                }
            }
            
            if subtractedValue > 0 {
                for _ in 1...subtractedValue {
                    let imageView = UIImageView(image: UIImage(named: "blank_star_icon.png"))
                    imageView.contentMode = .scaleAspectFit
                    starStackContainer.addArrangedSubview(imageView)
                }
            }
            
        }
        
    }

    
    
    
    
    
    func configure(title : String , seasonCount : Int, episodeCount: Int, pickerDataSource: [Int], userReview : Float?) {
        
        if userReview == nil || userReview == 0 {
            starStackContainer.removeFromSuperview()
        } else {
            fillStarStack(userReview: userReview ?? 0)
        }
        
        titleLabel.text = title
        seasonEpisodeCountLabel.text = "\(seasonCount) \(seasonCount > 1 ? "Seasons" : "Season"), \(episodeCount) \(episodeCount > 1 ? "Episodes" : "Episode")"
        
        if arrSeasons.isEmpty {
            for season in pickerDataSource {
                arrSeasons.append("Season \(season)")
            }
            
            seasonPicker.attributedText =  getAttributedString(for: arrSeasons[0])
        }
    }
    
    
    private func getAttributedString(for text: String) -> NSAttributedString {
        let attributedString = NSMutableAttributedString(string: text)
        let range = NSRange(location: 0, length: text.count )
        
        
        attributedString.addAttribute(NSAttributedString.Key.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: range)
        attributedString.addAttribute(NSAttributedString.Key.underlineColor, value: appDelegate.getOperatoColor(), range: range)
        
        return attributedString
    }
    
}

extension VODSeasonPicker:  UIPickerViewDelegate, UIPickerViewDataSource {
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return arrSeasons.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return arrSeasons[row]
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return false
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        seasonPicker.text = arrSeasons[row]
        seasonPicker.resignFirstResponder()
        seasonPickerDelegate?.setSeason(season: arrSeasons[row])
    }
}

