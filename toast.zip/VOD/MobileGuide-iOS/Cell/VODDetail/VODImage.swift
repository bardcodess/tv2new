//
//  VODImage.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 19/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class VODImage: UITableViewHeaderFooterView {
    
    @IBOutlet private var VODPoster: UIImageView!
    
// MARK: - For asset
    func configure(with model: VODDetailModel) {
        var posterurl = ""
        
        if model.assetDetails?.episodes != nil && ((model.assetDetails?.episodes!.count)!) > 0  {
            if ((model.assetDetails?.episodes!.count)!) > 0 {
                posterurl = model.assetDetails?.episodes?[0].posters?.first(where: {$0.posterType == "back-splash"})?.posterUrl ?? ""
            }
            if posterurl == "" {
                posterurl = model.assetDetails?.episodes?[0].posters?.first(where: {$0.posterType == "poster"})?.posterUrl ?? ""
            }
            if posterurl == "" {
                posterurl = model.assetDetails?.episodes?[0].poster?[0] ?? ""
            }
        } else {
            posterurl = model.assetDetails?.posters?.first(where: {$0.posterType == "back-splash"})?.posterUrl ?? ""
            if posterurl == "" {
                posterurl = model.assetDetails?.posters?.first(where: {$0.posterType == "poster"})?.posterUrl ?? ""
            }
            if posterurl == "" {
                if model.assetDetails?.poster?.count ?? 0 > 0  {
                    posterurl = model.assetDetails?.poster?[0] ?? ""
                }
            }
        }
        
       
        if posterurl == "" {
            VODPoster.image = UIImage(named: "Ondemand_Search")
        } else {
            guard let url = URL(string: posterurl) else {
                return
            }
            
            VODPoster.sd_setImage(with: url,placeholderImage: UIImage(named: "Ondemand_Search"))
        }
       
    }
    
    
// MARK: - For series
    func configureWithRecommendationModel(with model: DetailSeriesModel, isSeriesView: Bool) {
        var posterurl = ""
        if isSeriesView {
            posterurl = model.episodes?[0].posters?.first(where: {$0.posterType == "back-splash"})?.posterUrl ?? ""
            
            if posterurl == "" {
                posterurl = model.episodes?[0].posters?.first(where: {$0.posterType == "poster"})?.posterUrl ?? ""
            }
            
            if posterurl == "" {
                posterurl = model.episodes?[0].poster?[0] ?? ""
            }
        } else {
            if posterurl == "" {
                posterurl =  model.posters?.first(where: {$0.posterType == "back-splash"})?.posterUrl ?? ""
            }
            
            if posterurl == "" {
                posterurl = model.posters?.first(where: {$0.posterType == "poster"})?.posterUrl ?? ""
            }
            
            if posterurl == "" {
                posterurl = model.poster?[0] ?? ""
            }
              
        }
      
        
       
    
        guard let url = URL(string: posterurl) else {
            return
        }
    
        VODPoster.sd_setImage(with: url,placeholderImage: UIImage(named: "Ondemand_Search"))
    }
    
    
    
    // MARK: - FOR RECORDINGS SERIES
    
    
    func configureForRecordings(model: DetailRecordingsModel) {
        let urlString = model.iconSrc ?? ""
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        
        VODPoster.sd_setImage(with: url,placeholderImage: UIImage(named: "Ondemand_Search"))
    }
    
    
    // MARK: - FOR RECORDING ITEM
    
    func configureForRecordingItem(model: String?) {
        let urlString = model ?? ""
        
        guard let url = URL(string: urlString) else {
            return
        }
       
        VODPoster.sd_setImage(with: url,placeholderImage: UIImage(named: "Ondemand_Search"))
    }
    
    
    
    //MARK: - FOR LIVE ITEM
    
    func configureForLiveItem(model: String?) {
        let urlString = model ?? ""
        
        guard let url = URL(string: urlString) else {
            return
        }
       
        VODPoster.sd_setImage(with: url,placeholderImage: UIImage(named: "Ondemand_Search"))
    }
    
}
