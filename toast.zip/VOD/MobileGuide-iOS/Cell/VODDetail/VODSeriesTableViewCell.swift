//
//  VODSeriesTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 16/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class VODSeriesTableViewCell: UITableViewCell {

    @IBOutlet private var posterimage: UIImageView!
    @IBOutlet private var titleLabel: UILabel!
    @IBOutlet private var progressView: UIProgressView!
    @IBOutlet private var ratingLabel: UILabel!
    @IBOutlet private var descriptionLabel: UILabel!
    @IBOutlet var posterImageWidthCns: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
       prepareTheme()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    private func prepareTheme() {
        progressView.progressTintColor = appDelegate.getOperatoColor()
    }
    
    
    
    
    func configure(with model: DetailSeriesModel?, progressArray assetProgress: [SeriesBookMark]) {
        
        guard let model = model else {
            return
        }
        
        var progressForEpisode =  0.0
        
        if assetProgress.count > 0 {
            let bookmark = assetProgress.first(where: {$0.vodId == model.assetId})
            progressForEpisode = bookmark?.assetProgress ?? 0.0
        } else {
            progressForEpisode = 0.0
        }
        
        titleLabel.text = model.title
        descriptionLabel.text = model.shortSummary
        
        let duration = DateUtility.shared.convertTimeDurationToHoursMinutes(model.runTime ?? "")
        let seasonNumber = model.seasonNumber?.stringValue ?? ""
        let episodeId = model.episodeId?.stringValue ?? ""
        let ratingText =  "S\(seasonNumber)E\(episodeId) • \(duration) • \(model.rating ?? "") • \(model.year ?? "")"
        ratingLabel.text = ratingText
        
        var urlString = model.posters?.first(where: {$0.posterType == "poster"})?.posterUrl ?? ""
        if urlString == "" {
            urlString =  model.poster?[0] ?? ""
        }
        progressView.progress = Float(progressForEpisode / 100)
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        posterimage.sd_setImage(with: url,placeholderImage: UIImage(named: "default_asset.png"))
    }
    
    
    // MARK: - FOR RECORDINGS
    
    func configureForRecordings(with model: DetailRecordings?) {
        
        guard let model = model else {
            return
        }
        
        var ratingsString = ""
        
        if model.ratings == nil {
            ratingsString = ""
        } else {
            ratingsString = model.ratings!.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString
        }
        
        let durationStringToTimeInter = DateUtility.shared.timeIntervalFromSeconds(model.duration ?? 0)
        let duration = DateUtility.shared.formatDuration(durationStringToTimeInter)
        
        titleLabel.text = model.title
        descriptionLabel.text = model.shortSummary
        
        let seasonNumber = model.seasonNumber ?? ""
        let episodeId = model.episodeNumber ?? ""
        let ratingText =  "S\(seasonNumber)E\(episodeId) • \(duration) \(ratingsString)"
        ratingLabel.text = ratingText
        
        let urlString = model.iconSrc ?? ""
      
        
        guard let url = URL(string: urlString) else {
            return
        }
        
        posterImageWidthCns.constant = 150
        posterimage.contentMode = .scaleAspectFill
        posterimage.sd_setImage(with: url,placeholderImage: UIImage(named: "default_asset.png"))
    }
    
}
