//
//  VODButtonsCollectionViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 24/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class VODButtonsCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet private var label: UILabel!
    @IBOutlet private var image: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(image: String, title: String) {
        label.text = title
        self.image.image = UIImage(named: image)
    }
   
    
    
}
