//
//  VODProgressTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 13/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class VODProgressTableViewCell: UITableViewCell {
    
    @IBOutlet private var remainingText: UILabel!
    @IBOutlet private var title: UILabel!
    @IBOutlet private var progressView: UIProgressView!
    @IBOutlet private var actionsCollectionView: UICollectionView!
    
    private var actionButtons = [String]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        prepareTheme()
        actionsCollectionView.delegate = self
        actionsCollectionView.dataSource = self
        actionsCollectionView.register(UINib(nibName: "VODButtonsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "actionButtonCell")
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        layoutIfNeeded()
    }
    
    private func prepareTheme() {
        progressView.progressTintColor = appDelegate.getOperatoColor()
        
    }
    
    
    
    private func calculateRemainngTime(for asset: String?,model: String?) -> String{
        
        guard let totalRuntime = model?.components(separatedBy: ".")[0] else {
            return ""
        }
        
        guard let assetTime = asset?.components(separatedBy: ".")[0]  else {
            return ""
        }
        
        guard let totalRuntimeToDateComponent = DateUtility.shared.timeStringToDateComponents(totalRuntime) else { return "" }
        
        guard let assetLastPositionTimeToDateComponent = DateUtility.shared.timeStringToDateComponents(assetTime) else { return "" }
        
        let remainingTime = DateUtility.shared.calculateRemainingTime(startingTime: assetLastPositionTimeToDateComponent, endingTime: totalRuntimeToDateComponent)
        
        let remainingHour = remainingTime.hour! > 0 ? remainingTime.hour! : 0
        let remainingMinutes =  remainingTime.minute! > 0 ? remainingTime.minute! : 0
        
        var hours = ""
        var minutes = ""
        
        if remainingHour == 0 && remainingMinutes == 0  {
            return ""
        }
        
        if remainingHour == 0 {
            hours = ""
        } else {
            hours = "\(remainingHour)"
        }
        
        if remainingMinutes == 0  {
            minutes = ""
        } else {
            minutes = "\(remainingMinutes)"
        }
        
        let remaingTimeString = "\(hours)\(remainingHour == 0 ? "" : "h ")\(minutes)\(remainingMinutes == 0 ? "" : "m") remaining"
        return remaingTimeString
    }
    
    private func addActionButtons(isBookmarkAvailable: Bool) {
        
        if isBookmarkAvailable {
            actionButtons = ["Resume","Restart","Download"]
        } else {
            actionButtons = ["Watch","Download"]
        }
        
        DispatchQueue.main.async {
            self.actionsCollectionView.reloadData()
        }
    }
    
    
    // MARK: - For asset
    func configureWithHomemodel(with model: VODDetailModel, assetProgress: AssetBookmarkModel?) {
        title.text = model.assetDetails?.title ?? ""
        
        guard let assetProgress = assetProgress else {
            addActionButtons(isBookmarkAvailable: false)
            return
        }
        
        if assetProgress.result.bookmark.assetProgress != nil {
            progressView.progress = Float(assetProgress.result.bookmark.assetProgress! / 100)
        }
        
        addActionButtons(isBookmarkAvailable: true)
        
        let remainingTextString =  calculateRemainngTime(for: assetProgress.result.bookmark.lastPosition ?? nil, model: model.assetDetails?.runTime ?? nil)
        remainingText.text = remainingTextString
    }
    
    // MARK: - For series
    
    func configureWithRecommendationModel(with model: DetailSeriesModel, assetProgress: [SeriesBookMark]) {
        title.text = model.title
        let asset = assetProgress.first(where: {$0.vodId == model.assetId})
        
        guard let asset = asset else {
            addActionButtons(isBookmarkAvailable: false)
            remainingText.text = ""
            progressView.progress = 0
            return
        }
        
        let remainingTextString =  calculateRemainngTime(for: asset.lastPosition!, model: model.runTime!)
        remainingText.text = remainingTextString
        addActionButtons(isBookmarkAvailable: true)
        
        progressView.progress = Float((asset.assetProgress ?? 0) / 100)
    }
    
    
}


// MARK: - Action Buttons

extension VODProgressTableViewCell : UICollectionViewDelegate , UICollectionViewDataSource {
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        actionButtons.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "actionButtonCell", for: indexPath) as! VODButtonsCollectionViewCell
        cell.configure(image: actionButtons[indexPath.row], title: actionButtons[indexPath.row])
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        2
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:  65, height: 50)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        10
    }
    
}
