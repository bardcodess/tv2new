//
//  RecordingSettingTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 21/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

protocol RecordingSettingsProtocol {
    func didPickerOptionChanged(dataChanged : Setting,idx:Int)
}



import UIKit

class RecordingSettingTableViewCell: UITableViewCell, UIPickerViewDataSource, UIPickerViewDelegate {
    
    
    
    var options = [RecordingSettingsResponse]()
    
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return options[0].settings.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return  options[0].settings[row].description
    }
    
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        return false
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        settingTextField.text = options[0].settings[row].description
        recordingSettingDelegate?.didPickerOptionChanged(dataChanged: options[0].settings[row], idx: secIdx ?? 0)
        
    }
    

    @IBOutlet var settingTextField: UITextField!
    @IBOutlet var backgroudView: UIView!
    var picker = UIPickerView()
    var recordingSettingDelegate : RecordingSettingsProtocol?
    var secIdx: Int?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        backgroudView.layer.cornerRadius = 10
        self.selectionStyle = .none
        picker.dataSource = self
        picker.delegate = self
        settingTextField.inputView = picker
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
    }
    
    func configure(with model:  [RecordingSettingsResponse],recordingData: DetailRecordingsModel,userSelectedData: String) {
        self.options = model
        picker.reloadAllComponents()
       let row =  options[0].settings.firstIndex(where: {$0.description == userSelectedData})
       picker.selectRow(row ?? 0, inComponent: 0, animated: true)
        settingTextField.text = userSelectedData
    }
    
}
