//
//  RecordingSettingFooterForProgram.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 28/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit


class RecordingSettingFooterForProgram: UIView {


    class func instanceFromNib() -> UIView {
        let nib = UINib(nibName: "RecordingSettingFooterForProgram", bundle: nil).instantiate(withOwner: nil, options: nil)[0] as! UIView
        
        return nib
    }
}
