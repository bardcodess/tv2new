//
//  RecordingSettingsHeader.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 21/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class RecordingSettingsHeader: UITableViewHeaderFooterView {

    @IBOutlet private var HeaderText: UILabel!
  
    func configure(headerLabel: String){
        HeaderText.text = headerLabel
    }
    

}
