//
//  MenuViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 08/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class MenuViewCell: UITableViewCell {

    @IBOutlet var menuLabel: UILabel!
    @IBOutlet var menuIconImageView: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()

        autoresizingMask = .flexibleWidth
        layoutIfNeeded()
    }
}
