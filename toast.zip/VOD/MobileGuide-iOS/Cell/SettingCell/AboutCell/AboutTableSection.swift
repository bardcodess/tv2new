//
//  AboutTableSection.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 20/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class AboutTableSection: UIView {
    
    var countList = [CountList]()
    private let table : UITableView =  {
        let table = UITableView()
        table.register(UINib(nibName: "InNetworkTableViewCell", bundle: nil), forCellReuseIdentifier: "inNetwork")
        table.register(UINib(nibName: "AboutTableSectionHeader", bundle: nil), forHeaderFooterViewReuseIdentifier: "AboutTableSectionHeader")
        table.register(UINib(nibName: "ShowDiagnostics", bundle: nil), forHeaderFooterViewReuseIdentifier: "ShowDiagnostics")
        table.isScrollEnabled = false
        //tableFooter.backgroundColor = .red
        table.backgroundColor = UIColor(named: "appBg")
         table.separatorColor = UIColor.clear
        
        return table
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(table)
        table.delegate = self
        table.dataSource = self
       
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        table.frame = self.bounds
    }
    
    func configure(with model: [CountList]){
        self.countList = model
        DispatchQueue.main.async {
            self.table.reloadData()
        }
    }
    
    
}

extension AboutTableSection: UITableViewDelegate, UITableViewDataSource {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        countList.count - 1
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "inNetwork", for: indexPath) as! InNetworkTableViewCell
        cell.networkText.text = countList[indexPath.row + 1].text
        cell.value.text = countList[indexPath.row + 1].value
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableHeaderFooterView(withIdentifier: "AboutTableSectionHeader") as! AboutTableSectionHeader
        header.totalDeviceText.text = countList[0].text
        header.totatDeviceValue.text = countList[0].value
        return header
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        60
    }
    
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let view = tableView.dequeueReusableHeaderFooterView(withIdentifier: "ShowDiagnostics") as! ShowDiagnostics
        return view
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        50
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
    }
    
}
