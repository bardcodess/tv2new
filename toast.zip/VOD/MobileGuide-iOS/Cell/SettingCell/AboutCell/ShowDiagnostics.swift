//
//  ShowDiagnostics.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 23/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class ShowDiagnostics: UITableViewHeaderFooterView {

 
    
}
