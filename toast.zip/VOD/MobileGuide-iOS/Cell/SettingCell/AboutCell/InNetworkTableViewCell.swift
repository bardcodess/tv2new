//
//  InNetworkTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 20/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class InNetworkTableViewCell: UITableViewCell {

    @IBOutlet var value: UILabel!
    @IBOutlet var networkText: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
