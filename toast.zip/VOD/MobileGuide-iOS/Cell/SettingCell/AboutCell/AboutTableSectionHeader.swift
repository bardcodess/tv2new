//
//  AboutTableSectionHeader.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 22/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit


class AboutTableSectionHeader: UITableViewHeaderFooterView {
    
    
    @IBOutlet var totalDeviceText: UILabel!
    
   
    @IBOutlet var totatDeviceValue: UILabel!
    
    override class func awakeFromNib() {
        super.awakeFromNib()
        
    }

    /*
     
     
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
