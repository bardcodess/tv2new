//
//  LiveShowTimesTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class LiveShowTimesTableViewCell: UITableViewCell {

    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var episodeLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

       
    }
    
    func configure(model: ShowTimeResult) {
        episodeLabel.text = model.episodeTitle
        var startingDateSting = DateUtility.shared.UTCToLocal(date: model.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        startingDateSting = DateUtility.shared.formatRelativeDate(startingDateSting)
        
        let start = DateUtility.shared.UTCToLocal(date: model.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        let end = DateUtility.shared.UTCToLocal(date: model.end ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        var ratingsString = ""
        
        if model.ratings.count == 0 {
            ratingsString = ""
        } else {
       
             ratingsString = model.ratings.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString

        }
        
        timeLabel.text = "\(startingDateSting) \(start) - \(end) \(ratingsString) "
        
    }
    
}
