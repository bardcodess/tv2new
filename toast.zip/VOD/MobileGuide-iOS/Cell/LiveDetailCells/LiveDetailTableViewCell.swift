//
//  LiveDetailTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class LiveDetailTableViewCell: UITableViewCell {

    @IBOutlet var descriptionUnderTabView: UIView!
    @IBOutlet var showTimeUnderTabView: UIView!
   
   // @IBOutlet var showTimeView: UIView!
    @IBOutlet var showTimeTab: UIView!
    @IBOutlet var showTimeTableView: UITableView!
    
    @IBOutlet var showTimeView: UIView!
    @IBOutlet var episodeLabel: UILabel!
    @IBOutlet var summaryLabel: UILabel!
    @IBOutlet var channelDetail: UILabel!
    @IBOutlet var timeDetailLabel: UILabel!
    
    var showTimes = [ShowTimeResult]()
    
    @IBOutlet var descriptionView: UIView!
    
    @IBAction func descriptionTabTapped(_ sender: Any) {
        showTimeView.isHidden = true
        descriptionView.isHidden = false
        descriptionUnderTabView.isHidden = false
        showTimeUnderTabView.isHidden = true
    }
    
    
    @IBAction func showTimesTabTapped(_ sender: Any) {
        descriptionView.isHidden = true
        showTimeView.isHidden = false
        showTimeUnderTabView.isHidden = false
        descriptionUnderTabView.isHidden = true
    }
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
       showTimeTableView.delegate = self
        showTimeTableView.dataSource = self
        showTimeTableView.register(UINib(nibName: "LiveShowTimesTableViewCell", bundle:  nil), forCellReuseIdentifier: "showTimesCell")
        
        
        showTimeTab.isHidden = true
        showTimeUnderTabView.isHidden = true
        showTimeView.isHidden = true
        
       // showTimeView.isHidden = true
        descriptionUnderTabView.backgroundColor = appDelegate.getOperatoColor()
        showTimeUnderTabView.backgroundColor = appDelegate.getOperatoColor()
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(model: DetailLiveModel, showTimes: [ShowTimeResult]){
        episodeLabel.text = model.episodeTitle
        summaryLabel.text = model.description
        channelDetail.text = "\(model.channelId ?? "") \(model.channelCallLetter ?? "")"
        
        var startingDateSting = DateUtility.shared.UTCToLocal(date: model.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        startingDateSting = DateUtility.shared.formatRelativeDate(startingDateSting)
        
        let start = DateUtility.shared.UTCToLocal(date: model.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        let end = DateUtility.shared.UTCToLocal(date: model.end ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        var ratingsString = ""
        
        if model.ratings.count == 0 {
            ratingsString = ""
        } else {
       
             ratingsString = model.ratings.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString

        }
        
        timeDetailLabel.text = "\(startingDateSting) \(start) - \(end) \(ratingsString) "
        
        
        
        if showTimes.count > 0 {
            self.showTimes = showTimes
            showTimeTab.isHidden = false
            DispatchQueue.main.async {
                self.showTimeTableView.reloadData()
            }
        }
    }
    
  private  func configureFromShowtime(model: ShowTimeResult) {
      episodeLabel.text = model.episodeTitle
        summaryLabel.text = model.description
        channelDetail.text = "\(model.channelId ?? "") \(model.channelCallLetter ?? "")"
        
        var startingDateSting = DateUtility.shared.UTCToLocal(date: model.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        startingDateSting = DateUtility.shared.formatRelativeDate(startingDateSting)
        
        let start = DateUtility.shared.UTCToLocal(date: model.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        let end = DateUtility.shared.UTCToLocal(date: model.end ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        var ratingsString = ""
        
        if model.ratings.count == 0 {
            ratingsString = ""
        } else {
       
             ratingsString = model.ratings.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString

        }
        
        timeDetailLabel.text = "\(startingDateSting) \(start) - \(end) \(ratingsString) "
        
    }
    
}

extension LiveDetailTableViewCell: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        showTimes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "showTimesCell", for: indexPath) as! LiveShowTimesTableViewCell
        cell.episodeLabel.text = showTimes[indexPath.row].episodeTitle
        cell.preservesSuperviewLayoutMargins = false
        cell.separatorInset = UIEdgeInsets.zero
        cell.layoutMargins = UIEdgeInsets.zero
        cell.configure(model:  showTimes[indexPath.row])
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        configureFromShowtime(model: showTimes[indexPath.row])
       
        descriptionView.isHidden = false
        showTimeView.isHidden = true
        showTimeUnderTabView.isHidden = true
        descriptionUnderTabView.isHidden = false
        
       
        
        
        
    }
    
    
}
