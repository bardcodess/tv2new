//
//  LiveActionTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 29/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class LiveActionTableViewCell: UITableViewCell {

    @IBOutlet var actionCollectionView: UICollectionView!
    @IBOutlet var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(model: DetailLiveModel) {
        titleLabel.text = model.programTitle
    }
}
