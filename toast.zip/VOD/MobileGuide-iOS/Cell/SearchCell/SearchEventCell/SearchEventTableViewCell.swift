//
//  SearchEventTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 05/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class SearchEventTableViewCell: UITableViewCell {

    @IBOutlet var shortDescriptionLabel: UILabel!
    
    @IBOutlet var detaillabel: UILabel!
    
    @IBOutlet var titleLabel: UILabel!
    
    @IBOutlet var stackLabel: UILabel!
    
    @IBOutlet var posterImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(with model: EventProgram) {
        guard let url = URL(string: model.iconSrc ?? "") else {
            return
        }
        
       posterImage.sd_setImage(with: url,placeholderImage: UIImage(named: "default_asset.png"))
        var relativeTime = DateUtility.shared.getDateFromUTCString(from: model.startTime ?? "")
        relativeTime = DateUtility.shared.formatRelativeDate(relativeTime)
        let startTime = DateUtility.shared.getLocaTimeString(from: model.startTime ?? "")
        let endTime = DateUtility.shared.getLocaTimeString(from: model.endTime ?? "")
        
        var ratingsString = ""
        
        if model.ratings.count > 0 {
            ratingsString = ""
        } else {
            ratingsString = (model.ratings.map { $0.value }.joined(separator: ", "))
            ratingsString = "•" + ratingsString
        }
        
        let detailText = "\(relativeTime) \(startTime)-\(endTime) \(ratingsString)"
        detaillabel.text = detailText
        titleLabel.text = model.title
        stackLabel.text = detailText
        shortDescriptionLabel.text = model.programDescription ?? ""

        
    }
    
}
