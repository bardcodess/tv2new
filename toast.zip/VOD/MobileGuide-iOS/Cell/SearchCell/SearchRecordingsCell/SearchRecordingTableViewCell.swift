//
//  SearchRecordingTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 02/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class SearchRecordingTableViewCell: UITableViewCell {

    @IBOutlet var posterImage: UIImageView!

    @IBOutlet var posterImageWidthConstraint: NSLayoutConstraint!
    @IBOutlet var title: UILabel!
    @IBOutlet var detailsLabel: UILabel!
    @IBOutlet var shortDescriptionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    override func prepareForReuse() {
        super.prepareForReuse()
        title.text = ""
        
        detailsLabel.text = ""
        shortDescriptionLabel.text = ""
        posterImage.image = UIImage(named: "default_asset.png")
    }
    
  // MARK: - For Search Recording
    func configureCell(with model: SearchRecordingsItem?, episodeCount: Int) {
        guard let url = URL(string: model?.iconSrc ?? "") else {
            return
        }
        
        title.text = model?.title
        posterImageWidthConstraint.constant = 150
        posterImage.contentMode = .scaleAspectFill
        posterImage.sd_setImage(with: url,placeholderImage: UIImage(named: "default_asset.png"))
        detailsLabel.isHidden = true
        shortDescriptionLabel.text = model?.shortDescription ?? ""
        shortDescriptionLabel.numberOfLines = 2
    
    }
    
    
    
    //MARK: - For Search Live
    func configureForLive(with model: LiveProgram?, channel: [Channel]) {
        guard let url = URL(string: model?.iconSrc ?? "") else {
            return
        }
        var filteredChannel = [Channel]()
        if channel.count > 0 {
            filteredChannel = channel.filter({$0.channelId == model?.channelId ?? "27"})
        }
        
        title.text = model?.programTitle
        posterImage.sd_setImage(with: url,placeholderImage: UIImage(named: "default_asset.png"))
       
        posterImageWidthConstraint.constant = 150
        posterImage.contentMode = .scaleAspectFill
        var relativeTime = DateUtility.shared.UTCToLocal(date:  model?.start ?? "",incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        relativeTime = DateUtility.shared.formatRelativeDate(relativeTime)
        let startTime = DateUtility.shared.UTCToLocal(date: model?.start ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        let endTime = DateUtility.shared.UTCToLocal(date: model?.end ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")

        
        var ratingsString = ""
        
        if model?.ratings == nil {
            ratingsString = ""
        } else {
            ratingsString = (model?.ratings.map { $0.value }.joined(separator: ", "))!
            ratingsString = "•" + ratingsString
        }
        
        var channelNumber = 0
        if filteredChannel.count > 0 {
            channelNumber = filteredChannel[0].channelNumber 
        }
        var channelCallLetter = model?.channelCallLetter ?? ""
        
        var detailsText = "\(relativeTime) \(startTime)-\(endTime)\(ratingsString) \(channelNumber) \(channelCallLetter)"
        detailsLabel.text = detailsText
        
        guard var description = model?.reducedDescription else  {
            return
        }
        var descriptionText = ""
        if description.count > 0 {
            descriptionText = (model?.reducedDescription)!
        } else {
            descriptionText = (model?.description)!
        }
        shortDescriptionLabel.text = descriptionText
    }
    
    
    // MARK: - For Search VOD
    func configureForVod(with model: Recommendation?) {
        var urlString = ""
        guard let model = model else {
            return
        }
        
        guard let episode = model.episodes else{
            return
        }
        
        var detailsText = ""
        var shortSummary = ""
       
        if episode.count > 0 {
            urlString = episode[0].posters?.first(where: { $0.posterType == "poster" })?.posterUrl ?? ""
            var groupedSeasons = groupBySeason(for: episode)
            var seasonCount : String {
                if groupedSeasons.keys.count > 1 {
                    return "Seasons"
                } else {
                    return "Season"
                }
            }
            detailsText = "\(groupedSeasons.keys.count) \(seasonCount), \(episode.count) \(episode.count > 1 ? "Episodes" : "Episode")"
            
        } else {
            if( model.poster != nil && model.poster!.count > 0)
            {
                urlString = model.poster![0]
            }
            else
            {
                urlString = ""
            }
            var ratingsString = "•" + (model.rating ?? "")
            var year = model.year ?? ""
            detailsText = "\(DateUtility.shared.convertTimeDurationToHoursMinutes(model.runTime ?? "")) \(ratingsString) \(year)"
            shortSummary = model.shortSummary ?? ""
        }
     
        let url = URL(string: urlString)
        title.text = model.title
        posterImage.sd_setImage(with: url,placeholderImage: UIImage(named: "default_asset.png"))
      
        detailsLabel.text = detailsText
        shortDescriptionLabel.numberOfLines = 2
        shortDescriptionLabel.text = shortSummary
        
    }
    
    
    private func groupBySeason( for collection : [Recommendation]) -> [String:[Recommendation]] {
        var groupedObjects = [String: [Recommendation]]()
        for object in collection {
            let season = object.seasonNumber?.stringValue ?? ""
            if groupedObjects[season] != nil {
                groupedObjects[season]?.append(object)
            } else {
                groupedObjects[season] = [object]
            }
        }
        return groupedObjects
    }

}
