//
//  TabsCollectionViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 25/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class TabsCollectionViewCell: UICollectionViewCell {

    @IBOutlet var tabName: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = .blue
        underTabView.isHidden = true
       prepareTheme()
    }

    @IBOutlet var underTabView: UIView!
    
    private func prepareTheme() {
        let operatorName = appDelegate.operatorName
        switch operatorName {
        case "CCAP":
            underTabView.backgroundColor = UIColor(hex: Colors.ccapBrandColor.rawValue)
        case "NWTel":
            underTabView.backgroundColor = UIColor(hex: Colors.nwTelBranColor.rawValue)
        case  "TBAYTEL":
            underTabView.backgroundColor = UIColor(hex: Colors.tBayBrandColor.rawValue)
        case  "HARGRAY":
            underTabView.backgroundColor = UIColor(hex: Colors.hargrayBrandColor.rawValue)
        default:
            print("default")
        }
    
    }
    override var isSelected: Bool {
        didSet{
            
            underTabView.isHidden = isSelected ? false : true
        }
    }
   
    
}
