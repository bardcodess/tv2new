//
//  HomeCollectionTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by nikhlesh on 26/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit



protocol CollectionViewCellDelegate: class {
    func collectionView(collectionviewcell: HomeCollectionViewCell?, index: Int, didTappedInTableViewCell: HomeCollectionTableViewCell)
    // other delegate methods that you can define to perform action in viewcontroller
}


class HomeCollectionTableViewCell: UITableViewCell, UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    var homeCellTapDelegate: CollectionViewCellDelegate?
    
    static let identifier = "HomeCollectionTableViewCell"
    static func nib() -> UINib{
        return UINib(nibName: "HomeCollectionTableViewCell", bundle: nil)
    }
    
    
    @IBOutlet var collectionView : UICollectionView!
    
    var models = [HomeDataModel]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.register(HomeCollectionViewCell.nib(), forCellWithReuseIdentifier: HomeCollectionViewCell.identifier)
        collectionView.delegate = self
        collectionView.dataSource = self
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    // collectionView
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = models.first!.isAsset ? CGSize(width: collectionView.frame.width/3 - 20, height:  190) : CGSize(width: collectionView.frame.width - 200 , height:  160)
        return size
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomeCollectionViewCell.identifier, for: indexPath) as! HomeCollectionViewCell
        cell.configure(with: models[indexPath.row])
        return cell
    }
    
    func configure(with models : [HomeDataModel])
    {
        self.models = models
        DispatchQueue.main.async { [weak self] in
            self?.collectionView.reloadData()
            
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            let cell = collectionView.cellForItem(at: indexPath) as? HomeCollectionViewCell
            self.homeCellTapDelegate?.collectionView(collectionviewcell: cell, index: indexPath.item, didTappedInTableViewCell: self)
        }
}
