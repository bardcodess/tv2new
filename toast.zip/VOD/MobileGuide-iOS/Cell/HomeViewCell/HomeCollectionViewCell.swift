//
//  HomeCollectionViewCell.swift
//  MobileGuide-iOS
//
//  Created by nikhlesh on 26/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class HomeCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var  title : UILabel!
    @IBOutlet var  assetPoster : UIImageView!
    @IBOutlet var  seriesLabel: UILabel!
    
    var cellData : HomeDataModel!
    static  let identifier = "HomeCollectionViewCell"
    
    static func nib() -> UINib{
        return UINib(nibName: "HomeCollectionViewCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        assetPoster.image = nil
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if(!cellData.isAsset)
        {
            contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15))
        }
        
    }
    
    public func configure (with model : HomeDataModel)
    {
        var poster: String
        cellData = model
        if(model.isAsset)
        {
            if model.isSeriesIndicator {
                poster = model.assetDetails?.episodes?.first?.posters?.first(where: { $0.posterType == "poster" })?.posterUrl ?? ""
                seriesLabel.isHidden = false
            } else {
                if(model.assetDetails?.posters == nil || model.assetDetails?.posters?.count == 0)
                {
                    if model.assetDetails?.poster != nil {
                        
                        if(model.assetDetails?.poster?.count == 0)
                        {
                            poster = ""
                        }
                        else
                        {
                            poster =  model.assetDetails?.poster?[0] ?? ""
                        }
                        
                    } else {
                        poster = ""
                    }
                }
                else
                {
                    poster = model.assetDetails?.posters?.first(where: { $0.posterType == "poster" })?.posterUrl ?? ""
                }
                seriesLabel.isHidden = true
                
            }
        }
        else
        {
            poster = model.channelLogoURL ?? ""
            if(model.isSeriesIndicator)
            {
                seriesLabel.isHidden = false
            }
            else
            {
                seriesLabel.isHidden = true
            }
        }
        
        self.title.text = model.programName
        guard let url = URL(string: poster) else {
            return
        }
        assetPoster.sd_setImage(with: url, completed: nil)
        
    }
    
}
