//
//  RecordingDetailTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 03/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class RecordingDetailTableViewCell: UITableViewCell {

    @IBOutlet var progressLabel: UILabel!
    @IBOutlet var summaryLabel: UILabel!
    @IBOutlet var underTabView: UIView!
    @IBOutlet var episodeLabel: UILabel!
    @IBOutlet var descriptionLabel: UILabel!
    @IBOutlet var channelLabel: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        underTabView.backgroundColor = appDelegate.getOperatoColor()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(model: DetailRecordingsModel) {
        episodeLabel.text = model.episodeTitle
        var recordingDate = DateUtility.shared.UTCToLocal(date: (model.actualStartUtc ?? model.scheduledStartUtc) ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        let start = DateUtility.shared.UTCToLocal(date: (model.actualStartUtc ?? model.scheduledStartUtc) ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        let end = DateUtility.shared.UTCToLocal(date: (model.actualEndUtc ?? model.scheduledEndUtc) ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        recordingDate = DateUtility.shared.formatRelativeDate(recordingDate)
        let recordingTime =  DateUtility.shared.getLocaTimeString(from: (model.actualStartUtc ?? model.scheduledStartUtc) ?? "")
        
        let season = model.seasonNumber != nil ?  "S\(model.seasonNumber!)" : ""
        let episode = model.episodeNumber != nil ?  "E\(model.episodeNumber!)• " : ""
        
        var ratingsString = ""
        
        if model.ratings == nil || model.ratings?.count == 0 {
            ratingsString = ""
        } else {
//            for item in model.ratings! {
//                ratingsString = ratingsString + " ," + item.value
//            }
             ratingsString = model.ratings!.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString
//            print("Dfdf")
//            print(model.ratings?.count)
//            let ratingsString = model.ratings!.map { $0.value }.joined(separator: ", ")
        }
        
        descriptionLabel.text = "\(season+episode)\(recordingDate) \(start) - \(end) \(ratingsString)"
        
        
        progressLabel.text = "Recording is in progress"
        channelLabel.text  = "\(model.channelNumber ?? 0) \(model.channelCallLetter ?? "")"
        
        summaryLabel.text = "\(model.shortSummary ?? "")"
    }
    
}
