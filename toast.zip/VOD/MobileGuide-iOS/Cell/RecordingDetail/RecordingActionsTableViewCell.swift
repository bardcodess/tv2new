//
//  RecordingActionsTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 02/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class RecordingActionsTableViewCell: UITableViewCell {

    @IBOutlet private var actionCollectionView: UICollectionView!
    @IBOutlet private var titleLabel: UILabel!
     var actionButtons = [String]()
    var model: DetailRecordingsModel?
    var rootViewController : UIViewController?
    var isSeries : Bool?
    override func awakeFromNib() {
        super.awakeFromNib()
        actionCollectionView.delegate = self
        actionCollectionView.dataSource = self
        actionCollectionView.register(UINib(nibName: "VODButtonsCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "actionButtonCell")
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(model: DetailRecordingsModel, rootVC: UIViewController) {
        titleLabel.text = model.title ?? ""
        if model.isRecordingCompleted {
            actionButtons = ["Watch","Delete"]
        } else {
            actionButtons = ["Manage","Delete"]
        }
        
       rootViewController = rootVC
        self.isSeries = model.isSeries
        self.model = model
        DispatchQueue.main.async {
            self.actionCollectionView.reloadData()
        }
    }
    
    
}

extension RecordingActionsTableViewCell : UICollectionViewDelegate , UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        actionButtons.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "actionButtonCell", for: indexPath) as! VODButtonsCollectionViewCell
        cell.configure(image: actionButtons[indexPath.row], title: actionButtons[indexPath.row])
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        2
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width:  65, height: 50)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        10
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let actionButton = actionButtons[indexPath.row]
        
        switch actionButton {
        case "Manage" :
            let vc = RecordingSettingViewController.instantiate(scheduledRecordingData: model!)
            rootViewController?.navigationController?.pushViewController(vc, animated: true)
            
        default:
        print("DFd")
        }
    }
    
    
}
