//
//  OnDemadTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by nikhlesh on 14/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

protocol OnDemandCollectionViewCellDelegate: class {
    func onDemandcollectionView(onDemandCollectionviewcell: OnDemandCollectionViewCell?, index: Int, onDemandTableViewCell: OnDemadTableViewCell)
    // other delegate methods that you can define to perform action in viewcontroller
}


class OnDemadTableViewCell: UITableViewCell,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    
    @IBOutlet weak var viewallbutton: UIButton!
    var models = [Recommendation]()
    var isLastCat = false
    @IBOutlet weak var collectionView: UICollectionView!
    var onDemandCellTapDelegate: OnDemandCollectionViewCellDelegate?
    
    static let identifier = "OnDemadTableViewCell"
    static func nib() -> UINib{
        return UINib(nibName: "OnDemadTableViewCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        collectionView.register(OnDemandCollectionViewCell.nib(), forCellWithReuseIdentifier: OnDemandCollectionViewCell.identifier)
        collectionView.delegate = self
        collectionView.dataSource = self
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        models.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let size = CGSize(width: collectionView.frame.width/3 - 20, height:  200)
        return size
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: OnDemandCollectionViewCell.identifier, for: indexPath) as! OnDemandCollectionViewCell
        cell.configure(with: models[indexPath.row])
        if let flowLayout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            // Modify the scroll direction here
            if(self.isLastCat)
            {
                flowLayout.scrollDirection = .vertical
            }
            else
            {
                flowLayout.scrollDirection = .horizontal
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
            let cell = collectionView.cellForItem(at: indexPath) as? OnDemandCollectionViewCell
        self.onDemandCellTapDelegate?.onDemandcollectionView(onDemandCollectionviewcell: cell, index: indexPath.item, onDemandTableViewCell: self)
        
        }
    
    
    
    func configure(with models : [Recommendation] , isLast : Bool = false)
    {
        self.models = models
        self.isLastCat = isLast
        DispatchQueue.main.async { [weak self] in
            self?.collectionView.reloadData()
            
        }
    }
    
}
