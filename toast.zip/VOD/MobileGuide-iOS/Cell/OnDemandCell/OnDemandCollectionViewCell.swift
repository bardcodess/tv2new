//
//  OnDemandCollectionViewCell.swift
//  MobileGuide-iOS
//
//  Created by nikhlesh on 14/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class OnDemandCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var seriesLabel: UILabel!
    
    @IBOutlet weak var assetTitle: UILabel!
    
    @IBOutlet weak var assetPoster: UIImageView!
    
    static  let identifier = "OnDemandCollectionViewCell"
    
    static func nib() -> UINib{
        return UINib(nibName: "OnDemandCollectionViewCell", bundle: nil)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    public func configure (with model : Recommendation)
    {
        var posterUrl = ""
        self.assetTitle.text = model.title
        let isSeries = model.assetType?.lowercased() == "series"
        if(isSeries)
        {
            posterUrl = GetPosterURL(with: model.episodes!)
            seriesLabel.isHidden = false
        }
        else
        {
            if model.poster != nil {
                
                if(model.poster?.count == 0)
                {
                    posterUrl = ""
                }
                else
                {
                    posterUrl =   model.poster?[0] ?? ""
                }
                
            } else {
                posterUrl = ""
            }
            seriesLabel.isHidden = true
        }
        guard let url = URL(string: posterUrl) else {
            return
        }
        assetPoster.sd_setImage(with: url, placeholderImage: UIImage(named: "default_asset.png"), completed: nil)
    }
    
    func GetPosterURL(with episodes : [Recommendation]) -> String
    {
        
        var posterUrl = ""
        if (episodes.count > 0)
        {
            if ((episodes[0].posters?.first(where: { $0.posterType == "poster" })?.posterUrl) != nil)
            {
                posterUrl = (episodes[0].posters?.first(where: { $0.posterType == "poster" })!.posterUrl)!
                
            }
            else if (episodes[0].poster != nil)
            {
                posterUrl = (episodes[0].poster?.first)!;
            }
        }
        return posterUrl
    }
    
}
