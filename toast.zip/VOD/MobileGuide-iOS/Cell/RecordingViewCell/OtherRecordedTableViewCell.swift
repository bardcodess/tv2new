//
//  OtherRecordedTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 22/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class OtherRecordedTableViewCell: UITableViewCell {
    @IBOutlet var seasonDateLabel: UILabel!
    
    @IBOutlet var descriptionLabel: UILabel!
    
    @IBOutlet var containerView: UIView!
    @IBOutlet var showTitle: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
       
        // Initialization co
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configure(with model:ItemSchedule){
        showTitle.text = model.episodeTitle ?? model.title
        descriptionLabel.text = model.description ?? model.shortDescription
        
        var recordingDate = DateUtility.shared.UTCToLocal(date: model.scheduledStartUtc ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        recordingDate = DateUtility.shared.formatRelativeDate(recordingDate)
        var recordingTime = DateUtility.shared.UTCToLocal(date: (model.scheduledStartUtc) ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        let season = model.seasonNumber != nil ?  "S\(model.seasonNumber!)" : ""
        let episode = model.episodeNumber != nil ?  "E\(model.episodeNumber!)•" : ""
        //let seasonDateText = String(describing: season+episode) + "*" + String(describing: recordingTime)
        
        let durationStringToTimeInter = DateUtility.shared.timeIntervalFromSeconds(model.duration)
        let duration = DateUtility.shared.formatDuration(durationStringToTimeInter)
        
        var ratingsString = ""
        
        if model.ratings == nil {
            ratingsString = ""
        } else {

            ratingsString = model.ratings!.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString
        }
        
        
        
        let seasonDateText = "\(season+episode)\(recordingDate) \(recordingTime)•\(duration)\(ratingsString)"
        
        seasonDateLabel.text = seasonDateText
    }
    
    func configureForRecordings(with model:Item) {
        showTitle.text = model.episodeTitle ?? model.title
        descriptionLabel.text = model.description ?? model.shortDescription
        
        var recordingDate = DateUtility.shared.UTCToLocal(date: model.actualStartUtc!, incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        recordingDate = DateUtility.shared.formatRelativeDate(recordingDate)
        var recordingTime = DateUtility.shared.UTCToLocal(date: (model.actualStartUtc)!, incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
       
        let season = model.seasonNumber != nil ?  "S\(model.seasonNumber!)" : ""
        let episode = model.episodeNumber != nil ?  "E\(model.episodeNumber!)•" : ""
        //let seasonDateText = String(describing: season+episode) + "*" + String(describing: recordingTime)
        
        let durationStringToTimeInter = DateUtility.shared.timeIntervalFromSeconds(model.duration)
        let duration = DateUtility.shared.formatDuration(durationStringToTimeInter)
        
        var ratingsString = ""
        
        if model.ratings == nil {
            ratingsString = ""
        } else {
//            for item in model.ratings! {
//                ratingsString = ratingsString + " ," + item.value
//            }
             ratingsString = model.ratings!.map { $0.value }.joined(separator: ",")
            ratingsString = "•" + ratingsString
//            print("Dfdf")
//            print(model.ratings?.count)
//            let ratingsString = model.ratings!.map { $0.value }.joined(separator: ", ")
        }
        
        
        
        let seasonDateText = "\(season+episode)\(recordingDate) \(recordingTime)•\(duration)\(ratingsString)"
        
        seasonDateLabel.text = seasonDateText
    }
    
}
