//
//  RecordTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 17/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit
import SDWebImage

protocol HeaderDelegate {
    func callHeader(idx: Int)
}


class RecordTableViewCell: UITableViewHeaderFooterView {
    @IBOutlet var descriptionLabel: UILabel!
    
    @IBOutlet var seriesIndicatorLabel: UILabel!
    @IBOutlet var postetImage: UIImageView!
    @IBOutlet public var showName: UILabel!
    @IBOutlet var deleteButton: UIButton!
    @IBOutlet var expandButton: UIButton!
    
    @IBAction func expandCollapseBtnTapped(_ sender: Any) {
        if let idx = secIndex {
            delegate?.callHeader(idx: idx)
            
        }
    }
    var secIndex : Int?
    var delegate : HeaderDelegate?
    override func awakeFromNib() {
        super.awakeFromNib()
        seriesIndicatorLabel.layer.masksToBounds = true
        seriesIndicatorLabel.layer.cornerRadius = 5
        // Initialization code
    }
    
    override func prepareForReuse() {
            super.prepareForReuse()
        expandButton.isHidden = false
        seriesIndicatorLabel.isHidden = false
        descriptionLabel.isHidden = true
            // Clear all content based views and their actions here
        }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
    
    func configureCell(with model: ExpandedRecordedCells, isDeleteVisible: Bool) {
        showName.text = model.section.title
        guard let url = URL(string: model.section.iconSrc) else {
            return
        }
        let otherRecordedEpiCount = model.otherRecordedItems?.count ?? 0
        descriptionLabel.isHidden = true
        
        var recordingDate = DateUtility.shared.UTCToLocal(date: model.section.actualStartUtc!, incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
        recordingDate = DateUtility.shared.formatRelativeDate(recordingDate)
        var recordingTime = DateUtility.shared.UTCToLocal(date: model.section.scheduledStartUtc!, incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
        //let recordingTime =  DateUtility.shared.getLocaTimeString(from: model.section.scheduledStartUtc!)
        let season = model.section.seasonNumber != nil ?  "S\(model.section.seasonNumber!)" : ""
        let episode = model.section.episodeNumber != nil ?  "S\(model.section.episodeNumber!)•" : ""
        //let seasonDateText = String(describing: season+episode) + "*" + String(describing: recordingTime)
        let durationStringToTimeInter = DateUtility.shared.timeIntervalFromSeconds(model.section.duration)
        let duration = DateUtility.shared.formatDuration(durationStringToTimeInter)
        
        var ratingsString = ""
        
        if model.section.ratings == nil {
            ratingsString = ""
        } else {
            ratingsString = model.section.ratings!.map { $0.value }.joined(separator: ", ")
            ratingsString = "•" + ratingsString
        }
        
        let seasonDateText = "\(season+episode)\(recordingDate) \(recordingTime)•\(duration)\(ratingsString)"
        
        descriptionLabel.text = seasonDateText
        
        
        if otherRecordedEpiCount < 2 {
            expandButton.isHidden = true
            seriesIndicatorLabel.isHidden = true
            descriptionLabel.isHidden = false
        }

        postetImage.sd_setImage(with: url)
    }
    
    
    
    
    
    
    func configureCellSchedule(with model: ExpandedScheduledCells) {
        showName.text = model.section.title
       
        guard let url = URL(string: model.section.iconSrc) else {
            return
        }
        deleteButton.isHidden = true
        
        descriptionLabel.isHidden = true
        
        var recordingDate = DateUtility.shared.UTCToLocal(date: model.section.scheduledStartUtc ?? "", incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "dd/MM/YYYY")
       
        recordingDate = DateUtility.shared.formatRelativeDate(recordingDate)
        var recordingTime = DateUtility.shared.UTCToLocal(date: (model.section.scheduledStartUtc ?? model.section.startUtc)!, incomingFormat: "yyyy-MM-dd'T'HH:mm:ss.SSSZ", outGoingFormat: "hh:mm a")
       
        let season = model.section.seasonNumber != nil ?  "S\(model.section.seasonNumber!)" : ""
        let episode = model.section.episodeNumber != nil ?  "S\(model.section.episodeNumber!)•" : ""
        //let seasonDateText = String(describing: season+episode) + "*" + String(describing: recordingTime)
        
        let durationStringToTimeInter = DateUtility.shared.timeIntervalFromSeconds(model.section.duration)
        let duration = DateUtility.shared.formatDuration(durationStringToTimeInter)
        
        var ratingsString = ""
        
        if model.section.ratings == nil {
            ratingsString = ""
        } else {
//            for item in model.section.ratings! {
//                ratingsString = ratingsString + " ," + item.value
//            }
            
            
            ratingsString = model.section.ratings!.map { $0.value }.joined(separator: ", ")
            ratingsString = "•" + ratingsString
            
        }
        
        
        let seasonDateText = "\(season+episode)\(recordingDate) \(recordingTime)•\(duration)\(ratingsString)"
        
        descriptionLabel.text = seasonDateText
        
        
        let otherScheduleEpiCount = model.otherScheduledEpisodes?.count ?? 0
        if otherScheduleEpiCount < 2 {
            expandButton.isHidden = true
            seriesIndicatorLabel.isHidden = true
            descriptionLabel.isHidden = false
        }
        
        postetImage.sd_setImage(with: url)
    }

    
    
}
