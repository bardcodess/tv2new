//
//  RecordedTableFooter.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 13/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class RecordedTableFooter: UIView {

    var onButtonClicked: (()-> Void)?
   // var buttonTitle: String
    
    private let button : UIButton =  {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = .white
        btn.setTitle("View all", for: .normal)
        btn.setTitleColor(.black, for: .normal)
        btn.layer.cornerRadius = 10
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
      //  self.buttonTitle = title
        self.addSubview( button)
    
        button.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            button.topAnchor.constraint(equalTo: self.topAnchor, constant: 2),
            button.widthAnchor.constraint(equalToConstant: 200),
            button.heightAnchor.constraint(equalToConstant: 44)
        ])
        
        self.button.addTarget(self, action: #selector(didTap), for: .touchUpInside)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func didTap() {
        self.onButtonClicked?()
    }
    
    
    
}
