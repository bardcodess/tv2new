//
//  FailedTableHeader.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 13/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class FailedTableHeader: UIView {

    var onButtonClicked: (()-> Void)?
   // var buttonTitle: String
    
    private let button : UIButton =  {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = .white
        btn.setTitle("Clear all", for: .normal)
        btn.setTitleColor(.black, for: .normal)
        btn.layer.cornerRadius = 10
        return btn
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
      //  self.buttonTitle = title
        self.addSubview( button)
    
        button.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            button.centerXAnchor.constraint(equalTo: self.centerXAnchor),
            button.centerYAnchor.constraint(equalTo: self.centerYAnchor),
            button.widthAnchor.constraint(equalToConstant: 150),
            button.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        self.button.addTarget(self, action: #selector(didTap), for: .touchUpInside)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc private func didTap() {
        self.onButtonClicked?()
    }
    
    

}
