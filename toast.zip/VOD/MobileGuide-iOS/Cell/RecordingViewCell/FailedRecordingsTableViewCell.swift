//
//  FailedRecordingsTableViewCell.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 30/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class FailedRecordingsTableViewCell: UITableViewCell {

    @IBOutlet var statusLabel: UILabel!
    @IBOutlet var detailLabel: UILabel!
    @IBOutlet var titleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func configureCell(with model: ItemFailedRecording){
        titleLabel.text = model.title
        
       
        let recordingTime =  DateUtility.shared.getLocaTimeString(from: model.start!)
       
        //let seasonDateText = String(describing: season+episode) + "*" + String(describing: recordingTime)
        
        
        let channelCallLetter = model.channelCallLetter ?? ""
        
        
        
        let seasonDateText = "\(recordingTime) \(channelCallLetter)"
        
        detailLabel.text = seasonDateText
        
        
        
        statusLabel.text = "Failure reason: "+(model.failReason ?? "")
    }
    
}
