//
//  Date+UTCConvert.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 31/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class DateUtility {
    
    public static let shared = DateUtility()
    
    private init() {}
    
    func getDateFromUTCString(from dateString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")

        if let utcDate = dateFormatter.date(from: dateString) {
            // Convert to local time
            let localDate = utcDate.addingTimeInterval(TimeInterval(TimeZone.current.secondsFromGMT()))
            
            // Create separate date and time formatters
            let localDateFormatter = DateFormatter()
            localDateFormatter.dateFormat = "yyyy-MM-dd"
            localDateFormatter.timeZone = TimeZone.current
            
            let localDateString = localDateFormatter.string(from: localDate)
           
            return localDateString


        } else {
            return "Invalid Date"
        }

    }
    
    
    func UTCToLocal(date: String ,incomingFormat: String, outGoingFormat: String) -> String {
       let dateFormatter = DateFormatter()
       dateFormatter.dateFormat = incomingFormat
       dateFormatter.timeZone = TimeZone(abbreviation: "UTC")

       let dt = dateFormatter.date(from: date)
       dateFormatter.timeZone = TimeZone.current
       dateFormatter.dateFormat = outGoingFormat
       
       return dateFormatter.string(from: dt ?? Date())
     }
    
    
    func formatRelativeDate(_ dateString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd/MM/yyyy"
        
        
        
        if let parsedDate = dateFormatter.date(from: dateString) {
            var calendar = Calendar.current
            
            let today = parsedDate
            let yesterday = calendar.date(byAdding: .day, value: -1, to: parsedDate)
            let tomorrow = calendar.date(byAdding: .day, value: 1, to: parsedDate)
            
            dateFormatter.dateFormat = "dd/MM/yyyy"
            
            if calendar.isDateInToday(today) {
                return "Today"
            } else if calendar.isDateInYesterday(yesterday!) {
                return "Yesterday"
            } else if calendar.isDateInTomorrow(tomorrow!) {
                return "Tomorrow"
            } else {
                return dateFormatter.string(from: today)

            }
            
            
        } else {
            return "Invalid date format"
        }
        
    }
    
    func getLocaTimeString(from dateString: String) -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSSZ"
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")

        if let utcDate = dateFormatter.date(from: dateString) {
            // Convert to local time
            let localDate = utcDate.addingTimeInterval(TimeInterval(TimeZone.current.secondsFromGMT()))
            
            // Create separate date and time formatters
           
            
            let localTimeFormatter = DateFormatter()
            localTimeFormatter.dateFormat = "HH:mm a"
            localTimeFormatter.timeZone = TimeZone.current
            
        
            let localTimeString = localTimeFormatter.string(from: localDate)
            

           return localTimeString
        } else {
            return "Invalid date format"
        }

    }
    
  
    
    func formatDuration(_ seconds: TimeInterval) -> String {
        let hours = Int(seconds) / 3600
        let minutes = (Int(seconds) % 3600) / 60
        
        var formattedDuration = ""
        
        if hours > 0 {
            formattedDuration += "\(hours)h "
        }
        
        if minutes > 0 {
            formattedDuration += "\(minutes)m"
        }
        
        return formattedDuration.isEmpty ? "0m" : formattedDuration
    }
    
    func timeIntervalFromSeconds(_ seconds: Int) -> TimeInterval {
        return TimeInterval(seconds)
    }
    
    
    func convertTimeDurationToHoursMinutes(_ timeDuration: String) -> String {
        let components = timeDuration.components(separatedBy: ":")
        
        if components.count == 3,
           let hours = Int(components[0]),
           let minutes = Int(components[1]),
           let _ = Int(components[2]) {
            if hours == 0 {
                return "\(minutes) minutes"
            } else {
                return "\(hours)h \(minutes)m"
            }
        } else {
            // Handle invalid input gracefully
            return "Invalid input"
        }
    }
    
    func timeStringToDateComponents(_ timeString: String) -> DateComponents? {
        let dateFormatter = DateFormatter()
        
        // Define possible date formats
        let formats = ["HH:mm:ss", "HH:mm:ss:SSS"]

        for format in formats {
            dateFormatter.dateFormat = format
            if let date = dateFormatter.date(from: timeString) {
                let calendar = Calendar.current
                let dateComponents = calendar.dateComponents([.hour, .minute, .second, .nanosecond], from: date)
                return dateComponents
            }
        }

        return nil
    }
    
    func calculateRemainingTime(startingTime: DateComponents, endingTime: DateComponents) -> DateComponents {
        let calendar = Calendar.current

        // Create NSDate objects from DateComponents
        let startDate = calendar.date(from: startingTime)!
        let endDate = calendar.date(from: endingTime)!

        // Calculate the remaining time by subtracting the end date from the start date
        let remainingTime = calendar.dateComponents([.hour, .minute, .second], from: startDate, to: endDate)

        return remainingTime
    }


}
