//
//  UIFontExtensions.swift
//  MobileGuide-iOS
//
//  Created by MA-15 on 17/07/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit
extension UIFont {
    /// Enum for App Fonts
    public enum FontTypes {
        case AvenirNext_Regular
        case AvenirNext_Medium
        case AvenirNext_Bold

        var name: String {
            switch self {
            case .AvenirNext_Regular:
                return "AvenirNext-Regular"
            case .AvenirNext_Medium:
                return "AvenirNext-Medium"
            case .AvenirNext_Bold:
                return "AvenirNext-Bold"
            }
        }
    }
    
    var scaled: UIFont {
        return UIFontMetrics.default.scaledFont(for: self)
    }
    
    public convenience init(type: FontTypes = .AvenirNext_Regular, size: CGFloat) {
        self.init(name: type.name, size: size)!
    }
}

extension UIFont {
    
    class func AvenirNext_Regular(_ size: CGFloat) -> UIFont {
        
        let aFont = UIFont(type: .AvenirNext_Regular, size: size)
        return aFont
    }

    class func AvenirNext_Medium(_ size: CGFloat) -> UIFont {
        
        let aFont = UIFont(type: .AvenirNext_Medium, size: size)
        return aFont
        
    }
    
    class func AvenirNext_Bold(_ size: CGFloat) -> UIFont {
        
        let aFont = UIFont(type: .AvenirNext_Bold, size: size)
        return aFont
    }
}
