//
//  UIColorExtensions.swift
//  MobileGuide-iOS
//
//  Created by MA-15 on 17/07/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

// MARK: - Application colors
public extension UIColor {
    /// Initializes and returns a color object using the specified Hex values.
    ///
    ///
    ///     UIColor(hex: "95A5A6")
    /// or
    ///
    ///     UIColor(hex: "#95A5A6")
    ///
    ///
    /// - Parameters:
    ///   - hex: Hex String of the color. example: "95A5A6" or "#95A5A6"
    ///
    /// - Returns:
    /// The color object. The color information represented by this object is in an RGB colorspace. On applications linked for iOS 10 or later, the color is specified in an extended range sRGB color space. On earlier versions of iOS, the color is specified in a device RGB colorspace.
     convenience init(hex: String) {
        
        var cString = hex.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            let start = cString.index(cString.startIndex, offsetBy: 1)
            cString = String(cString[start...])
        }
        
        let rVal, gVal, bVal, aVal: CGFloat
        
        if cString.count == 6 {
            let scanner = Scanner(string: cString)
            var hexNumber: UInt64 = 0
            
            if scanner.scanHexInt64(&hexNumber) {
                rVal = CGFloat((hexNumber & 0xff0000) >> 16) / 255
                gVal = CGFloat((hexNumber & 0x00ff00) >> 8) / 255
                bVal = CGFloat(hexNumber & 0x0000ff) / 255
                aVal = 1.0
                
                self.init(red: rVal, green: gVal, blue: bVal, alpha: aVal)
                return
            }
        }
        
        self.init(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        return
        
    }
    
    convenience init(red: Int, green: Int, blue: Int, alpha: Float = 1.0) {
       assert(red >= 0 && red <= 255, "Invalid red component")
       assert(green >= 0 && green <= 255, "Invalid green component")
       assert(blue >= 0 && blue <= 255, "Invalid blue component")
       self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: CGFloat(alpha))
   }
   
   /// Hexadecimal value string (read-only).
   var hexString: String {
       
       var rVal: CGFloat = 0
       var gVal: CGFloat = 0
       var bVal: CGFloat = 0
       var aVal: CGFloat = 0
       
       getRed(&rVal, green: &gVal, blue: &bVal, alpha: &aVal)
       
       let rgb: Int = (Int)(rVal*255)<<16 | (Int)(gVal*255)<<8 | (Int)(bVal*255)<<0
       
       return String(format: "#%06x", rgb)
       
   }
   
   // swiftlint:disable next large_tuple
   /// SwifterSwift: RGB components for a Color (between 0 and 255).
   ///
   ///        UIColor.red.rgbComponents.red -> 255
   ///        NSColor.green.rgbComponents.green -> 255
   ///        UIColor.blue.rgbComponents.blue -> 255
   ///
   var rgbComponents: (red: Int, green: Int, blue: Int) {
       var components: [CGFloat] {
           let comps = cgColor.components!
           if comps.count == 4 { return comps }
           return [comps[0], comps[0], comps[0], comps[1]]
       }
       let red = components[0]
       let green = components[1]
       let blue = components[2]
       return (red: Int(red * 255.0), green: Int(green * 255.0), blue: Int(blue * 255.0))
   }
   
   /// Random color in Swift 4.0
    static var random: UIColor {
       
       //        let randomRed:CGFloat = CGFloat(drand48())
       //        let randomGreen:CGFloat = CGFloat(drand48())
       //        let randomBlue:CGFloat = CGFloat(drand48())
       
       let randomRed: CGFloat = .random()
       let randomGreen: CGFloat = .random()
       let randomBlue: CGFloat = .random()
       //        print(randomRed, randomGreen, randomBlue)
       return self.init(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
   }
   
   /// Random color in Swift 4.2
   //    public static var random: UIColor {
   //        let red = Int.random(in: 0..<255)
   //        let green = Int.random(in: 0..<255)
   //        let blue = Int.random(in: 0..<255)
   //        return UIColor(red: red, green: green, blue: blue)
   //    }

}

extension CGFloat {
    
    static func random() -> CGFloat {
        return CGFloat(arc4random()) / CGFloat(UInt32.max)
    }
    
}
