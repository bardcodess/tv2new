//
//  BaseTextField.swift
//  MobileGuide-iOS
//
//  Created by MA-15 on 17/07/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

open class BaseTextField: UITextField , UITextFieldDelegate{
    // MARK: - Overrides
    

    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialSetup()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        initialSetup()
    }
    
    private func initialSetup() {
        tintColor = #colorLiteral(red: 0.231372549, green: 0.231372549, blue: 0.2823529412, alpha: 1)
        backgroundColor = #colorLiteral(red: 0.8470588235, green: 0.8470588235, blue: 0.8470588235, alpha: 0.3)
        font = UIFont.AvenirNext_Medium(15)

        textColor = UIColor.black
        self.textAlignment = .left
        
        //guard placeholder != nil else { return }
        //guard let aStrTitle = placeholder?.localized else { return }
        // Stop infinite loop from didset
        //guard aStrTitle != placeholder else { return }
        //placeholder = aStrTitle
    }
    

    override open func awakeFromNib() {
        super.awakeFromNib()
        //self.tintColor = UIColor.TextField.bgText
        //self.backgroundColor = UIColor.
        self.paddingLeftCustom = 5.0
        self.paddingRightCustom = 5.0
    }
    open override func layoutSubviews() {
        super.layoutSubviews()
        
    }


}
// Toggle Password Show Hide
extension UITextField {
    
    /// Activate password toggle with icon
    func enablePasswordToggle() {
        
        // Add padding to right side to add a button.
        self.paddingRightCustom = 60.0
        
        // Create a button and add to the rightView of the textField.
        let button = UIButton(type: .custom)
        button.backgroundColor = .clear
        button.frame = CGRect(x: 0, y: 0, width: 40, height: CGFloat(40))
        button.addTarget(self, action: #selector(self.togglePasswordView), for: .touchUpInside)
        button.setImage(UIImage(named:"password_show"), for: .normal)
        button.setImage(UIImage(named:"password_hide"), for: .selected)
        button.tintColor = UIColor.black
        self.rightView?.addSubview(button)
        button.center  = self.rightView?.center ?? CGPoint.zero
        
    }
    
    @IBAction func togglePasswordView(_ sender: UIButton) {
        sender.isSelected = self.isSecureTextEntry
        self.isSecureTextEntry = !self.isSecureTextEntry
    }
    /// Activate password toggle with icon
    func enableEditToggle() {
        
        // Add padding to right side to add a button.
        self.paddingRightCustom = 60.0
        
        // Create a button and add to the rightView of the textField.
        let button = UIButton(type: .custom)
        button.backgroundColor = .clear
        button.frame = CGRect(x: 0, y: 0, width: 40, height: CGFloat(40))
        button.addTarget(self, action: #selector(self.toggleEditTextField), for: .touchUpInside)
        button.setImage(UIImage(named:"password_show"), for: .normal)
        button.setImage(UIImage(named:"password_hide"), for: .selected)
        self.rightView?.addSubview(button)
        button.tintColor = UIColor.black
        button.tintColor = UIColor.black
        button.center  = self.rightView?.center ?? CGPoint.zero
        
    }
    @IBAction func toggleEditTextField(_ sender: UIButton) {
        //sender.isSelected = self.isEnabled
        //self.isEnabled = !self.isEnabled
        self.isEnabled = true
        self.alpha = 1.0
    }
}
