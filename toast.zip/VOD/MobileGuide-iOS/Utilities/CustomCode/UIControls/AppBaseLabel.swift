//
//  AppBaseLabel.swift
//  MobileGuide-iOS
//
//  Created by MA-15 on 17/07/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import UIKit

class AppBaseLabel: UILabel
{
    required init(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)!
        createBaseLbl()
    }
    required override init(frame: CGRect) {
        super.init(frame: frame)
        createBaseLbl()
    }
    func createBaseLbl(){
        self.text = self.text
        //self.text = self.text?.localized
    }
}
extension UILabel {
    
    func boldSubstringTabpAble(_ substr: String, color: UIColor) {
        let readmoreFont = UIFont.AvenirNext_Medium(13)

        
        guard substr.isEmpty == false,
              let text = attributedText,
              let range = text.string.range(of: substr, options: .caseInsensitive) else {
            return
        }
        let attr = NSMutableAttributedString(attributedString: text)
        let start = text.string.distance(from: text.string.startIndex, to: range.lowerBound)
        let length = text.string.distance(from: range.lowerBound, to: range.upperBound)
        attr.addAttributes([NSAttributedString.Key.font: readmoreFont, NSAttributedString.Key.foregroundColor: color],
                           range: NSMakeRange(start, length))
        attributedText = attr
    }
    func boldandTapstring(_ substr: String, color: UIColor) {
        let readmoreFont = UIFont.AvenirNext_Medium(15)
      
        guard substr.isEmpty == false,
              let text = attributedText,
              let range = text.string.range(of: substr, options: .caseInsensitive) else {
            return
        }
        let attr = NSMutableAttributedString(attributedString: text)
        let start = text.string.distance(from: text.string.startIndex, to: range.lowerBound)
        let length = text.string.distance(from: range.lowerBound, to: range.upperBound)
        attr.addAttributes([NSAttributedString.Key.font: readmoreFont, NSAttributedString.Key.foregroundColor: color],
                           range: NSMakeRange(start, length))
        attributedText = attr
    }
    func boldUnderlineSubstring(_ substr: String) {
        guard substr.isEmpty == false,
              let text = attributedText,
              let range = text.string.range(of: substr, options: .caseInsensitive) else {
            return
        }
        let attr = NSMutableAttributedString(attributedString: text)
        let start = text.string.distance(from: text.string.startIndex, to: range.lowerBound)
        let length = text.string.distance(from: range.lowerBound, to: range.upperBound)
        attr.addAttributes([NSAttributedString.Key.font: UIFont.AvenirNext_Medium(13),NSAttributedString.Key.underlineStyle: NSUnderlineStyle.single.rawValue],
                           range: NSMakeRange(start, length))
        attributedText = attr
    }
}

extension UITapGestureRecognizer {
    
    func didTapAttributedTextInLabel(label: UILabel, inRange targetRange: NSRange) -> Bool {
        guard let attributedText = label.attributedText else { return false }
        
        let mutableStr = NSMutableAttributedString.init(attributedString: attributedText)
        mutableStr.addAttributes([NSAttributedString.Key.font: label.font!], range: NSRange.init(location: 0, length: attributedText.length))
        
        // Create instances of NSLayoutManager, NSTextContainer and NSTextStorage
        let layoutManager = NSLayoutManager()
        let textContainer = NSTextContainer(size: CGSize.zero)
        let textStorage = NSTextStorage(attributedString: mutableStr)
        
        // Configure layoutManager and textStorage
        layoutManager.addTextContainer(textContainer)
        textStorage.addLayoutManager(layoutManager)
        
        // Configure textContainer
        textContainer.lineFragmentPadding = 0.0
        textContainer.lineBreakMode = label.lineBreakMode
        textContainer.maximumNumberOfLines = label.numberOfLines
        let labelSize = label.bounds.size
        textContainer.size = labelSize
        
        // Find the tapped character location and compare it to the specified range
        let locationOfTouchInLabel = self.location(in: label)
        let textBoundingBox = layoutManager.usedRect(for: textContainer)
        let textContainerOffset = CGPoint(x: (labelSize.width - textBoundingBox.size.width) * 0.5 - textBoundingBox.origin.x,
                                          y: (labelSize.height - textBoundingBox.size.height) * 0.5 - textBoundingBox.origin.y);
        let locationOfTouchInTextContainer = CGPoint(x: locationOfTouchInLabel.x - textContainerOffset.x,
                                                     y: locationOfTouchInLabel.y - textContainerOffset.y);
        let indexOfCharacter = layoutManager.characterIndex(for: locationOfTouchInTextContainer, in: textContainer, fractionOfDistanceBetweenInsertionPoints: nil)
        return NSLocationInRange(indexOfCharacter, targetRange)
    }
    
}
