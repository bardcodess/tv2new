//
//  File.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 08/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit
import LGSideMenuController

public struct SideMenuUtil {
    
   static let shared = SideMenuUtil()
    
    public static var screenWidth: CGFloat {
        #if os(iOS) || os(tvOS)
        return UIScreen.main.bounds.width
        #elseif os(watchOS)
        return CURRENT_DEVICE.screenBounds.width
        #endif
    }
    
    
    
    public func initMenuDrawer(vc: UIViewController)
    {
        let menuVC = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "menu")
         let sideMenuController = LGSideMenuController(rootViewController: vc,leftViewController: menuVC,rightViewController: nil)
        
        if SideMenuUtil.shared.getDeviceOrientation().isLandscape {
            sideMenuController.leftViewWidth = SideMenuUtil.screenWidth/2
        } else {
            sideMenuController.leftViewWidth = SideMenuUtil.screenWidth - 60
        }
         
       // sideMenuController.leftViewWidth = SideMenuUtil.screenWidth / 5
        sideMenuController.leftViewPresentationStyle = .slideAbove
      //  sideMenuController.leftViewController?.view.backgroundColor = UIColor(hex: Colors.appBG.rawValue)
        let aNav = UINavigationController(rootViewController: sideMenuController)
        aNav.setNavigationBarHidden(true, animated: false)
        appDelegate.window?.rootViewController = aNav
        appDelegate.currentSideController = "HOME"
    }
    
    public func setMenuDrawer() {
        if let dashboardVC = UIStoryboard.init(name: "Home", bundle: .main).instantiateViewController(withIdentifier: "home") as? HomeViewController {
            appDelegate.currentSideController = "HOME"
            self.initMenuDrawer(vc: dashboardVC)
            
        }
    }
    
  public  func getDeviceOrientation() -> UIDeviceOrientation {
        let identifier: String = "getDeviceOrientation"
        var orientation = UIDevice.current.orientation
        // Get the interface orientation incase the UIDevice Orientation doesn't exist.
        let interfaceOrientation: UIInterfaceOrientation?
        if #available(iOS 15, *) {
            interfaceOrientation = UIApplication.shared.connectedScenes
                // Keep only the first `UIWindowScene`
                .first(where: { $0 is UIWindowScene })
                // Get its associated windows
                .flatMap({ $0 as? UIWindowScene })?.interfaceOrientation
        } else {
            interfaceOrientation = UIApplication.shared.windows.first?.windowScene?.interfaceOrientation
        }
        guard interfaceOrientation != nil else {
//            debugPrint("\(identifier)  \(DebuggingIdentifiers.actionOrEventFailed) UIApplication Orientation does not exist. This should never happen. measured orientation \(interfaceOrientation)")
            return orientation
        }

        // Initially the orientation is unknown so we need to check based on the application window orientation.
        if !orientation.isValidInterfaceOrientation {
//            debugPrint("\(identifier)  \(DebuggingIdentifiers.actionOrEventFailed) Orientation is unknown.")
//            debugPrint("\(identifier)  \(DebuggingIdentifiers.actionOrEventInProgress) Trying through the window orientation \(interfaceOrientation) \(DebuggingIdentifiers.actionOrEventInProgress)")
            // Notice that UIDeviceOrientation.landscapeRight is assigned to UIInterfaceOrientation.landscapeLeft and UIDeviceOrientation.landscapeLeft is assigned to UIInterfaceOrientation.landscapeRight. The reason for this is that rotating the device requires rotating the content in the opposite direction.
            // Reference : https://developer.apple.com/documentation/uikit/uiinterfaceorientation
            switch interfaceOrientation {
            case .portrait:
                
                orientation = .portrait
                break
            case .landscapeRight:
                
                orientation = .landscapeLeft
                break
            case .landscapeLeft:
                
                orientation = .landscapeRight
                break
            case .portraitUpsideDown:
                
                orientation = .portraitUpsideDown
                break
            default:
              
                orientation = .unknown
                break
            }
        }

        return orientation
    }
    
   
    
}

extension UIWindow {
    static var key: UIWindow? {
        if #available(iOS 13, *) {
            return UIApplication.shared.windows.first { $0.isKeyWindow }
        } else {
            return UIApplication.shared.keyWindow
        }
    }
}
