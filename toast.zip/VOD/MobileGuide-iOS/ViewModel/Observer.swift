//
//  Observer.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 25/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class Observable<T> {

    var value: T {
        didSet {
            listener?(value)
        }
    }

    private var listener: ((T) -> Void)?

    init(_ value: T) {
        self.value = value
    }

    func bind(_ closure: @escaping (T) -> Void) {
        closure(value)
        listener = closure
    }
}
