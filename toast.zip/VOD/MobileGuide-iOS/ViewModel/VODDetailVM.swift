//
//  VODDetailVM.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 25/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

protocol ObservableViewModelProtocol {
    func fetchBookmarkForSeries(for id: String?)
    func fetchBookmarkForAsser(for id: String?)
    var seriesBookmark: Observable<SeriesBookmarkModel?> { get  set }
    var assetBookmark: Observable<AssetBookmarkModel?> { get  set }
    
   
}


class VODDetailVM : ObservableViewModelProtocol {
    
    var seriesBookmark: Observable<SeriesBookmarkModel?> = Observable(nil)
    var assetBookmark: Observable<AssetBookmarkModel?>  = Observable(nil)
    var showTimes: Observable<[ShowTimeResult]> = Observable([])
  
    

    func fetchBookmarkForSeries(for id: String?) {
        APIManager.shared.getSeriesBookmark(for: id ?? "") { result in
            switch result {
            case .success(let success):
                self.seriesBookmark.value = success
            case .failure(let failure):
                print(failure)
            }
        }
        
    }
    
    func fetchBookmarkForAsser(for id: String?) {
        APIManager.shared.getAssetBookmark(for: id ?? "") { result in
            switch result {
            case .success(let success):
                self.assetBookmark.value = success
            case .failure(let failure):
                print(failure)
            }
        }
    }
    
    
    func fetchShowTimes(seriesId: String ,callLetter: String, programId: String ) {
        APIManager.shared.getShowTimeForLiveShows(seriesId: seriesId, callLetter: callLetter , programId: programId) { result in
            switch result {
            case .success(let success):
                self.showTimes.value = success.result
            case .failure(let failure):
                dump(failure)
            }
        }
    }
    
}
