//
//  SettingVm.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 04/09/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation
import UIKit

class SettingsVM {
    
   
    // MARK: - About Section
    var aboutSectionDictionay = [String:String]()
    var aboutSectionDictionayDidChanges: ((Bool, Bool) -> Void)?
    
    func fetchUserDetails() {
        aboutSectionDictionay["User Name"] = APIManager.shared.getUsernameFromJWT()
        aboutSectionDictionay["Device Name"] = UIDevice.current.name
        aboutSectionDictionay["Version"] = "1.0"
        aboutSectionDictionay["Channel Map"] = appDelegate.appConfigs?.response.appConfigurations.common.channelMap
        APIManager.shared.getUserIP { result in
            switch result {
            case .success(let success):
                self.aboutSectionDictionay["IP Address"] = success.response
                APIManager.shared.getNetworkLocation(userPublicIP: success.response) { result in
                    switch result {
                    case .success(let success):
                        self.aboutSectionDictionay["Network Location"] = success.result[0]
                        self.aboutSectionDictionayDidChanges?(true,false)
                    case .failure(let failure):
                        print(failure)
                    }
                }
            case .failure(let failure):
                print(failure)
                self.aboutSectionDictionayDidChanges?(false,false)
            }
        }
    }
    
    
    
    
    
    
}
