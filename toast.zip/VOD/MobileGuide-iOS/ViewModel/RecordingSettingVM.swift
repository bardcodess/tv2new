//
//  RecordingSettingVM.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 28/11/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class RecordingSettingVM {
    
    var recordingSettings: Observable<RecordingSettingsModel?> = Observable(nil)
    private  var scheduledRecordingData : DetailRecordingsModel?
     var optionsDic = [String:[RecordingSettingsResponse]]()
    var headers : Observable<[String]> = Observable([])
    var headersCaseName : Observable<[String:String]> = Observable([:])
    private var settings = RecordingSettings()
    var selectedOptions : Observable<[String:Setting]> = Observable([:])
    
    
    init( scheduledRecordingData: DetailRecordingsModel?) {
        self.scheduledRecordingData = scheduledRecordingData
    }
    
    
    private  enum headerTitleForNwtelAndCcap: String, CaseIterable {
        case startTimeChoice = "Time"
        case showTypeChoice = "Show Type"
        case startRecordingTime = "Start Recording"
        case stopRecordingTime = "Stop Recording"
        case keepUntil = "Keep"
        case keepAtMost = "Keep Episode"
        case channelChoice = "Channel Choice"
        
        
        var caseName : String {
            switch self {
            case .keepUntil:
                return "keepUntil"
            case .channelChoice:
                return "channelChoice"
            case .showTypeChoice:
                return "showTypeChoice"
            case .startTimeChoice:
                return "startTimeChoice"
            case .startRecordingTime:
                return "startRecordingTime"
            case .stopRecordingTime:
                return "stopRecordingTime"
            case .keepAtMost:
                return "keepAtMost"
            }
        }
    }
    
    
     func getSetting() {
        
        APIManager.shared.getRecordingSettings { result in
            switch result {
            case .success(let success):
                self.recordingSettings.value = success
                self.setData()
            case .failure(let failure):
                dump(failure)
            }
        }
    }
    
    
    private  enum headerTitleForHargrayAndTbtyal: String, CaseIterable {
        case startTimeChoice = "Time"
        case showTypeChoice = "Show Type"
        case keepUntil = "Keep"
        case keepAtMost = "Keep Episode"
        case channelChoice = "Channel Choice"
        
        
        var caseName : String {
            switch self {
            case .keepUntil:
                return "keepUntil"
            case .channelChoice:
                return "channelChoice"
            case .showTypeChoice:
                return "showTypeChoice"
            case .startTimeChoice:
                return "startTimeChoice"
            case .keepAtMost:
                return "keepAtMost"
            }
        }
    }
    
    func selectedValueDidChange(dataChanged: Setting, idx: Int) {
        let headerRawValue = headers.value[idx]
        let headerCaseName = headersCaseName.value[headerRawValue ]
        selectedOptions.value[headerCaseName!] = dataChanged
        
        if  selectedOptions.value[headerCaseName!]?.description == "Until I delete" ||  selectedOptions.value[headerCaseName!]?.description == "Forever"  {
            
            if headers.value.contains(headerTitleForNwtelAndCcap.keepAtMost.rawValue) {
                return
            }
            
            let ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.keepUntil.rawValue)
            headers.value.insert(headerTitleForNwtelAndCcap.keepAtMost.rawValue, at: ind! + 1)
            
        
        } else if selectedOptions.value[headerCaseName!]?.description == "Until space is needed" ||  selectedOptions.value[headerCaseName!]?.description == "Space is needed"  {
            
            
            let ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.keepAtMost.rawValue)
            headers.value.remove(at: ind!)
            
           
            
            
        } else {
            return
        }
    }
    
    
    
    
    
    
    
    
    
    
    func setData() {
        
        headersCaseName.value["Time"] = "startTimeChoice"
        headersCaseName.value["Show Type"] = "showTypeChoice"
        headersCaseName.value["Keep"] = "keepUntil"
        headersCaseName.value["Keep Episode"] = "keepAtMost"
        headersCaseName.value["Channel Choice"] = "channelChoice"
        headersCaseName.value["Start Recording"] = "startRecordingTime"
        headersCaseName.value["Stop Recording"] = "stopRecordingTime"
        
        
        let optionsForkeepUntil = recordingSettings.value?.response.filter({$0.type == "keepUntil"})
        let value = optionsForkeepUntil![0].settings.filter({$0.text == scheduledRecordingData?.keepUntil ?? ""})
        settings.setValue(value[0].value, forKey: "keepUntil")
        settings.setValue(scheduledRecordingData?.keepAtMost ?? 0, forKey: "keepAtMost")
        settings.setValue(scheduledRecordingData?.startTimeChoice ?? 0, forKey: "startTimeChoice")
        settings.setValue(scheduledRecordingData?.showTypeChoice ?? 0, forKey: "showTypeChoice")
        settings.setValue(scheduledRecordingData?.channelChoice ?? 0, forKey: "channelChoice")
        settings.setValue(scheduledRecordingData?.startRecordingTime ?? 0, forKey: "startRecordingTime")
        settings.setValue(scheduledRecordingData?.stopRecordingTime ?? 0, forKey: "stopRecordingTime")
        
        
        
        
        if appDelegate.operatorName == "CCAP" || appDelegate.operatorName == "NWTel" {
            for title in headerTitleForNwtelAndCcap.allCases {
                headers.value.append(title.rawValue)
                
            }
            if  settings.value(forKey: headerTitleForNwtelAndCcap.keepUntil.caseName) as! Int == 0{
                let ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.keepAtMost.rawValue)
                headers.value.remove(at: ind!)
            }
            
            if !appDelegate.appEnabledFeatures!.isRecordingEnabled {
                var ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.stopRecordingTime.rawValue)
                headers.value.remove(at: ind!)
                
                ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.startRecordingTime.rawValue)
                headers.value.remove(at: ind!)
               
            }
            
            if scheduledRecordingData?.isProgram ?? false{
                var ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.startTimeChoice.rawValue)
                headers.value.remove(at: ind!)
                
                ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.showTypeChoice.rawValue)
                headers.value.remove(at: ind!)
                
                ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.channelChoice.rawValue)
                headers.value.remove(at: ind!)
            }
            
            for titles in headerTitleForNwtelAndCcap.allCases {
                optionsDic[titles.caseName] = recordingSettings.value?.response.filter({$0.type == titles.caseName })
            }
            
            for (_,caseName) in optionsDic.keys.enumerated() {
                let settingsArray = recordingSettings.value?.response.filter({$0.type == caseName})
                let selectedData = settingsArray?[0].settings.filter({$0.value == settings.value(forKey: caseName) as! Int})
                selectedOptions.value[caseName] =  selectedData?.first// settings.value(forKey: caseName)})
            }
            
        }
        else {
            for title in headerTitleForHargrayAndTbtyal.allCases {
                headers.value.append(title.rawValue)
            }
            if settings.value(forKey: headerTitleForHargrayAndTbtyal.keepUntil.caseName) as! Int == 0 {
                let ind = headers.value.firstIndex(of: headerTitleForHargrayAndTbtyal.keepAtMost.rawValue)
                headers.value.remove(at: ind!)
            }
            
            if !appDelegate.appEnabledFeatures!.isRecordingEnabled {
                var ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.stopRecordingTime.rawValue)
                headers.value.remove(at: ind!)
                
                ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.startRecordingTime.rawValue)
                headers.value.remove(at: ind!)
            }
            
            if scheduledRecordingData?.isProgram ?? false{
                var ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.startTimeChoice.rawValue)
                headers.value.remove(at: ind!)
                
                ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.showTypeChoice.rawValue)
                headers.value.remove(at: ind!)
                
                ind = headers.value.firstIndex(of: headerTitleForNwtelAndCcap.channelChoice.rawValue)
                headers.value.remove(at: ind!)
            }
            
            for titles in headerTitleForHargrayAndTbtyal.allCases {
                optionsDic[titles.caseName] = recordingSettings.value?.response.filter({$0.type == titles.caseName })
            }
            
            for (_,caseName) in optionsDic.keys.enumerated() {
                let settingsArray = recordingSettings.value?.response.filter({$0.type == caseName})
                selectedOptions.value[caseName] = settingsArray?[0].settings[0]
            }
        }
        
        
    }
    
    
}
