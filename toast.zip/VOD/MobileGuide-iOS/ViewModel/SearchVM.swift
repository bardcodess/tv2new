//
//  SearchVM.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 31/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class SearchVM {
    
    
    
    
    // MARK: - SEARCH RECORDINGNS
    
    var groupedRecordings: Observable<[String: [SearchRecordingsItem]]> = Observable([:])
    
    
    func mapSearchRecordingItemToDetailRecording(programs: [SearchRecordingsItem]) -> DetailRecordingsModel{
        
        var episodes = [DetailRecordings]()
        for object in programs {
            if object.seasonNumber == nil {
                continue
            } else {
                let detailRecordings = DetailRecordings(id: object.id, title: object.title, actualEndUtc: object.actualEndUtc, actualStartUtc: object.actualStartUtc, duration: object.duration, ratings: object.ratings, seasonNumber: object.seasonNumber, episodeNumber: object.episodeNumber, episodeTitle: object.episodeTitle, iconSrc: object.iconSrc, channelCallLetter: object.channelCallLetter, itemID: object.itemID, shortSummary: object.shortDescription, channelNumber: object.channelNumber,scheduledStartUtc: object.scheduledStartUTC,scheduledEndUtc: object.scheduledEndUTC,keepUntil: nil,keepAtMost: nil,startTimeChoice: nil,showTypeChoice: nil,channelChoice: nil,startRecordingTime: nil,stopRecordingTime: nil, seriesId: object.seriesId, episodeId: nil, isProgram: false)
                
                episodes.append(detailRecordings)
            }
           
        }
        
        return DetailRecordingsModel(title: programs[0].title, iconSrc: programs[0].iconSrc, userReview: nil, isSeries: true, id: programs[0].id, actualEndUtc: programs[0].actualEndUtc, actualStartUtc: programs[0].actualStartUtc, duration: programs[0].duration, ratings: programs[0].ratings, seasonNumber: programs[0].seasonNumber, episodeNumber: programs[0].episodeNumber, episodeTitle: programs[0].episodeTitle, channelCallLetter: programs[0].channelCallLetter, itemID: programs[0].itemID, shortSummary: programs[0].itemDescription, channelNumber: programs[0].channelNumber, scheduledStartUtc: programs[0].scheduledStartUTC, scheduledEndUtc: programs[0].scheduledEndUTC, episodes: episodes, isRecordingCompleted: true,keepUntil: nil,keepAtMost: nil,startTimeChoice: nil,showTypeChoice: nil,channelChoice: nil,startRecordingTime: nil,stopRecordingTime: nil, seriesId: programs[0].seriesId, isProgram: false, episodeId: nil)
    }
    

     
    
    func groupSearchRecordedPrograms(programs: [SearchRecordingsItem]) {
        var groupedProgram = [String:[SearchRecordingsItem]]()
        for object in programs {
            let key = object.seriesId ?? object.parentSeriesId ?? object.programId
            if groupedProgram[key ?? ""] != nil {
                groupedProgram[ key ?? ""]?.append(object)
            } else {
                groupedProgram[ key ?? ""] = [object]
            }
        }
        groupedRecordings.value = groupedProgram
    }
    
    
    func mapSearchRecordingItemToDetailRecordings(model: [SearchRecordingsItem]) -> DetailRecordingsModel {
        
        var detailRecording : DetailRecordingsModel? = nil
        
        for object in model {
            detailRecording =  DetailRecordingsModel(title: object.title, iconSrc: object.iconSrc, userReview: nil, isSeries: false, id: object.id, actualEndUtc: object.actualEndUtc, actualStartUtc: object.actualStartUtc, duration: object.duration, ratings: object.ratings, seasonNumber: object.seasonNumber, episodeNumber: object.episodeNumber, episodeTitle: object.episodeTitle, channelCallLetter: object.channelCallLetter, itemID: object.itemID, shortSummary: object.shortDescription, channelNumber: object.channelNumber, scheduledStartUtc: object.scheduledStartUTC, scheduledEndUtc: object.scheduledEndUTC, episodes: [], isRecordingCompleted: true,keepUntil: nil,keepAtMost: nil,startTimeChoice: nil,showTypeChoice: nil,channelChoice: nil,startRecordingTime: nil,stopRecordingTime: nil, seriesId: object.seriesId, isProgram: true, episodeId: nil)
        }
        
        return detailRecording!
        
    }
//    
    
    // MARK: - SEARCH VOD
    func mapSearchVODToVodDetailSeries(model: Recommendation?) -> VODDetailSeriesModel?{
        
        guard let episodes = model?.episodes else {
            return nil
        }
        var episodesArray = [DetailSeriesModel]()
        
        for object in episodes {
            let detailSeriesModel = DetailSeriesModel(title: object.title, assetId: object.assetId, seasonNumber: object.seasonNumber, episodeId: object.episodeId, userReview: object.userReview, poster: object.poster, posters: object.posters, year: object.year, shortSummary: object.shortSummary, rating: object.rating, episodeName: object.episodeName, licensingWindowEnd: object.licensingWindowEnd, runTime: object.runTime, episodes: [])
            episodesArray.append(detailSeriesModel)
        }
        
        
        let detailSeriesModel = DetailSeriesModel(title: model?.title, assetId: model?.assetId, seasonNumber: model?.seasonNumber, episodeId: model?.episodeId, userReview: model?.userReview, poster: model?.poster, posters: model?.posters, year: model?.year, shortSummary: model?.shortSummary, rating: model?.rating, episodeName: model?.episodeName, licensingWindowEnd: model?.licensingWindowEnd, runTime: model?.runTime, episodes: episodesArray)
        
        return VODDetailSeriesModel(assetDetails: detailSeriesModel, userReview: model?.userReview)
    }
    
    
    func mapSearchVODToVODDetail(model: Recommendation?) -> VODDetailModel {
        
        let detailSeriesModel = DetailSeriesModel(title: model?.title, assetId: model?.assetId, seasonNumber: model?.seasonNumber, episodeId: model?.episodeId, userReview: model?.userReview, poster: model?.poster, posters: model?.posters, year: model?.year, shortSummary: model?.shortSummary, rating: model?.rating, episodeName: model?.episodeName, licensingWindowEnd: model?.licensingWindowEnd, runTime: model?.runTime, episodes: [])
        
        let vodDetail = VODDetailModel(assetDetails: detailSeriesModel, userReview: model?.userReview,isSeries: false)
        
       return vodDetail
    }
}
