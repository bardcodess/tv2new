//
//  VODDetailSeriesVM.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 25/10/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

class VODDetailSeriesVM: ObservableViewModelProtocol {
    
    var seriesBookmark: Observable<SeriesBookmarkModel?> = Observable(nil)
    var sortedEpisodes : Observable<[DetailSeriesModel]> = Observable([])
    var sortedRecordings: Observable<[DetailRecordings]> = Observable([])
    var groupedSeasonDic = [String:[DetailSeriesModel]]()
    var groupedRecordedShowsBySeason = [String:[DetailRecordings]]()
    var seasonKey = 0
    var seasons = [Int]()
    var episodes = 0
    
    func fetchBookmarkForSeries(for id: String?) {
        APIManager.shared.getSeriesBookmark(for: id ?? "") { result in
            switch result {
            case .success(let success):
                self.seriesBookmark.value = success
            case .failure(let failure):
                print(failure)
            }
        }
        
    }
    
    private func groupBySeason( for collection : [DetailSeriesModel]) -> [String:[DetailSeriesModel]] {
        var groupedObjects = [String: [DetailSeriesModel]]()
        for object in collection {
            let season = object.seasonNumber?.stringValue ?? ""
            if groupedObjects[season] != nil {
                groupedObjects[season]?.append(object)
            } else {
                groupedObjects[season] = [object]
            }
        }
        return groupedObjects
    }
    
    
    func setupGroupedSeason(model : VODDetailSeriesModel) {
        groupedSeasonDic = groupBySeason(for: model.assetDetails?.episodes ?? [])
        episodes = model.assetDetails?.episodes?.count ?? 0
        seasons = groupedSeasonDic.keys.map({Int($0)!})
        seasons = seasons.sorted(by: {$0 < $1})
    }
    
   
    func displaySortedData() {
        let stringSeasonKey = String(seasons[seasonKey])
        sortedEpisodes.value = groupedSeasonDic[stringSeasonKey] ?? []
        sortedEpisodes.value = sortedEpisodes.value.sorted(by: {Int($0.episodeId?.stringValue ?? "") ?? 0 < Int($1.episodeId?.stringValue ?? "") ?? 0 })
    }
   
    
    
 // MARK: - FOR RECORDINGS
    private func groupBySeasonForRecordings( for collection : [DetailRecordings]) -> [String:[DetailRecordings]] {
        var groupedObjects = [String: [DetailRecordings]]()
        for object in collection {
            let season = object.seasonNumber ?? ""
            if groupedObjects[season] != nil {
                groupedObjects[season]?.append(object)
            } else {
                groupedObjects[season] = [object]
            }
        }
        return groupedObjects
    }
    
    func setUpGroupedSeasonForRecordings(model: DetailRecordingsModel) {
        groupedRecordedShowsBySeason = groupBySeasonForRecordings(for: model.episodes ?? [])
        episodes = model.episodes?.count ?? 0
        seasons = groupedRecordedShowsBySeason.keys.map({Int($0)!})
        seasons = seasons.sorted(by: {$0 < $1})
    }
    
    func displaySortedRecordings() {
        let stringSeasonKey = String(seasons[seasonKey])
        sortedRecordings.value = groupedRecordedShowsBySeason[stringSeasonKey] ?? []
        sortedRecordings.value = sortedRecordings.value.sorted(by: {Int($0.episodeNumber ?? "") ?? 0 < Int($1.episodeNumber ?? "") ?? 0 })
        
    }
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    // MARK: - Optionals
    
    /// Do not call
    /// - Parameter id: Do not call
    func fetchBookmarkForAsser(for id: String?) {
        //
    }
    
    /// Do not use
    var assetBookmark: Observable<AssetBookmarkModel?> = Observable(nil)
}


