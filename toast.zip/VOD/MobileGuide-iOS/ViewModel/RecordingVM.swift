//
//  RecordingVM.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 24/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation

protocol RecordingVMPRotocol {
    var recordingDidChanges: ((Bool, Bool) -> Void)? { get set }
    var scheduleDidChanges: ((Bool, Bool) -> Void)? { get set }
    var failedDidChanges: ((Bool, Bool) -> Void)? { get set }
  
}

class RecordingVM: RecordingVMPRotocol {
    
    
    var scheduleDidChanges: ((Bool, Bool) -> Void)?
    var failedDidChanges: ((Bool, Bool) -> Void)?
    var recordingDidChanges: ((Bool, Bool) -> Void)?
    
    var recordings : [ExpandedRecordedCells]?
    var schedules : [ExpandedScheduledCells]?
    var failedRec : [ItemFailedRecording]?
    
    var recordingDic = [String:[Item]]()
    var scheduleDic  = [String:[ItemSchedule]]()
    
    
    // MARK: - For Recordings
    
    func getRecordingsForNwTelAndCcap(skip: Int , top: Int) {
        
        APIManager.shared.getRecordedShows(skip: skip, top: top) { result in
            switch result {
            case .success(let success):
                for item in success.response.items {
                    let key = item.seriesId ?? item.id
                    
                    if self.recordingDic[key] == nil {
                        self.recordingDic[key] = [Item]()
                        self.recordingDic[key]?.append(item)
                    }
                    
                    self.recordingDic[key]?.append(contentsOf: item.otherRecordedEpisodes ?? [])
                }
                self.dicToArrayForRecordings()
            case .failure(_):
                self.recordingDidChanges?(false,false)
            }
        }
        
    }
    
    
    
    private  func dicToArrayForRecordings() {
        self.recordings = [ExpandedRecordedCells]()
        for obj in recordingDic {
            self.recordings?.append(ExpandedRecordedCells(section: obj.value[0], otherRecordedItems: obj.value ))
        }
        recordingDidChanges?(true,false)
    }
    
    
    
    func getRecordingsForHargrayAndTbtyel(skip: Int , top: Int) {
        APIManager.shared.getRecordedShows(skip: 0, top: 10) { result in
            switch result {
            case .success(let success):
                for item in success.response.items {
                    let key = item.seriesId ?? item.id
                    
                    if self.recordingDic[key] == nil {
                        self.recordingDic[key] = [Item]()
                    }
                    
                    self.recordingDic[key]?.append(item)
                }
                self.dicToArrayForRecordings()
            case .failure(_):
                self.recordingDidChanges?(false,false)
            }
        }
        
    }
    
    
    func mapExpandeRecordingsToDetailRecordings(model: Item, isSeries: Bool) -> DetailRecordingsModel {
        return DetailRecordingsModel(title: model.title, iconSrc: model.iconSrc, userReview: nil, isSeries: isSeries, id: model.id, actualEndUtc: model.actualEndUtc, actualStartUtc: model.actualStartUtc, duration: model.duration, ratings: model.ratings, seasonNumber: model.seasonNumber, episodeNumber: model.episodeNumber, episodeTitle: model.episodeTitle, channelCallLetter: model.channelCallLetter, itemID: "", shortSummary: model.description, channelNumber: model.channelNumber, scheduledStartUtc: model.scheduledStartUtc, scheduledEndUtc: model.scheduledEndUtc, episodes: [], isRecordingCompleted: true,keepUntil: nil,keepAtMost: nil,startTimeChoice: nil,showTypeChoice: nil,channelChoice: nil,startRecordingTime: model.hardStartPadding,stopRecordingTime: model.hardEndPadding, seriesId: model.seriesId, isProgram: model.otherRecordedEpisodes?.count ?? 0 > 0 ? false : true, episodeId: nil)
    }
    
    
    //MARK: - For failed
    
    
    func getFailedRecordings() {
        self.failedRec = [ItemFailedRecording]()
        APIManager.shared.getFailedShows { result in
            switch result {
            case .success(let success):
                for item in success.response.items {
                    self.failedRec?.append(item)
                }
                self.failedDidChanges?(true,false)
            case .failure(_):
                self.failedDidChanges?(false,true)
            }
        }
        
    }
    
    
    
    
    //MARK: -  for Schedule
    func getScheduleRecordingsForNwTelAndCcap(skip: Int , top: Int) {
        
        APIManager.shared.getScheduledShows(skip: skip, top: top) { result in
            switch result {
            case .success(let success):
                for item in success.response.items {
                    let key = item.seriesId ?? item.id
                    
                    if self.scheduleDic[key] == nil {
                        self.scheduleDic[key] = [ItemSchedule]()
                        self.scheduleDic[key]?.append(item)
                    }
                    
                    self.scheduleDic[key]?.append(contentsOf: item.otherScheduledEpisodes ?? [])
                }
                self.dicToArrayForSchedule()
            case .failure(_):
                self.scheduleDidChanges?(false,true)
            }
        }
        
    }
    
    
    
    
    private  func dicToArrayForSchedule() {
        self.schedules = [ExpandedScheduledCells]()
        for obj in scheduleDic {
            self.schedules?.append(ExpandedScheduledCells(section: obj.value[0], otherScheduledEpisodes: obj.value))
        }
        scheduleDidChanges?(true,false)
    }
    
    
    
    
    
    func getScheduleRecordingsForHargrayAndTbtyel(skip: Int , top: Int) {
        APIManager.shared.getScheduledShows(skip: skip, top: top) { result in
            switch result {
            case .success(let success):
                for item in success.response.items {
                    let key = item.seriesId ?? item.id
                    
                    if self.scheduleDic[key] == nil {
                        self.scheduleDic[key] = [ItemSchedule]()
                    }
                    
                    self.scheduleDic[key]?.append(item)
                }
                self.dicToArrayForSchedule()
            case .failure(_):
                self.scheduleDidChanges?(false,true)
            }
        }
        
    }
    
    
    func mapExpandeScheduledToDetailRecordings(model: ItemSchedule, isSeries: Bool) -> DetailRecordingsModel {
        return DetailRecordingsModel(title: model.title, iconSrc: model.iconSrc, userReview: nil, isSeries: isSeries, id: model.id, actualEndUtc: model.actualEndUtc, actualStartUtc: model.actualStartUtc, duration: model.duration, ratings: model.ratings, seasonNumber: model.seasonNumber, episodeNumber: model.episodeNumber, episodeTitle: model.episodeTitle, channelCallLetter: model.channelCallLetter, itemID: "", shortSummary: model.description, channelNumber: model.channelNumber, scheduledStartUtc: model.scheduledStartUtc, scheduledEndUtc: model.scheduledEndUtc, episodes: [], isRecordingCompleted: false,keepUntil: model.keepUntil,keepAtMost: model.keepAtMost,startTimeChoice: model.startTimeChoice,showTypeChoice: model.showTypeChoice,channelChoice: model.channelChoice,startRecordingTime: model.hardStartPadding,stopRecordingTime: model.hardEndPadding, seriesId: model.seriesId, isProgram: !isSeries, episodeId: model.episodeId)
    }
    
    
    
}
