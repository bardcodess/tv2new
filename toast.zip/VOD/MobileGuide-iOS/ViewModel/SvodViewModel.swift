protocol SvodViewModelDelegate: AnyObject {
    func didUpdateRow(didUpdate : Bool)
}

import Foundation
public class SvodViewModel{
    var sectionTitle : [String] = []
    var VodDic: [String: [CategoryList]] = [:]
    var catListIds : [String: String] = [:]
    var newDataAsset  = [CategoryList]()
    
    weak var delegate: SvodViewModelDelegate?
    
    func getRootCategoryData(catId : String)
    {
        APIManager.shared.GetNewVODCategoryData(catID: catId){ result in
            switch result {
            case .success(let assetList):
                self.newDataAsset = assetList
                for list in assetList
                {
                    Task
                    {
                        do{
                            let result = try await  APIManager.shared.PostVODCategoryAssetDataAsync(categoryVod: list)
                            if(result.count > 0 && result.first?.assets != nil && (result.first?.assets!.count)! > 0 )
                            {
                                self.catListIds.updateValue(list.id!, forKey: list.name ?? "")
                                self.catListIds.removeValue(forKey: "")
                                self.VodDic.updateValue(result, forKey: (list.name ?? ""))
                                self.VodDic.removeValue(forKey: "")
                                DispatchQueue.main.async {
                                    self.sectionTitle.append((list.name ?? ""))
                                    self.delegate?.didUpdateRow(didUpdate: true)
                                }
                            }
                        }
                        catch
                        {
                            print(error)
                        }
                    }
                }
            case .failure(let error):
                print(error)
            }
        }
    }
    
    
    func mapRecommendModelToVODDetail(model: Recommendation) -> VODDetailModel {
        let detailSeriesModel = DetailSeriesModel(id: model.id, title: model.title, assetId: model.assetId, seasonNumber: nil, episodeId: nil, userReview: model.userReview, poster: model.poster, posters: model.posters, year: model.year, shortSummary: model.shortSummary, rating: model.rating, episodeName: model.episodeName, licensingWindowEnd: model.licensingWindowEnd, runTime: model.runTime, episodes: mapToDetailSeriesModelArray(data: model))
        return VODDetailModel(assetId: model.assetId, assetDetails: detailSeriesModel,userReview: model.userReview, isSeries: false)
    }
    
    func mapRecommendModelToVODDetailSeries(model: Recommendation) -> VODDetailSeriesModel {
        let detailSeriesModel = DetailSeriesModel(id: model.id, title: model.title, assetId: model.assetId, seasonNumber: nil, episodeId: nil, userReview: model.userReview, poster: model.poster, posters: model.posters, year: model.year, shortSummary: model.shortSummary, rating: model.rating, episodeName: model.episodeName, licensingWindowEnd: model.licensingWindowEnd, runTime: model.runTime, episodes: mapToDetailSeriesModelArray(data: model))
        return  VODDetailSeriesModel(assetDetails:detailSeriesModel,userReview: model.userReview)
    }
    
    
   private func mapToDetailSeriesModelArray(data: Recommendation) -> [DetailSeriesModel] {
        var mappedArray = [DetailSeriesModel]()
        guard let episodes = data.episodes else {
            return []
        }
        for object in episodes {
            mappedArray.append(DetailSeriesModel(id: object.id, title: object.title, assetId: object.assetId, seasonNumber: object.seasonNumber, episodeId: object.episodeId, userReview: object.userReview, poster: object.poster, posters: object.posters, year: object.year, shortSummary: object.shortSummary, rating: object.rating, episodeName: object.episodeName, licensingWindowEnd: object.licensingWindowEnd, runTime: object.runTime, episodes: []))
        }
        return mappedArray
    }
}
