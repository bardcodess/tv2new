//
//  LoginVM.swift
//  MobileGuide-iOS
//
//  Created by MP-44 on 09/08/23.
//  Copyright © 2023 Tudip Digital. All rights reserved.
//

import Foundation



class LoginVM {
    
    let LoginError = APIError.self 
    
    func validateCreds(userRequest: LoginUserRequest, completion: @escaping(Result<Bool,Error>)-> Void) {
        
        if userRequest.username.count == 0 ||  userRequest.password.count == 0 {
            completion(.failure(LoginError.emptyUsernameOrPassword))
            return
        }
        
        
        let  username = userRequest.username.trimmingCharacters(in: .whitespacesAndNewlines)
        let  password = userRequest.password.trimmingCharacters(in: .whitespacesAndNewlines)
        
        print(username)
        print(password)
        
        AuthService.shared.loginUser(with: LoginUserRequest(username: username, password: password)) { result in
            switch result {
            case .success(_):
                completion(.success(true))
                let defaults = UserDefaults.standard
                defaults.set(username, forKey: "username")
            case .failure(let failure):
                print("vm fail")
                completion(.failure(failure))
            }
        }
    }
    

    
}
