protocol ViewModelDelegate: AnyObject {
    func didUpdateRow(didUpdate : Bool)
}

import Foundation
public class HomeViewModel {
    var recordingDidChanges: ((Bool, Bool) -> Void)?
    weak var delegate: ViewModelDelegate?
    var sectionTitle : [String] = []
    var recommendationList = [RecommendationFeed]()
    var HomeDic: [String: [HomeDataModel]] = [:]
    var HomeOrderDic : [String : [HomeDataModel]] = [:]
    
    var HomePageSequence = ["Recent Channels", "Continue Watching (VOD)", "New Releases (VOD)", "New Releases (Rentals)", "Recordings"]
    
    func getHomeData()
    {
        APIManager.shared.GetRecommendationFeedInfo{ result in
            switch result {
            case .success(let assetList):
                self.recommendationList = assetList
                
                APIManager.shared.fetchVodData(catID: self.recommendationList.first(where: { $0.localClassName == "Continue Watching" })?.id ?? ""){ result in
                    switch result {
                    case .success(let assetList):
                        let list = self.MapVODToHome(with: assetList)
                        
                        self.HomeDic.updateValue(list, forKey: "Continue Watching (VOD)")
                        DispatchQueue.main.async {
                            self.setHomePageDataSource()
                
                            self.delegate?.didUpdateRow(didUpdate: true)
                        }
                    case .failure(let error):
                        print(error)
                    }
                }
                
                APIManager.shared.fetchVodData(catID: self.recommendationList.first(where: { $0.localClassName == "New Releases (VOD)" })?.id ?? ""){ result in
                    switch result {
                    case .success(let assetList):
                        let list = self.MapVODToHome(with: assetList)
                        self.HomeDic.updateValue(list, forKey: "New Releases (VOD)")
                        DispatchQueue.main.async {
                            self.setHomePageDataSource()
                            self.delegate?.didUpdateRow(didUpdate: true)
                        }
                    case .failure(let error):
                        print(error)
                    }
                }
                
                APIManager.shared.fetchVodData(catID: self.recommendationList.first(where: { $0.localClassName == "New Releases (Pay per view)" })?.id ?? ""){ result in
                    switch result {
                    case .success(let assetList):
                        if(assetList.count != 0)
                        {
                            let list = self.MapVODToHome(with: assetList)
                            self.HomeDic.updateValue(list, forKey:"New Releases (Rentals)")
                            DispatchQueue.main.async {
                                self.setHomePageDataSource()
                                
                                self.delegate?.didUpdateRow(didUpdate: true)
                                
                            }
                            
                        }
                    case .failure(let error):
                        print(error)
                    }
                }
                APIManager.shared.FetchHomeRecordingsData
                { result in
                    switch result {
                    case .success(let RecList):
                        if(RecList.count != 0)
                        {
                            let list = self.MapRecordingsToHome(with:Array(RecList.prefix(10)))
                            self.HomeDic.updateValue(list, forKey:"Recordings")
                            DispatchQueue.main.async {
                                self.setHomePageDataSource()
                                
                                self.delegate?.didUpdateRow(didUpdate: true)
                            }
                        }
                    case .failure(let failure):
                        print(failure)
                        
                    }
                }
            case .failure(let error):
                print(error)
                
            }
        }
    }
    
    func setHomePageDataSource()
    {
        self.HomeOrderDic.removeAll()
        self.sectionTitle.removeAll()
        for sequence in self.HomePageSequence
        {
            for element in self.HomeDic.keys
            {
                if(sequence.contains(element))
                {
                    self.HomeOrderDic.updateValue(self.HomeDic[sequence]!, forKey: sequence)
                    self.sectionTitle.append(sequence)
                }
            }
            
        }
    }
    
    func MapRecordingsToHome (with model : [RecordingsItems])-> [HomeDataModel]
    {
        var homeDataModels : [HomeDataModel] = []
        for item in model
        {
            var recordedItem  :  RecordingsItems? = nil
            
            recordedItem = RecordingsItems(id: item.id, showingID: item.showingID, episodeId: item.episodeId, channelID: item.channelID, start: item.start, end: item.end, state: item.state, ratings: item.ratings, channelCallLetter: item.channelCallLetter, iconSrc: item.iconSrc, duration: item.duration, title: item.title, description: item.description, shortDescription: item.description, seriesId: item.seriesId, episodeTitle: item.episodeTitle, scheduledStartUtc: item.scheduledStartUtc, scheduledEndUtc: item.scheduledEndUtc, channelNumber: item.channelNumber, seasonNumber: item.seasonNumber, episodeNumber: item.episodeNumber, seriesDefinitionId: item.seriesDefinitionId, itemId: item.itemId,keepAtMost: item.keepAtMost,keepUntil: item.keepUntil ,channel: item.channel, actualEndUtc: item.actualEndUtc, actualStartUtc: item.actualStartUtc, keepUntilDate: item.keepUntilDate, otherRecordedEpisodes: item.otherRecordedEpisodes)
            
            
            var homeDataModel = HomeDataModel(
                
                id: item.id,
                recentWatchedTime: "",
                channelId: "",
                channel: item.channel, programId: "",
                programName:  item.title ?? item.episodeTitle,
                channelNumber: item.channelNumber,
                callLetters: "",
                channelLogoURL: item.iconSrc,
                ppvStart: "",
                ppvEnd: "",
                blockCode: "",
                pauseEnabled: false,
                isAPIWithBlockCode: false,
                multicastAbrEnabled: false,
                assetId: "",
                placeHolderImage: "default_asset.png",
                recordingId: "",
                showDetailsPage: true,
                isAsset: false,
                isPPV: false,
                assetDetails: nil,
                shouldDisplayBanner: false,
                shouldDisplayPlayBadge: false,
                shouldDisplayPurchasedTag: false,
                isSeriesIndicator: item.otherRecordedEpisodes != nil && item.otherRecordedEpisodes!.count > 0,
                ratings: item.ratings,
                assetPermission: nil ,
                posterHeight: "200",
                seasonNumber: EpisodeID.integer(0),
                episodeId: EpisodeID.string(""),
                recordedItem: recordedItem, otherRecordedEpisodes: item.otherRecordedEpisodes, isRecordedAsset: item.otherRecordedEpisodes?.count ?? 0 > 0 ? true : false
                
            )
            if recordedItem != nil {
                homeDataModel.otherRecordedEpisodes?.insert(recordedItem!, at: 0)
            }
            
            homeDataModels.append(homeDataModel)
        }
        
        return homeDataModels
        
    }
    
    func MapVODToHome (with model : [Recommendation])-> [HomeDataModel]
    {
        var homeDataModels : [HomeDataModel] = []
        
        for item in model
        {
            let isSeries = item.assetType?.lowercased() == "series"
            var episode  = isSeries ? item.episodes![0] : item
            if(isSeries)
            {
                episode = item.episodes![0]
            }
            let homeDataModel = HomeDataModel(
                
                id: item.id,
                recentWatchedTime: "",
                channelId: "",
                channel: nil, programId: "",
                programName: isSeries ? episode.title : item.title,
                channelNumber: nil,
                callLetters: "",
                channelLogoURL: "",
                ppvStart: "",
                ppvEnd: "",
                blockCode: "",
                pauseEnabled: false,
                isAPIWithBlockCode: false,
                multicastAbrEnabled: false,
                assetId: isSeries ? episode.assetId : item.assetId,
                placeHolderImage: "default_asset.png",
                recordingId: "",
                showDetailsPage: true,
                isAsset: true,
                isPPV: false,
                assetDetails: item,
                shouldDisplayBanner: false,
                shouldDisplayPlayBadge: false,
                shouldDisplayPurchasedTag: false,
                isSeriesIndicator: isSeries,
                ratings: nil,
                assetPermission: nil ,
                posterHeight: "200",
                userReview: isSeries ? episode.userReview : item.userReview,
                seasonNumber: EpisodeID.integer(0),
                episodeId: EpisodeID.string(""), recordedItem: nil, otherRecordedEpisodes: nil, isRecordedAsset: false
                
                

            )
            homeDataModels.append(homeDataModel)
        }
        
        return homeDataModels
        
    }
    
    func mapHomeDataModelToVODDetail(model: HomeDataModel) -> VODDetailModel {
        let detailSeriesModel = DetailSeriesModel(id: model.id, title: model.assetDetails?.title, assetId: model.assetId, seasonNumber: nil, episodeId: nil, userReview: model.userReview, poster: model.assetDetails?.poster, posters: model.assetDetails?.posters, year: model.assetDetails?.year, shortSummary: model.assetDetails?.shortSummary, rating: model.assetDetails?.rating, episodeName: model.assetDetails?.episodeName, licensingWindowEnd: model.assetDetails?.licensingWindowEnd, runTime: model.assetDetails?.runTime, episodes: mapToDetailSeriesModelArray(data: model))
        return VODDetailModel(assetId: model.assetId, assetDetails: detailSeriesModel,userReview: model.userReview, isSeries: false)
    }
    
    func mapHomeDataModelToVODSeriesDetail(model: HomeDataModel) -> VODDetailSeriesModel {
        let detailSeriesModel = DetailSeriesModel(id: model.id, title: model.assetDetails?.title, assetId: model.assetId, seasonNumber: nil, episodeId: nil, userReview: model.userReview, poster: model.assetDetails?.poster, posters: model.assetDetails?.posters, year: model.assetDetails?.year, shortSummary: model.assetDetails?.shortSummary, rating: model.assetDetails?.rating, episodeName: model.assetDetails?.episodeName, licensingWindowEnd: model.assetDetails?.licensingWindowEnd, runTime: model.assetDetails?.runTime, episodes: mapToDetailSeriesModelArray(data: model))
        let vodDetailSeries = VODDetailSeriesModel(assetDetails:detailSeriesModel,userReview: model.userReview)
       // vodDetailSeries.assetDetails?.id = model.assetDetails?.id
        return vodDetailSeries
    }
    
    
    
    
    
    
    func mapToDetailSeriesModelArray(data: HomeDataModel) -> [DetailSeriesModel] {
        var mappedArray = [DetailSeriesModel]()
        guard let episodes = data.assetDetails?.episodes else {
            return []
        }
        for object in episodes {
            mappedArray.append(DetailSeriesModel(id: object.id, title: object.title, assetId: object.assetId, seasonNumber: object.seasonNumber, episodeId: object.episodeId, userReview: object.userReview, poster: object.poster, posters: object.posters, year: object.year, shortSummary: object.shortSummary, rating: object.rating, episodeName: object.episodeName, licensingWindowEnd: object.licensingWindowEnd, runTime: object.runTime, episodes: []))
        }
        return mappedArray
    }
    
   
//    
//    func mapToDetailRecordItemFromHomeDataModel(data: HomeDataModel)  -> DetailRecordingsModel? {
//        
//        guard let item = data.recordedItem else {
//            return nil
//        }
//        
//        return DetailRecordingsModel(title: data.recordedItem?.title, iconSrc: data.recordedItem?.iconSrc, userReview: data.userReview, isSeries: true, id: data.recordedItem?.id, actualEndUtc: data.recordedItem?.actualEndUtc, actualStartUtc: data.recordedItem?.actualStartUtc, duration: data.recordedItem?.duration, ratings: data.recordedItem?.ratings, seasonNumber: data.recordedItem?.seasonNumber, episodeNumber: data.recordedItem?.episodeNumber, episodeTitle: data.recordedItem?.episodeTitle, channelCallLetter: data.recordedItem?.channelCallLetter, itemID: data.recordedItem?.itemId, shortSummary: data.recordedItem?.description, channelNumber: data.recordedItem?.channelNumber, scheduledStartUtc: data.recordedItem?.scheduledStartUtc, scheduledEndUtc: data.recordedItem?.scheduledEndUtc, episodes: [])
//    }
    
    
    
    
    func mapToDetailRecordingModelFromHomeDataModel(data: HomeDataModel) -> DetailRecordingsModel? {
        guard let recordings = data.otherRecordedEpisodes else {
            return nil
        }
        
        var recordingsArray = [DetailRecordings]()
        
        for object in recordings {
            if object.seasonNumber == nil {
                continue
            }
            let detailRecordings = DetailRecordings(id: object.id, title: object.title, actualEndUtc: object.actualEndUtc, actualStartUtc: object.actualStartUtc, duration: object.duration, ratings: object.ratings, seasonNumber: object.seasonNumber?.stringValue, episodeNumber: object.episodeNumber?.stringValue, episodeTitle: object.episodeTitle, iconSrc: object.iconSrc, channelCallLetter: object.channelCallLetter, itemID: object.itemId, shortSummary: object.description, channelNumber: object.channelNumber,scheduledStartUtc: object.scheduledStartUtc, scheduledEndUtc: object.scheduledEndUtc ,keepUntil: object.keepUntil,keepAtMost: object.keepAtMost,startTimeChoice: nil,showTypeChoice: nil,channelChoice: nil,startRecordingTime: nil,stopRecordingTime: nil,seriesId: object.seriesId,episodeId: object.episodeId, isProgram: data.otherRecordedEpisodes?.count ?? 0 > 0 ? false : true)
            recordingsArray.append(detailRecordings)
        }
        
        guard let item = data.recordedItem else {
            return nil
        }
        
        let d = DetailRecordingsModel(title: item.title, iconSrc: item.iconSrc, userReview: nil, isSeries: data.isRecordedAsset, id: item.id, actualEndUtc: item.actualEndUtc, actualStartUtc: item.actualStartUtc, duration: item.duration, ratings: item.ratings, seasonNumber: item.seasonNumber?.stringValue, episodeNumber: item.episodeNumber?.stringValue, episodeTitle: item.episodeTitle, channelCallLetter: item.channelCallLetter, itemID: item.itemId, shortSummary: item.description, channelNumber: item.channelNumber, scheduledStartUtc: item.scheduledStartUtc, scheduledEndUtc: item.scheduledEndUtc, episodes: recordingsArray, isRecordingCompleted: true,keepUntil: item.keepUntil,keepAtMost: item.keepAtMost,startTimeChoice: nil,showTypeChoice: nil,channelChoice: nil,startRecordingTime: nil,stopRecordingTime: nil,seriesId: item.seriesId,isProgram: item.otherRecordedEpisodes?.count ?? 0 > 0 ? false : true, episodeId: item.episodeId)
        
        return d
        
        
    }
}
